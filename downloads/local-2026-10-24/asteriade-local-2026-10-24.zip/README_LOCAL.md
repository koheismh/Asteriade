# Asteriade ローカル移行パッケージ

このZIPはクラウドの未commit作業を含みます。GitHubのmasterをcloneした状態とは異なります。

1. 配布時に示されたZIPのSHA-256を確認し、新しいフォルダへ展開する。
2. GitとPython 3.12を用意する。
3. `restore.py --destination`で、まだ存在しない新規作業フォルダへ復元する。
4. 復元先の`docs/research/LOCAL_DEVELOPMENT_HANDOFF_2026-10-24.md`を読む。
5. Go 1.27.2を用意してOS別の基準検証を行い、ローカルCodexで続きを進める。

Windows PowerShellの例（destinationの親フォルダは先に作成）:

```powershell
py -3.12 .\restore.py --destination "$env:USERPROFILE\source\Asteriade-local"
```

macOS/Linuxの例:

```bash
python3 restore.py --destination /path/to/new/Asteriade-local
```

復元器は外部通信、commit/push、依存インストール、アプリ実行をしません。bundleからGitを復元し、全ソースのhashとHEAD/未commit statusを照合します。既存フォルダへは上書きしません。失敗した新規出力は調査用に残ります。

`source/`は全作業ファイル、`base.bundle`は現在のbranchのGit履歴、`tracked-changes.patch`はtracked変更の確認用です。untrackedもsourceに含みます。manifestはすべてのpayloadのsize/hashを記録します。Gitの個人設定・資格情報、アプリDB、クラウドproxy、Go/cache、Backtrader sourceは同梱しません。

`evidence/`の記録はクラウドでの過去実績です。ローカルやWindowsでの成功を意味しません。PCで試験を実行し、観測を更新してください。Stage 0全体・Windows実効境界は未合格、RunnerはBLOCKEDのままです。
