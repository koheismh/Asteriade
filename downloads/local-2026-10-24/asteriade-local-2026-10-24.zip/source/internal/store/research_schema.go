package store

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
)

// schema (v1) remains byte-for-byte unchanged. Research is an additive v2.
var researchSchema = []string{
	`CREATE TABLE research_meta (id INTEGER PRIMARY KEY CHECK(id=1),epoch TEXT NOT NULL,sequence INTEGER NOT NULL,head_hash TEXT NOT NULL,continuity TEXT NOT NULL CHECK(continuity IN ('verified','unknown')))`,
	`CREATE TABLE research_partitions (id TEXT PRIMARY KEY,descriptor TEXT NOT NULL,exposure TEXT NOT NULL,version INTEGER NOT NULL)`,
	`CREATE TABLE research_ledger (sequence INTEGER PRIMARY KEY,kind TEXT NOT NULL,aggregate_id TEXT NOT NULL,payload TEXT NOT NULL,previous_hash TEXT NOT NULL,entry_hash TEXT NOT NULL UNIQUE)`,
	`CREATE TABLE research_manifests (identity_hash TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),parent_hash TEXT REFERENCES research_manifests(identity_hash),manifest TEXT NOT NULL)`,
	`CREATE TABLE research_runs (id TEXT PRIMARY KEY,manifest_hash TEXT NOT NULL REFERENCES research_manifests(identity_hash),project_id TEXT NOT NULL REFERENCES projects(id),status TEXT NOT NULL CHECK(status IN ('preparing','running','succeeded','outcome_unknown')),validation_status TEXT NOT NULL CHECK(validation_status='unvalidated'))`,
	`CREATE TABLE research_claims (id TEXT PRIMARY KEY,run_id TEXT NOT NULL UNIQUE REFERENCES research_runs(id),partition_id TEXT NOT NULL REFERENCES research_partitions(id),actor TEXT NOT NULL,policy_hash TEXT NOT NULL,manifest_hash TEXT NOT NULL REFERENCES research_manifests(identity_hash),fence INTEGER NOT NULL,status TEXT NOT NULL CHECK(status IN ('active','releasing','finished','outcome_unknown')),output_hash TEXT NOT NULL,recipient TEXT NOT NULL)`,
	`CREATE TABLE research_candidates (id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id),family_id TEXT NOT NULL,parent_id TEXT REFERENCES research_candidates(id),record TEXT NOT NULL)`,
	`CREATE TRIGGER research_ledger_no_update BEFORE UPDATE ON research_ledger BEGIN SELECT RAISE(ABORT,'research ledger is append only'); END`,
	`CREATE TRIGGER research_ledger_no_delete BEFORE DELETE ON research_ledger BEGIN SELECT RAISE(ABORT,'research ledger is append only'); END`,
	`CREATE TRIGGER research_manifest_no_update BEFORE UPDATE ON research_manifests BEGIN SELECT RAISE(ABORT,'frozen manifest is immutable'); END`,
	`CREATE TRIGGER research_manifest_no_delete BEFORE DELETE ON research_manifests BEGIN SELECT RAISE(ABORT,'frozen manifest is immutable'); END`,
	`CREATE TRIGGER research_candidate_no_update BEFORE UPDATE ON research_candidates BEGIN SELECT RAISE(ABORT,'candidate history is immutable'); END`,
	`CREATE TRIGGER research_candidate_no_delete BEFORE DELETE ON research_candidates BEGIN SELECT RAISE(ABORT,'candidate history is immutable'); END`,
	`CREATE TRIGGER research_partition_identity BEFORE UPDATE OF id,descriptor ON research_partitions BEGIN SELECT RAISE(ABORT,'partition identity is immutable'); END`,
	`CREATE TRIGGER research_partition_no_delete BEFORE DELETE ON research_partitions BEGIN SELECT RAISE(ABORT,'partition exposure must be retained'); END`,
}

func appliedSchema(ctx context.Context, d *sql.DB) (int, error) {
	var version int
	if err := d.QueryRowContext(ctx, "PRAGMA user_version").Scan(&version); err != nil {
		return 0, err
	}
	migrations := [][]string{schema, researchSchema}
	if version < 0 || version > len(migrations) {
		return 0, fmt.Errorf("unsupported schema version %d", version)
	}
	if version == 0 {
		var tables int
		if err := d.QueryRowContext(ctx, "SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").Scan(&tables); err != nil {
			return 0, err
		}
		if tables != 0 {
			return 0, fmt.Errorf("unversioned existing database; refusing initialization")
		}
		return 0, nil
	}
	var count int
	if err := d.QueryRowContext(ctx, "SELECT count(*) FROM schema_migrations").Scan(&count); err != nil {
		return 0, err
	}
	if count != version {
		return 0, fmt.Errorf("migration ledger count mismatch")
	}
	for i := 0; i < version; i++ {
		var recorded string
		if err := d.QueryRowContext(ctx, "SELECT script_hash FROM schema_migrations WHERE schema_version=?", i+1).Scan(&recorded); err != nil {
			return 0, err
		}
		if recorded != hash([]byte(strings.Join(migrations[i], "\n"))) {
			return 0, fmt.Errorf("schema migration checksum mismatch at version %d", i+1)
		}
	}
	return version, nil
}

func (s *Store) migrate(ctx context.Context) error {
	version, err := appliedSchema(ctx, s.db)
	if err != nil {
		return err
	}
	migrations := [][]string{schema, researchSchema}
	if version == len(migrations) {
		return nil
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	for i := version; i < len(migrations); i++ {
		for _, q := range migrations[i] {
			if _, err = tx.ExecContext(ctx, q); err != nil {
				return fmt.Errorf("migration %d: %w", i+1, err)
			}
		}
		if _, err = tx.ExecContext(ctx, "INSERT INTO schema_migrations(schema_version,script_hash,applied_at) VALUES(?,?,?)", i+1, hash([]byte(strings.Join(migrations[i], "\n"))), now()); err != nil {
			return err
		}
		if _, err = tx.ExecContext(ctx, fmt.Sprintf("PRAGMA user_version=%d", i+1)); err != nil {
			return err
		}
	}
	if _, err = tx.ExecContext(ctx, "INSERT INTO research_meta VALUES(1,?,0,?,'verified')", id(), hash([]byte("asteriade/synthetic-ledger-v1"))); err != nil {
		return err
	}
	if err = tx.Commit(); err != nil {
		return err
	}
	s.researchFresh = true
	return nil
}
