package store

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"testing"
	"testing/fstest"
	"time"

	"github.com/koheismh/Asteriade/internal/research"
)

type syntheticFixtureState struct {
	M     research.EvaluationManifest
	Files fstest.MapFS
	Run   SyntheticRun
	Req   SyntheticClaimRequest
}

func syntheticFixture(t *testing.T, s *Store, name string, start time.Time) syntheticFixtureState {
	t.Helper()
	ctx := context.Background()
	files := fstest.MapFS{}
	content := func(label string) string {
		b := []byte("synthetic " + name + " " + label)
		h := sha256.Sum256(b)
		k := hex.EncodeToString(h[:])
		files[k] = &fstest.MapFile{Data: b, Mode: 0600}
		return k
	}
	project, err := s.CreateProject(ctx, name, "synthetic registry tests", "plan_confirmation", "project-"+name)
	if err != nil {
		t.Fatal(err)
	}
	p := research.SyntheticPartition{ID: "partition-" + name, DatasetSHA256: content("dataset"), DataOrigin: "synthetic", Venue: "synthetic", Product: "spot", Base: "TOY", Quote: "CASH", LineageID: "lineage-" + name, Start: start, End: start.Add(2 * time.Hour), TimeframeSeconds: 3600, Role: "holdout", MappingKnown: true}
	if err = s.RegisterSyntheticPartition(ctx, p, "partition-"+name); err != nil {
		t.Fatal(err)
	}
	m := research.EvaluationManifest{ProjectID: project.ID, ResearchProgramID: "program-" + name, HypothesisID: "hypothesis-" + name, CycleID: "cycle-" + name, ExperimentID: "experiment-" + name, SelectionFamilyID: "family-" + name, Partition: p, Seed: 17, FrozenAt: start.Add(24 * time.Hour)}
	m.StrategySpec = research.StrategySpec{Version: research.StrategySpecVersion, Environment: "synthetic", Instrument: "TOY-CASH", TimeframeSeconds: 3600, Signal: research.ComponentRef{SHA256: content("signal")}, Entry: research.ComponentRef{SHA256: content("entry")}, Exit: research.ComponentRef{SHA256: content("exit")}, Sizing: research.ComponentRef{SHA256: content("sizing")}, Risk: research.ComponentRef{SHA256: content("risk")}}
	m.KernelSHA256 = content("kernel")
	m.CodeSHA256 = content("code")
	m.EnvironmentSHA256 = content("environment")
	m.BenchmarkSHA256 = content("benchmark")
	m.ProtocolSHA256 = content("protocol")
	m.CostSHA256 = content("cost")
	m.MetricsSHA256 = content("metrics")
	m.RequiredGatesSHA256 = content("gates")
	m.PolicySHA256 = content("policy")
	m, err = research.FreezeEvaluation(m)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.SaveSyntheticManifest(ctx, m, files, "manifest-"+name); err != nil {
		t.Fatal(err)
	}
	r, err := s.CreateSyntheticRun(ctx, m.IdentityHash, "run-"+name, files)
	if err != nil {
		t.Fatal(err)
	}
	return syntheticFixtureState{m, files, r, SyntheticClaimRequest{RunID: r.ID, PartitionID: p.ID, Actor: "synthetic-worker", PolicyHash: m.PolicySHA256, ManifestHash: m.IdentityHash}}
}

func syntheticStart() time.Time { return time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC) }
func mustClaim(t *testing.T, s *Store, f syntheticFixtureState, key string) SyntheticClaim {
	t.Helper()
	c, err := s.ClaimSyntheticEvaluation(context.Background(), f.Req, key)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestSyntheticPreflightAndClaimReplayBinding(t *testing.T) {
	s, ctx := openTest(t)
	f := syntheticFixture(t, s, "alpha", syntheticStart())
	if err := s.ChangeSyntheticExposure(ctx, f.M.Partition.ID, 1, "preflight", "preflight"); err != nil {
		t.Fatal(err)
	}
	if err := s.ChangeSyntheticExposure(ctx, f.M.Partition.ID, 2, "preflight_failed", "failed"); err != nil {
		t.Fatal(err)
	}
	p, err := s.SyntheticPartition(ctx, f.M.Partition.ID)
	if err != nil || p.Exposure.State != "unseen" || p.Exposure.AccessPossible {
		t.Fatal(p, err)
	}
	c := mustClaim(t, s, f, "claim")
	before, _ := s.ResearchCheckpoint(ctx)
	again, err := s.ClaimSyntheticEvaluation(ctx, f.Req, "claim")
	after, _ := s.ResearchCheckpoint(ctx)
	if err != nil || again != c || before != after {
		t.Fatal("replay changed durable state", err)
	}
	for _, mutate := range []func(*SyntheticClaimRequest){func(r *SyntheticClaimRequest) { r.Actor = "another-actor" }, func(r *SyntheticClaimRequest) { r.PolicyHash = f.M.CodeSHA256 }, func(r *SyntheticClaimRequest) { r.PartitionID = "another-partition" }, func(r *SyntheticClaimRequest) { r.ManifestHash = f.M.CodeSHA256 }} {
		r := f.Req
		mutate(&r)
		if _, err = s.ClaimSyntheticEvaluation(ctx, r, "claim"); !errors.Is(err, ErrConflict) {
			t.Fatal("changed payload replay", err)
		}
	}
	if err = s.CheckSyntheticClaim(ctx, c.Proof); err != nil {
		t.Fatal(err)
	}
	for _, change := range []func(*SyntheticClaimProof){func(p *SyntheticClaimProof) { p.Fence++ }, func(p *SyntheticClaimProof) { p.Actor = "another-actor" }, func(p *SyntheticClaimProof) { p.PolicyHash = f.M.CodeSHA256 }, func(p *SyntheticClaimProof) { p.ManifestHash = f.M.CodeSHA256 }} {
		proof := c.Proof
		change(&proof)
		if err = s.CheckSyntheticClaim(ctx, proof); err == nil {
			t.Fatal("invalid proof accepted")
		}
	}
}

func TestSyntheticConcurrentOverlapAndAdjacentInterval(t *testing.T) {
	s, ctx := openTest(t)
	a := syntheticFixture(t, s, "alpha", syntheticStart())
	b := syntheticFixture(t, s, "beta", syntheticStart().Add(time.Hour))
	var wg sync.WaitGroup
	errs := make(chan error, 2)
	for i, f := range []syntheticFixtureState{a, b} {
		wg.Add(1)
		go func(i int, f syntheticFixtureState) {
			defer wg.Done()
			_, err := s.ClaimSyntheticEvaluation(ctx, f.Req, []string{"claim-a", "claim-b"}[i])
			errs <- err
		}(i, f)
	}
	wg.Wait()
	close(errs)
	passed, conflicts := 0, 0
	for err := range errs {
		if err == nil {
			passed++
		} else if errors.Is(err, research.ErrExposureConflict) {
			conflicts++
		} else {
			t.Fatal(err)
		}
	}
	if passed != 1 || conflicts != 1 {
		t.Fatalf("grants=%d conflicts=%d", passed, conflicts)
	}
	var count int
	s.db.QueryRow("SELECT count(*) FROM research_claims").Scan(&count)
	if count != 1 {
		t.Fatal(count)
	}
	adjacent := syntheticFixture(t, s, "adjacent", syntheticStart().Add(3*time.Hour))
	mustClaim(t, s, adjacent, "claim-adjacent")
	if err := s.verifyResearchLedger(ctx); err != nil {
		t.Fatal(err)
	}
}

func researchCounts(t *testing.T, s *Store) map[string]int {
	t.Helper()
	out := map[string]int{}
	for _, table := range []string{"research_claims", "research_ledger", "events", "outbox", "request_receipts"} {
		var n int
		if err := s.db.QueryRow("SELECT count(*) FROM " + table).Scan(&n); err != nil {
			t.Fatal(err)
		}
		out[table] = n
	}
	return out
}

func TestSyntheticClaimFailureIsAtomicAtEveryWriteBoundary(t *testing.T) {
	for _, table := range []string{"research_claims", "research_ledger", "outbox", "request_receipts"} {
		t.Run(table, func(t *testing.T) {
			s, ctx := openTest(t)
			f := syntheticFixture(t, s, "atomic", syntheticStart())
			before := researchCounts(t, s)
			cp, _ := s.ResearchCheckpoint(ctx)
			if _, err := s.db.Exec("CREATE TEMP TRIGGER injected_failure BEFORE INSERT ON " + table + " BEGIN SELECT RAISE(ABORT,'injected'); END"); err != nil {
				t.Fatal(err)
			}
			if _, err := s.ClaimSyntheticEvaluation(ctx, f.Req, "claim"); err == nil {
				t.Fatal("injected failure ignored")
			}
			if !reflect.DeepEqual(before, researchCounts(t, s)) {
				t.Fatal("partial transaction")
			}
			got, _ := s.ResearchCheckpoint(ctx)
			p, _ := s.SyntheticPartition(ctx, f.M.Partition.ID)
			r, _ := s.SyntheticRun(ctx, f.Run.ID)
			if got != cp || p.Exposure.State != "unseen" || p.Exposure.AccessPossible || r.Status != "preparing" {
				t.Fatal("projection partially committed", p, r)
			}
			if _, err := s.db.Exec("DROP TRIGGER injected_failure"); err != nil {
				t.Fatal(err)
			}
			mustClaim(t, s, f, "claim")
		})
	}
}

func TestSyntheticReleaseCorrectionAndCandidateHistory(t *testing.T) {
	s, ctx := openTest(t)
	f := syntheticFixture(t, s, "release", syntheticStart())
	c := mustClaim(t, s, f, "claim")
	if err := s.RecordSyntheticClaim(ctx, c.Proof, "release_intent", f.M.CodeSHA256, "synthetic-viewer", "early-release"); err == nil {
		t.Fatal("released before value access")
	}
	if err := s.RecordSyntheticClaim(ctx, c.Proof, "value_access", "", "", "read"); err != nil {
		t.Fatal(err)
	}
	if err := s.RecordSyntheticClaim(ctx, c.Proof, "release_intent", f.M.CodeSHA256, "synthetic-viewer", "release"); err != nil {
		t.Fatal(err)
	}
	if err := s.CheckSyntheticClaim(ctx, c.Proof); err == nil {
		t.Fatal("release did not fence further access")
	}
	if err := s.RecordSyntheticClaim(ctx, c.Proof, "release_ack", f.M.KernelSHA256, "synthetic-viewer", "bad-ack"); err == nil {
		t.Fatal("ack mismatched result")
	}
	if err := s.RecordSyntheticClaim(ctx, c.Proof, "release_ack", f.M.CodeSHA256, "synthetic-viewer", "ack"); err != nil {
		t.Fatal(err)
	}
	r, _ := s.SyntheticRun(ctx, f.Run.ID)
	if r.Status != "succeeded" || r.ValidationStatus != "unvalidated" {
		t.Fatal("run success promoted scientific validity", r)
	}
	p, _ := s.SyntheticPartition(ctx, f.M.Partition.ID)
	if err := s.ChangeSyntheticExposure(ctx, p.Partition.ID, p.Exposure.Version, "defect", "defect"); err != nil {
		t.Fatal(err)
	}
	p, _ = s.SyntheticPartition(ctx, p.Partition.ID)
	if err := s.ChangeSyntheticExposure(ctx, p.Partition.ID, p.Exposure.Version, "corrected", "corrected"); err == nil {
		t.Fatal("correction accepted without a revision")
	}
	if err := s.CorrectSyntheticAnalysis(ctx, c.Proof.ClaimID, f.M.IdentityHash, "no-revision", f.Files); err == nil {
		t.Fatal("original manifest accepted as correction")
	}
	revision := f.M
	revision.ParentIdentityHash = f.M.IdentityHash
	revision.RevisionReason = "synthetic kernel correction"
	revision, err := research.FreezeEvaluation(revision)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.SaveSyntheticManifest(ctx, revision, f.Files, "same-kernel"); err != nil {
		t.Fatal(err)
	}
	if err = s.CorrectSyntheticAnalysis(ctx, c.Proof.ClaimID, revision.IdentityHash, "same-kernel", f.Files); err == nil {
		t.Fatal("correction accepted without new kernel")
	}
	kernel := []byte("synthetic corrected kernel")
	kernelHash := sha256.Sum256(kernel)
	revision.KernelSHA256 = hex.EncodeToString(kernelHash[:])
	f.Files[revision.KernelSHA256] = &fstest.MapFile{Data: kernel, Mode: 0600}
	revision, err = research.FreezeEvaluation(revision)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.SaveSyntheticManifest(ctx, revision, f.Files, "corrected-manifest"); err != nil {
		t.Fatal(err)
	}
	if err = s.CorrectSyntheticAnalysis(ctx, c.Proof.ClaimID, revision.IdentityHash, "corrected", f.Files); err != nil {
		t.Fatal(err)
	}
	p, _ = s.SyntheticPartition(ctx, p.Partition.ID)
	if p.Exposure.State != "corrected_analysis" || !p.Exposure.ResultReleased {
		t.Fatal(p)
	}
	parent := SyntheticCandidate{ID: "candidate-parent", ProjectID: f.M.ProjectID, FamilyID: "family-one", Reason: "initial synthetic hypothesis"}
	if err := s.RegisterSyntheticCandidate(ctx, parent, "candidate-parent"); err != nil {
		t.Fatal(err)
	}
	if err := s.RecordSyntheticCandidateOutcome(ctx, parent.ID, "failed", "synthetic counterexample", "outcome-parent"); err != nil {
		t.Fatal(err)
	}
	child := SyntheticCandidate{ID: "candidate-child", ProjectID: f.M.ProjectID, FamilyID: parent.FamilyID, ParentID: parent.ID, Reason: "derived after failure"}
	if err := s.RegisterSyntheticCandidate(ctx, child, "candidate-child"); err != nil {
		t.Fatal(err)
	}
	if err := s.RecordSyntheticCandidateOutcome(ctx, child.ID, "rejected", "unsupported assumption", "outcome-child"); err != nil {
		t.Fatal(err)
	}
	if err := s.RecordSyntheticCandidateOutcome(ctx, parent.ID, "selected", "rewrite failure", "rewrite"); !errors.Is(err, ErrConflict) {
		t.Fatal(err)
	}
	var count int
	s.db.QueryRow("SELECT count(*) FROM research_candidates").Scan(&count)
	if count != 2 {
		t.Fatal(count)
	}
	for _, q := range []string{"DELETE FROM research_candidates", "UPDATE research_manifests SET manifest='{}'", "DELETE FROM research_ledger", "UPDATE research_partitions SET descriptor='{}'"} {
		if _, err := s.db.Exec(q); err == nil {
			t.Fatal("immutable history changed", q)
		}
	}
}

func TestSyntheticManifestContentRevisionAndRuns(t *testing.T) {
	s, ctx := openTest(t)
	f := syntheticFixture(t, s, "identity", syntheticStart())
	r, err := s.CreateSyntheticRun(ctx, f.M.IdentityHash, "run-two", f.Files)
	if err != nil || r.ID == f.Run.ID || r.ManifestHash != f.Run.ManifestHash {
		t.Fatal(r, err)
	}
	again, err := s.CreateSyntheticRun(ctx, f.M.IdentityHash, "run-two", f.Files)
	if err != nil || again.ID != r.ID {
		t.Fatal(err)
	}
	old := f.Files[f.M.KernelSHA256]
	f.Files[f.M.KernelSHA256] = &fstest.MapFile{Data: []byte("tampered")}
	if _, err = s.CreateSyntheticRun(ctx, f.M.IdentityHash, "tampered", f.Files); err == nil {
		t.Fatal("changed content accepted at run creation")
	}
	f.Files[f.M.KernelSHA256] = old
	m := f.M
	m.Seed++
	m, err = research.FreezeEvaluation(m)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.SaveSyntheticManifest(ctx, m, f.Files, "unparented"); !errors.Is(err, ErrConflict) {
		t.Fatal("same experiment rewritten without lineage", err)
	}
	m.ParentIdentityHash = f.M.IdentityHash
	m.RevisionReason = "synthetic correction"
	m, err = research.FreezeEvaluation(m)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.SaveSyntheticManifest(ctx, m, f.Files, "revision"); err != nil {
		t.Fatal(err)
	}
	if m.IdentityHash == f.M.IdentityHash {
		t.Fatal("revision reused identity")
	}
	// Verify actual files via os.DirFS too, not only an in-memory fixture.
	dir := t.TempDir()
	for h, file := range f.Files {
		if err = os.WriteFile(filepath.Join(dir, h), file.Data, 0600); err != nil {
			t.Fatal(err)
		}
	}
	if err = research.VerifyEvaluationContent(m, os.DirFS(dir)); err != nil {
		t.Fatal(err)
	}
	if err = os.Remove(filepath.Join(dir, m.CostSHA256)); err != nil {
		t.Fatal(err)
	}
	if err = research.VerifyEvaluationContent(m, os.DirFS(dir)); err == nil {
		t.Fatal("missing referenced file accepted")
	}
}

func TestSyntheticUnknownMappingAndMissingPartitionFailClosed(t *testing.T) {
	s, ctx := openTest(t)
	f := syntheticFixture(t, s, "known", syntheticStart())
	p := f.M.Partition
	p.ID = "unknown-partition"
	p.MappingKnown = false
	if err := s.RegisterSyntheticPartition(ctx, p, "unknown"); err != nil {
		t.Fatal(err)
	}
	if _, err := s.ClaimSyntheticEvaluation(ctx, f.Req, "claim"); !errors.Is(err, research.ErrContinuityUnknown) {
		t.Fatal(err)
	}
	if _, err := s.SyntheticPartition(ctx, "missing"); !errors.Is(err, ErrNotFound) {
		t.Fatal(err)
	}
}

// Subprocess exits without Close after durable transitions. The parent opens
// the DB as a fresh process would; no worker or network capability is involved.
func TestResearchCrashHelper(t *testing.T) {
	path := os.Getenv("ASTERIADE_TEST_CRASH_DB")
	if path == "" {
		t.Skip("subprocess helper")
	}
	s, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	f := syntheticFixture(t, s, "crash", syntheticStart())
	c := mustClaim(t, s, f, "claim")
	phase := os.Getenv("ASTERIADE_TEST_CRASH_PHASE")
	ctx := context.Background()
	if phase == "read" || phase == "release" {
		if err = s.RecordSyntheticClaim(ctx, c.Proof, "value_access", "", "", "read"); err != nil {
			t.Fatal(err)
		}
	}
	if phase == "release" {
		if err = s.RecordSyntheticClaim(ctx, c.Proof, "release_intent", f.M.CodeSHA256, "synthetic-viewer", "release"); err != nil {
			t.Fatal(err)
		}
	}
	b, err := json.Marshal(c)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path+".proof", b, 0600); err != nil {
		t.Fatal(err)
	}
	os.Exit(0)
}

func TestSyntheticAbruptExitRecoveryAndReplay(t *testing.T) {
	for _, phase := range []string{"intent", "read", "release"} {
		t.Run(phase, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "crash.db")
			cmd := exec.Command(os.Args[0], "-test.run=^TestResearchCrashHelper$")
			cmd.Env = append(os.Environ(), "ASTERIADE_TEST_CRASH_DB="+path, "ASTERIADE_TEST_CRASH_PHASE="+phase)
			if out, err := cmd.CombinedOutput(); err != nil {
				t.Fatalf("helper: %v %s", err, out)
			}
			b, err := os.ReadFile(path + ".proof")
			if err != nil {
				t.Fatal(err)
			}
			var old SyntheticClaim
			if err = json.Unmarshal(b, &old); err != nil {
				t.Fatal(err)
			}
			s, err := Open(path)
			if err != nil {
				t.Fatal(err)
			}
			ctx := context.Background()
			p, err := s.SyntheticPartition(ctx, old.Proof.PartitionID)
			if err != nil || !p.Exposure.AccessPossible || p.Exposure.Fence <= old.Proof.Fence {
				t.Fatal(p, err)
			}
			if phase == "release" && !p.Exposure.ResultReleased {
				t.Fatal("lost release exposure")
			}
			r, _ := s.SyntheticRun(ctx, old.Proof.RunID)
			if r.Status != "outcome_unknown" {
				t.Fatal(r)
			}
			if err = s.CheckSyntheticClaim(ctx, old.Proof); err == nil {
				t.Fatal("old proof reactivated")
			}
			cp, _ := s.ResearchCheckpoint(ctx)
			replay, err := s.ClaimSyntheticEvaluation(ctx, old.Proof.SyntheticClaimRequest, "claim")
			after, _ := s.ResearchCheckpoint(ctx)
			if err != nil || replay.Status != "outcome_unknown" || cp != after {
				t.Fatal("replay restored grant", replay, err)
			}
			s.Close()
			s, err = Open(path)
			if err != nil {
				t.Fatal(err)
			}
			defer s.Close()
			again, _ := s.ResearchCheckpoint(ctx)
			if again != after {
				t.Fatal("repeated recovery changed history")
			}
		})
	}
}

func TestSyntheticRestoreAndLostWitnessNeverRestoreUnseen(t *testing.T) {
	for _, mode := range []string{"new-location", "older-db", "missing-witness", "db-ahead-of-witness"} {
		t.Run(mode, func(t *testing.T) {
			dir := t.TempDir()
			path := filepath.Join(dir, "state.db")
			s, err := Open(path)
			if err != nil {
				t.Fatal(err)
			}
			ctx := context.Background()
			f := syntheticFixture(t, s, "restore", syntheticStart())
			backup := filepath.Join(dir, "backup.db")
			if err = s.Backup(ctx, backup); err != nil {
				t.Fatal(err)
			}
			oldWitness, err := os.ReadFile(path + ".research-witness")
			if err != nil {
				t.Fatal(err)
			}
			mustClaim(t, s, f, "claim")
			s.Close()
			switch mode {
			case "new-location":
				path = backup
			case "older-db":
				b, e := os.ReadFile(backup)
				if e != nil {
					t.Fatal(e)
				}
				if e = os.WriteFile(path, b, 0600); e != nil {
					t.Fatal(e)
				}
			case "missing-witness":
				if e := os.Remove(path + ".research-witness"); e != nil {
					t.Fatal(e)
				}
			case "db-ahead-of-witness":
				// Durable state of an interruption after DB commit but before
				// witness replacement. No acknowledgment can make it unused.
				if e := os.WriteFile(path+".research-witness", oldWitness, 0600); e != nil {
					t.Fatal(e)
				}
			}
			s, err = Open(path)
			if err != nil {
				t.Fatal(err)
			}
			defer s.Close()
			cp, _ := s.ResearchCheckpoint(ctx)
			if cp.Continuity != "unknown" {
				t.Fatal("restore trusted copied metadata", cp)
			}
			p, _ := s.SyntheticPartition(ctx, f.M.Partition.ID)
			if p.Exposure.Continuity != "unknown" {
				t.Fatal(p)
			}
			if _, err = s.ClaimSyntheticEvaluation(ctx, f.Req, "after-restore"); !errors.Is(err, research.ErrContinuityUnknown) {
				t.Fatal(err)
			}
		})
	}
}

func TestSyntheticProjectionAndReceiptTamperingFailClosed(t *testing.T) {
	for _, mode := range []string{"exposure-reset", "claim", "run", "receipt", "ledger-gap"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "state.db")
			s, err := Open(path)
			if err != nil {
				t.Fatal(err)
			}
			defer s.Close()
			ctx := context.Background()
			f := syntheticFixture(t, s, "finished", syntheticStart())
			c := mustClaim(t, s, f, "claim")
			for _, event := range []string{"value_access", "release_intent", "release_ack"} {
				output, recipient := f.M.CodeSHA256, "synthetic-viewer"
				if event == "value_access" {
					output, recipient = "", ""
				}
				if err = s.RecordSyntheticClaim(ctx, c.Proof, event, output, recipient, event); err != nil {
					t.Fatal(err)
				}
			}
			// A fresh run makes this regression independent of the original
			// run's terminal status and of recovery of unfinished claims.
			fresh, err := s.CreateSyntheticRun(ctx, f.M.IdentityHash, "next-run", f.Files)
			if err != nil {
				t.Fatal(err)
			}
			cp, err := s.ResearchCheckpoint(ctx)
			if err != nil {
				t.Fatal(err)
			}
			switch mode {
			case "exposure-reset":
				b, e := json.Marshal(research.NewExposure())
				if e != nil {
					t.Fatal(e)
				}
				_, err = s.db.Exec("UPDATE research_partitions SET exposure=?,version=1 WHERE id=?", string(b), f.M.Partition.ID)
			case "claim":
				_, err = s.db.Exec("UPDATE research_claims SET actor='different-worker' WHERE id=?", c.Proof.ClaimID)
			case "run":
				_, err = s.db.Exec("UPDATE research_runs SET status='preparing' WHERE id=?", f.Run.ID)
			case "receipt":
				_, err = s.db.Exec("UPDATE request_receipts SET result_ref='different-claim' WHERE scope='research.claim'")
			case "ledger-gap":
				if _, err = s.db.Exec("DROP TRIGGER research_ledger_no_delete"); err == nil {
					_, err = s.db.Exec("DELETE FROM research_ledger WHERE sequence=1")
				}
			}
			if err != nil {
				t.Fatal(err)
			}
			req := f.Req
			req.RunID = fresh.ID
			if _, err = s.ClaimSyntheticEvaluation(ctx, req, "after-corruption"); !errors.Is(err, research.ErrContinuityUnknown) {
				t.Fatal("corruption allowed new grant", err)
			}
			if _, err = s.ClaimSyntheticEvaluation(ctx, f.Req, "claim"); !errors.Is(err, research.ErrContinuityUnknown) {
				t.Fatal("corruption allowed replay", err)
			}
			if _, err = s.SyntheticPartition(ctx, f.M.Partition.ID); !errors.Is(err, research.ErrContinuityUnknown) {
				t.Fatal("corrupt projection presented as authoritative", err)
			}
			after, err := s.ResearchCheckpoint(ctx)
			if err != nil || cp != after {
				t.Fatal("failed access changed history", err)
			}
			if err = s.Close(); err != nil {
				t.Fatal(err)
			}
			reopened, err := Open(path)
			if err == nil {
				reopened.Close()
				t.Fatal("corruption accepted at open")
			}
			if !errors.Is(err, research.ErrContinuityUnknown) {
				t.Fatal(err)
			}
		})
	}
}

func TestSyntheticEmptyLedgerCannotAuthorizeExistingProjection(t *testing.T) {
	s, ctx := openTest(t)
	p := research.SyntheticPartition{ID: "unrecorded-partition", DatasetSHA256: strings.Repeat("a", 64), DataOrigin: "synthetic", Venue: "synthetic", Product: "spot", Base: "TOY", Quote: "CASH", LineageID: "unrecorded-lineage", Start: syntheticStart(), End: syntheticStart().Add(time.Hour), TimeframeSeconds: 3600, Role: "holdout", MappingKnown: true}
	d, err := json.Marshal(p)
	if err != nil {
		t.Fatal(err)
	}
	x, err := json.Marshal(research.NewExposure())
	if err != nil {
		t.Fatal(err)
	}
	if _, err = s.db.Exec("INSERT INTO research_partitions VALUES(?,?,?,1)", p.ID, string(d), string(x)); err != nil {
		t.Fatal(err)
	}
	if err = s.verifyResearchLedger(ctx); !errors.Is(err, research.ErrContinuityUnknown) {
		t.Fatal("empty ledger authorized state", err)
	}
}

func createLegacyV1(t *testing.T, path string) {
	t.Helper()
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_RDWR, 0600)
	if err != nil {
		t.Fatal(err)
	}
	f.Close()
	d, err := sql.Open("sqlite3", path)
	if err != nil {
		t.Fatal(err)
	}
	defer d.Close()
	for _, q := range schema {
		if _, err = d.Exec(q); err != nil {
			t.Fatal(err)
		}
	}
	if _, err = d.Exec("INSERT INTO schema_migrations VALUES(1,?,?)", hash([]byte(strings.Join(schema, "\n"))), now()); err != nil {
		t.Fatal(err)
	}
	if _, err = d.Exec("INSERT INTO projects(id,title,goal,lifecycle_status,execution_mode,limits_json,created_at,updated_at) VALUES('legacy-project','legacy title','goal','draft','automatic','{}',?,?)", now(), now()); err != nil {
		t.Fatal(err)
	}
	if _, err = d.Exec("PRAGMA user_version=1"); err != nil {
		t.Fatal(err)
	}
}

func TestResearchMigrationPreservesV1AndRejectsInvalidLedgers(t *testing.T) {
	path := filepath.Join(t.TempDir(), "legacy.db")
	createLegacyV1(t, path)
	s, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	p, err := s.GetProject(context.Background(), "legacy-project")
	if err != nil || p.Title != "legacy title" {
		t.Fatal(p, err)
	}
	var h string
	s.db.QueryRow("SELECT script_hash FROM schema_migrations WHERE schema_version=1").Scan(&h)
	if h != hash([]byte(strings.Join(schema, "\n"))) {
		t.Fatal("v1 checksum changed")
	}
	s.Close()
	s, err = Open(path)
	if err != nil {
		t.Fatal(err)
	}
	var count int
	s.db.QueryRow("SELECT count(*) FROM schema_migrations").Scan(&count)
	s.Close()
	if count != 2 {
		t.Fatal(count)
	}
	for _, mode := range []string{"future", "tampered", "missing", "migration-failure"} {
		t.Run(mode, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "bad.db")
			createLegacyV1(t, path)
			d, e := sql.Open("sqlite3", path)
			if e != nil {
				t.Fatal(e)
			}
			query := map[string]string{"future": "PRAGMA user_version=999", "tampered": "UPDATE schema_migrations SET script_hash='bad'", "missing": "DELETE FROM schema_migrations", "migration-failure": "CREATE TABLE research_partitions(collision TEXT)"}[mode]
			if _, e = d.Exec(query); e != nil {
				t.Fatal(e)
			}
			d.Close()
			before, e := os.ReadFile(path)
			if e != nil {
				t.Fatal(e)
			}
			if bad, e := Open(path); e == nil {
				bad.Close()
				t.Fatal("invalid database accepted")
			}
			if mode != "migration-failure" {
				after, e := os.ReadFile(path)
				if e != nil || string(before) != string(after) {
					t.Fatal("rejected database rewritten", e)
				}
			} else {
				d, e = sql.Open("sqlite3", path)
				if e != nil {
					t.Fatal(e)
				}
				defer d.Close()
				var version, meta int
				d.QueryRow("PRAGMA user_version").Scan(&version)
				d.QueryRow("SELECT count(*) FROM sqlite_master WHERE name='research_meta'").Scan(&meta)
				if version != 1 || meta != 0 {
					t.Fatal("partial migration", version, meta)
				}
			}
		})
	}
}
