package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"io/fs"
	"strings"

	"github.com/koheismh/Asteriade/internal/research"
)

type SyntheticPartitionRecord struct {
	Partition research.SyntheticPartition `json:"partition"`
	Exposure  research.Exposure           `json:"exposure"`
}

type rowQuery interface {
	QueryRowContext(context.Context, string, ...any) *sql.Row
}

func loadPartition(ctx context.Context, q rowQuery, id string) (SyntheticPartitionRecord, error) {
	var p SyntheticPartitionRecord
	var descriptor, exposure string
	var version int64
	err := q.QueryRowContext(ctx, "SELECT descriptor,exposure,version FROM research_partitions WHERE id=?", id).Scan(&descriptor, &exposure, &version)
	if errors.Is(err, sql.ErrNoRows) {
		return p, ErrNotFound
	}
	if err != nil {
		return p, err
	}
	if err = json.Unmarshal([]byte(descriptor), &p.Partition); err != nil {
		return p, err
	}
	if err = json.Unmarshal([]byte(exposure), &p.Exposure); err != nil {
		return p, err
	}
	if err = p.Partition.Validate(); err != nil {
		return p, err
	}
	if err = p.Exposure.Validate(); err != nil {
		return p, err
	}
	if p.Partition.ID != id || p.Exposure.Version != version {
		return p, ErrInvalid
	}
	return p, nil
}

func loadPartitions(ctx context.Context, tx *sql.Tx) ([]SyntheticPartitionRecord, error) {
	rows, err := tx.QueryContext(ctx, "SELECT id FROM research_partitions ORDER BY id")
	if err != nil {
		return nil, err
	}
	var ids []string
	for rows.Next() {
		var id string
		if err = rows.Scan(&id); err != nil {
			rows.Close()
			return nil, err
		}
		ids = append(ids, id)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return nil, err
	}
	var out []SyntheticPartitionRecord
	for _, id := range ids {
		p, err := loadPartition(ctx, tx, id)
		if err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, nil
}

func saveExposure(ctx context.Context, tx *sql.Tx, id string, x research.Exposure) error {
	if err := x.Validate(); err != nil {
		return err
	}
	b, err := json.Marshal(x)
	if err != nil {
		return err
	}
	result, err := tx.ExecContext(ctx, "UPDATE research_partitions SET exposure=?,version=? WHERE id=? AND version=?", string(b), x.Version, id, x.Version-1)
	if err != nil {
		return err
	}
	n, err := result.RowsAffected()
	if err != nil {
		return err
	}
	if n != 1 {
		return ErrConflict
	}
	return nil
}

func (s *Store) SyntheticPartition(ctx context.Context, id string) (SyntheticPartitionRecord, error) {
	s.researchMu.Lock()
	defer s.researchMu.Unlock()
	if err := s.verifyResearchLedger(ctx); err != nil {
		return SyntheticPartitionRecord{}, err
	}
	return loadPartition(ctx, s.db, id)
}

func (s *Store) RegisterSyntheticPartition(ctx context.Context, p research.SyntheticPartition, key string) error {
	if err := p.Validate(); err != nil {
		return err
	}
	_, err := s.researchWrite(ctx, "research.register_partition", key, p, func(tx *sql.Tx) (string, error) {
		var existing string
		if e := tx.QueryRowContext(ctx, "SELECT id FROM research_partitions WHERE id=?", p.ID).Scan(&existing); e == nil {
			return "", ErrConflict
		} else if !errors.Is(e, sql.ErrNoRows) {
			return "", e
		}
		d, e := json.Marshal(p)
		if e != nil {
			return "", e
		}
		x, e := json.Marshal(research.NewExposure())
		if e != nil {
			return "", e
		}
		if _, e = tx.ExecContext(ctx, "INSERT INTO research_partitions VALUES(?,?,?,1)", p.ID, string(d), string(x)); e != nil {
			return "", e
		}
		return p.ID, s.appendResearch(ctx, tx, "partition_registered", p.ID, p)
	})
	return err
}

// ChangeSyntheticExposure records diagnostic events only. Access
// and release intents can only be issued by the transactional claim methods.
func (s *Store) ChangeSyntheticExposure(ctx context.Context, partition string, version int64, event, key string) error {
	if event != "preflight" && event != "preflight_failed" && event != "defect" && event != "retire" {
		return ErrInvalid
	}
	_, err := s.researchWrite(ctx, "research.exposure", key, []any{partition, version, event}, func(tx *sql.Tx) (string, error) {
		p, e := loadPartition(ctx, tx, partition)
		if e != nil {
			return "", e
		}
		if p.Exposure.Version != version {
			return "", ErrConflict
		}
		x, e := research.ApplyExposure(p.Exposure, event)
		if e != nil {
			return "", e
		}
		if e = saveExposure(ctx, tx, partition, x); e != nil {
			return "", e
		}
		return partition, s.appendResearch(ctx, tx, event, partition, x)
	})
	return err
}

// CorrectSyntheticAnalysis records a revision of an already released claim.
// It preserves consumption and grants no access or scientific validity.
func (s *Store) CorrectSyntheticAnalysis(ctx context.Context, claimID, revisionHash, key string, content fs.FS) error {
	revision, err := loadManifest(ctx, s.db, revisionHash)
	if err != nil {
		return err
	}
	if err = research.VerifyEvaluationContent(revision, content); err != nil {
		return err
	}
	_, err = s.researchWrite(ctx, "research.correction", key, []string{claimID, revisionHash}, func(tx *sql.Tx) (string, error) {
		c, e := loadClaim(ctx, tx, claimID)
		if e != nil {
			return "", e
		}
		if c.OutputHash == "" || c.Recipient != "synthetic-viewer" || c.Status == "active" {
			return "", ErrConflict
		}
		original, e := loadManifest(ctx, tx, c.Proof.ManifestHash)
		if e != nil {
			return "", e
		}
		if revision.ParentIdentityHash != original.IdentityHash || revision.KernelSHA256 == original.KernelSHA256 ||
			revision.Partition != original.Partition || revision.ProjectID != original.ProjectID || revision.SelectionFamilyID != original.SelectionFamilyID {
			return "", ErrConflict
		}
		p, e := loadPartition(ctx, tx, c.Proof.PartitionID)
		if e != nil {
			return "", e
		}
		x, e := research.ApplyExposure(p.Exposure, "corrected")
		if e != nil {
			return "", e
		}
		if e = saveExposure(ctx, tx, c.Proof.PartitionID, x); e != nil {
			return "", e
		}
		return revisionHash, s.appendResearch(ctx, tx, "corrected", c.Proof.PartitionID, struct {
			ClaimID      string            `json:"claim_id"`
			RevisionHash string            `json:"revision_hash"`
			Exposure     research.Exposure `json:"exposure"`
		}{claimID, revisionHash, x})
	})
	return err
}

func loadManifest(ctx context.Context, q rowQuery, h string) (research.EvaluationManifest, error) {
	var m research.EvaluationManifest
	var b string
	err := q.QueryRowContext(ctx, "SELECT manifest FROM research_manifests WHERE identity_hash=?", h).Scan(&b)
	if errors.Is(err, sql.ErrNoRows) {
		return m, ErrNotFound
	}
	if err != nil {
		return m, err
	}
	if err = json.Unmarshal([]byte(b), &m); err != nil {
		return m, err
	}
	if m.IdentityHash != h {
		return m, ErrInvalid
	}
	return m, research.VerifyEvaluation(m)
}

func (s *Store) SaveSyntheticManifest(ctx context.Context, m research.EvaluationManifest, content fs.FS, key string) error {
	if err := research.VerifyEvaluationContent(m, content); err != nil {
		return err
	}
	_, err := s.researchWrite(ctx, "research.manifest", key, m, func(tx *sql.Tx) (string, error) {
		p, e := loadPartition(ctx, tx, m.Partition.ID)
		if e != nil {
			return "", e
		}
		if p.Partition != m.Partition {
			return "", ErrConflict
		}
		if m.ParentIdentityHash != "" {
			parent, e := loadManifest(ctx, tx, m.ParentIdentityHash)
			if e != nil {
				return "", e
			}
			if parent.ProjectID != m.ProjectID || parent.SelectionFamilyID != m.SelectionFamilyID {
				return "", ErrConflict
			}
		}
		rows, e := tx.QueryContext(ctx, "SELECT manifest FROM research_manifests WHERE project_id=?", m.ProjectID)
		if e != nil {
			return "", e
		}
		for rows.Next() {
			var b string
			if e = rows.Scan(&b); e != nil {
				rows.Close()
				return "", e
			}
			var old research.EvaluationManifest
			if e = json.Unmarshal([]byte(b), &old); e != nil {
				rows.Close()
				return "", e
			}
			if old.ExperimentID == m.ExperimentID && old.IdentityHash != m.IdentityHash && m.ParentIdentityHash == "" {
				rows.Close()
				return "", ErrConflict
			}
		}
		e = rows.Err()
		rows.Close()
		if e != nil {
			return "", e
		}
		b, e := json.Marshal(m)
		if e != nil {
			return "", e
		}
		if _, e = tx.ExecContext(ctx, "INSERT INTO research_manifests VALUES(?,?,?,?)", m.IdentityHash, m.ProjectID, nullString(m.ParentIdentityHash), string(b)); e != nil {
			return "", e
		}
		return m.IdentityHash, s.appendResearch(ctx, tx, "manifest_frozen", m.IdentityHash, m)
	})
	return err
}

type SyntheticRun struct {
	ID               string `json:"id"`
	ManifestHash     string `json:"manifest_hash"`
	ProjectID        string `json:"project_id"`
	Status           string `json:"status"`
	ValidationStatus string `json:"validation_status"`
}

func (s *Store) CreateSyntheticRun(ctx context.Context, manifestHash, key string, content fs.FS) (SyntheticRun, error) {
	m, err := loadManifest(ctx, s.db, manifestHash)
	if err != nil {
		return SyntheticRun{}, err
	}
	if err = research.VerifyEvaluationContent(m, content); err != nil {
		return SyntheticRun{}, err
	}
	ref, err := s.researchWrite(ctx, "research.run", key, manifestHash, func(tx *sql.Tx) (string, error) {
		id := id()
		if _, e := tx.ExecContext(ctx, "INSERT INTO research_runs VALUES(?,?,?,'preparing','unvalidated')", id, manifestHash, m.ProjectID); e != nil {
			return "", e
		}
		return id, s.appendResearch(ctx, tx, "run_created", id, manifestHash)
	})
	if err != nil {
		return SyntheticRun{}, err
	}
	return s.SyntheticRun(ctx, ref)
}

func (s *Store) SyntheticRun(ctx context.Context, id string) (SyntheticRun, error) {
	s.researchMu.Lock()
	defer s.researchMu.Unlock()
	var r SyntheticRun
	if err := s.verifyResearchLedger(ctx); err != nil {
		return r, err
	}
	err := s.db.QueryRowContext(ctx, "SELECT id,manifest_hash,project_id,status,validation_status FROM research_runs WHERE id=?", id).Scan(&r.ID, &r.ManifestHash, &r.ProjectID, &r.Status, &r.ValidationStatus)
	if errors.Is(err, sql.ErrNoRows) {
		err = ErrNotFound
	}
	return r, err
}

// These are synthetic ledger bindings, NOT authentication tokens or OS grants.
type SyntheticClaimRequest struct {
	RunID        string `json:"run_id"`
	PartitionID  string `json:"partition_id"`
	Actor        string `json:"actor"`
	PolicyHash   string `json:"policy_hash"`
	ManifestHash string `json:"manifest_hash"`
}
type SyntheticClaimProof struct {
	SyntheticClaimRequest
	ClaimID string `json:"claim_id"`
	Fence   int64  `json:"fence"`
}
type SyntheticClaim struct {
	Proof      SyntheticClaimProof `json:"proof"`
	Status     string              `json:"status"`
	OutputHash string              `json:"output_hash"`
	Recipient  string              `json:"recipient"`
}

func loadClaim(ctx context.Context, q rowQuery, id string) (SyntheticClaim, error) {
	var c SyntheticClaim
	err := q.QueryRowContext(ctx, "SELECT id,run_id,partition_id,actor,policy_hash,manifest_hash,fence,status,output_hash,recipient FROM research_claims WHERE id=?", id).Scan(&c.Proof.ClaimID, &c.Proof.RunID, &c.Proof.PartitionID, &c.Proof.Actor, &c.Proof.PolicyHash, &c.Proof.ManifestHash, &c.Proof.Fence, &c.Status, &c.OutputHash, &c.Recipient)
	if errors.Is(err, sql.ErrNoRows) {
		err = ErrNotFound
	}
	return c, err
}

func researchIdentifier(s string) bool {
	if len(s) < 3 || len(s) > 128 {
		return false
	}
	for i, c := range s {
		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' {
			continue
		}
		if i > 0 && (c == '-' || c == '_' || c == '.' || c == ':') {
			continue
		}
		return false
	}
	return true
}

func digestOK(s string) bool {
	if len(s) != 64 || s == strings.Repeat("0", 64) {
		return false
	}
	for _, c := range s {
		if !(c >= 'a' && c <= 'f' || c >= '0' && c <= '9') {
			return false
		}
	}
	return true
}

func (s *Store) ClaimSyntheticEvaluation(ctx context.Context, req SyntheticClaimRequest, key string) (SyntheticClaim, error) {
	if !researchIdentifier(req.Actor) || !researchIdentifier(req.RunID) || !researchIdentifier(req.PartitionID) || !digestOK(req.PolicyHash) || !digestOK(req.ManifestHash) {
		return SyntheticClaim{}, ErrInvalid
	}
	ref, err := s.researchWrite(ctx, "research.claim", key, req, func(tx *sql.Tx) (string, error) {
		var runManifest, status string
		if e := tx.QueryRowContext(ctx, "SELECT manifest_hash,status FROM research_runs WHERE id=?", req.RunID).Scan(&runManifest, &status); e != nil {
			return "", e
		}
		if runManifest != req.ManifestHash || status != "preparing" {
			return "", ErrConflict
		}
		m, e := loadManifest(ctx, tx, req.ManifestHash)
		if e != nil {
			return "", e
		}
		if m.PolicySHA256 != req.PolicyHash || m.Partition.ID != req.PartitionID {
			return "", ErrConflict
		}
		p, e := loadPartition(ctx, tx, req.PartitionID)
		if e != nil {
			return "", e
		}
		if p.Partition != m.Partition {
			return "", ErrConflict
		}
		if !p.Partition.MappingKnown {
			return "", research.ErrContinuityUnknown
		}
		all, e := loadPartitions(ctx, tx)
		if e != nil {
			return "", e
		}
		for _, other := range all {
			if !other.Partition.MappingKnown || other.Exposure.Continuity != "verified" {
				return "", research.ErrContinuityUnknown
			}
			if !other.Exposure.AccessPossible {
				continue
			}
			overlap, e := research.Overlaps(p.Partition, other.Partition)
			if e != nil {
				return "", e
			}
			if overlap {
				return "", research.ErrExposureConflict
			}
		}
		x := p.Exposure
		if x.State == "unseen" {
			x, e = research.ApplyExposure(x, "preflight")
			if e != nil {
				return "", e
			}
			if e = saveExposure(ctx, tx, req.PartitionID, x); e != nil {
				return "", e
			}
			if e = s.appendResearch(ctx, tx, "preflight", req.PartitionID, x); e != nil {
				return "", e
			}
		}
		x, e = research.ApplyExposure(x, "access_intent")
		if e != nil {
			return "", e
		}
		if e = saveExposure(ctx, tx, req.PartitionID, x); e != nil {
			return "", e
		}
		cid := id()
		if _, e = tx.ExecContext(ctx, "INSERT INTO research_claims(id,run_id,partition_id,actor,policy_hash,manifest_hash,fence,status,output_hash,recipient) VALUES(?,?,?,?,?,?,?,'active','','')", cid, req.RunID, req.PartitionID, req.Actor, req.PolicyHash, req.ManifestHash, x.Fence); e != nil {
			return "", e
		}
		if _, e = tx.ExecContext(ctx, "UPDATE research_runs SET status='running' WHERE id=?", req.RunID); e != nil {
			return "", e
		}
		return cid, s.appendResearch(ctx, tx, "access_intent", cid, SyntheticClaimProof{SyntheticClaimRequest: req, ClaimID: cid, Fence: x.Fence})
	})
	if err != nil {
		return SyntheticClaim{}, err
	}
	return loadClaim(ctx, s.db, ref)
}

func checkClaim(ctx context.Context, q rowQuery, proof SyntheticClaimProof) (SyntheticClaim, error) {
	c, err := loadClaim(ctx, q, proof.ClaimID)
	if err != nil {
		return c, err
	}
	if c.Proof != proof || c.Status != "active" {
		return c, ErrConflict
	}
	p, err := loadPartition(ctx, q, proof.PartitionID)
	if err != nil {
		return c, err
	}
	if p.Exposure.Continuity != "verified" || p.Exposure.Fence != proof.Fence || p.Exposure.State != "evaluation_active" && p.Exposure.State != "inspected" {
		return c, ErrConflict
	}
	return c, nil
}

func (s *Store) CheckSyntheticClaim(ctx context.Context, proof SyntheticClaimProof) error {
	s.researchMu.Lock()
	defer s.researchMu.Unlock()
	if err := s.ensureResearchContinuity(ctx); err != nil {
		return err
	}
	_, err := checkClaim(ctx, s.db, proof)
	return err
}

// outputHash/recipient bind the release intent. Only a local synthetic viewer
// exists here; this method sends no content and launches no process.
func (s *Store) RecordSyntheticClaim(ctx context.Context, proof SyntheticClaimProof, event, outputHash, recipient, key string) error {
	if event != "value_access" && event != "release_intent" && event != "release_ack" {
		return ErrInvalid
	}
	if event == "value_access" {
		if outputHash != "" || recipient != "" {
			return ErrInvalid
		}
	} else if !digestOK(outputHash) || recipient != "synthetic-viewer" {
		return ErrInvalid
	}
	_, err := s.researchWrite(ctx, "research.claim_event", key, []any{proof, event, outputHash, recipient}, func(tx *sql.Tx) (string, error) {
		c, e := loadClaim(ctx, tx, proof.ClaimID)
		if e != nil {
			return "", e
		}
		if c.Proof != proof {
			return "", ErrConflict
		}
		p, e := loadPartition(ctx, tx, proof.PartitionID)
		if e != nil {
			return "", e
		}
		if p.Exposure.Fence != proof.Fence || p.Exposure.Continuity != "verified" {
			return "", ErrConflict
		}
		if event == "release_ack" {
			if c.Status != "releasing" || p.Exposure.State != "consumed" || c.OutputHash != outputHash || c.Recipient != recipient {
				return "", ErrConflict
			}
			if _, e = tx.ExecContext(ctx, "UPDATE research_claims SET status='finished' WHERE id=?", proof.ClaimID); e != nil {
				return "", e
			}
			if _, e = tx.ExecContext(ctx, "UPDATE research_runs SET status='succeeded' WHERE id=?", proof.RunID); e != nil {
				return "", e
			}
		} else {
			if _, e = checkClaim(ctx, tx, proof); e != nil {
				return "", e
			}
			x, e := research.ApplyExposure(p.Exposure, event)
			if e != nil {
				return "", e
			}
			if e = saveExposure(ctx, tx, proof.PartitionID, x); e != nil {
				return "", e
			}
			if event == "release_intent" {
				if _, e = tx.ExecContext(ctx, "UPDATE research_claims SET status='releasing',output_hash=?,recipient=? WHERE id=?", outputHash, recipient, proof.ClaimID); e != nil {
					return "", e
				}
			}
		}
		return proof.ClaimID, s.appendResearch(ctx, tx, event, proof.ClaimID, []any{proof, outputHash, recipient})
	})
	return err
}

type SyntheticCandidate struct {
	ID        string `json:"id"`
	ProjectID string `json:"project_id"`
	FamilyID  string `json:"family_id"`
	ParentID  string `json:"parent_id"`
	Reason    string `json:"reason"`
}

func (s *Store) RegisterSyntheticCandidate(ctx context.Context, c SyntheticCandidate, key string) error {
	if !researchIdentifier(c.ID) || !researchIdentifier(c.ProjectID) || !researchIdentifier(c.FamilyID) || strings.TrimSpace(c.Reason) == "" || len(c.Reason) > 2048 {
		return ErrInvalid
	}
	_, err := s.researchWrite(ctx, "research.candidate", key, c, func(tx *sql.Tx) (string, error) {
		if c.ParentID != "" {
			var family string
			if e := tx.QueryRowContext(ctx, "SELECT family_id FROM research_candidates WHERE id=?", c.ParentID).Scan(&family); e != nil {
				return "", e
			}
			if family != c.FamilyID {
				return "", ErrConflict
			}
		}
		b, e := json.Marshal(c)
		if e != nil {
			return "", e
		}
		if _, e = tx.ExecContext(ctx, "INSERT INTO research_candidates VALUES(?,?,?,?,?)", c.ID, c.ProjectID, c.FamilyID, nullString(c.ParentID), string(b)); e != nil {
			return "", e
		}
		return c.ID, s.appendResearch(ctx, tx, "candidate_registered", c.ID, c)
	})
	return err
}

func (s *Store) RecordSyntheticCandidateOutcome(ctx context.Context, candidate, outcome, reason, key string) error {
	if outcome != "failed" && outcome != "rejected" && outcome != "selected" {
		return ErrInvalid
	}
	if strings.TrimSpace(reason) == "" || len(reason) > 2048 {
		return ErrInvalid
	}
	_, err := s.researchWrite(ctx, "research.candidate_outcome", key, []string{candidate, outcome, reason}, func(tx *sql.Tx) (string, error) {
		var id string
		if e := tx.QueryRowContext(ctx, "SELECT id FROM research_candidates WHERE id=?", candidate).Scan(&id); e != nil {
			return "", e
		}
		var count int
		if e := tx.QueryRowContext(ctx, "SELECT count(*) FROM research_ledger WHERE kind='candidate_outcome' AND aggregate_id=?", candidate).Scan(&count); e != nil {
			return "", e
		}
		if count != 0 {
			return "", ErrConflict
		}
		return id, s.appendResearch(ctx, tx, "candidate_outcome", id, []string{outcome, reason})
	})
	return err
}
