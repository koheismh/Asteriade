package store

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
)

// Fixed columns, primary-key order and explicit nullable-string encoding bind
// the materialized state to the append-only history. Research receipts are
// included because replacing a replay result can otherwise change a grant.
// Generic events/outbox delivery state are not research authority.
func researchProjectionHash(ctx context.Context, q interface {
	QueryContext(context.Context, string, ...any) (*sql.Rows, error)
}) (digest string, empty bool, err error) {
	h := sha256.New()
	enc := json.NewEncoder(h)
	if err = enc.Encode("asteriade/synthetic-projection-v1"); err != nil {
		return "", false, err
	}
	empty = true
	for _, query := range []string{
		"SELECT id,descriptor,exposure,version FROM research_partitions ORDER BY id",
		"SELECT identity_hash,project_id,parent_hash,manifest FROM research_manifests ORDER BY identity_hash",
		"SELECT id,manifest_hash,project_id,status,validation_status FROM research_runs ORDER BY id",
		"SELECT id,run_id,partition_id,actor,policy_hash,manifest_hash,fence,status,output_hash,recipient FROM research_claims ORDER BY id",
		"SELECT id,project_id,family_id,parent_id,record FROM research_candidates ORDER BY id",
		"SELECT scope,request_key,body_hash,result_ref,status FROM request_receipts WHERE scope GLOB 'research.*' ORDER BY scope,request_key",
	} {
		if err = enc.Encode(query); err != nil {
			return "", false, err
		}
		rows, err := q.QueryContext(ctx, query)
		if err != nil {
			return "", false, err
		}
		columns, err := rows.Columns()
		if err != nil {
			rows.Close()
			return "", false, err
		}
		for rows.Next() {
			empty = false
			values := make([]sql.NullString, len(columns))
			targets := make([]any, len(columns))
			for i := range targets {
				targets[i] = &values[i]
			}
			if err = rows.Scan(targets...); err != nil {
				rows.Close()
				return "", false, err
			}
			if err = enc.Encode(values); err != nil {
				rows.Close()
				return "", false, err
			}
		}
		err = rows.Err()
		closeErr := rows.Close()
		if err != nil {
			return "", false, err
		}
		if closeErr != nil {
			return "", false, closeErr
		}
	}
	return "sha256:" + hex.EncodeToString(h.Sum(nil)), empty, nil
}
