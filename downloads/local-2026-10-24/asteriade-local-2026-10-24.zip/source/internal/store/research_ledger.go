package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"

	"github.com/koheismh/Asteriade/internal/privatefs"
	"github.com/koheismh/Asteriade/internal/research"
)

type ResearchCheckpoint struct {
	Epoch      string `json:"epoch"`
	Sequence   int64  `json:"sequence"`
	HeadHash   string `json:"head_hash"`
	Continuity string `json:"continuity"`
}

type ledgerEntry struct {
	Sequence     int64  `json:"sequence"`
	Kind         string `json:"kind"`
	Aggregate    string `json:"aggregate"`
	Payload      string `json:"payload"`
	PreviousHash string `json:"previous_hash"`
}

func checkpoint(ctx context.Context, q interface {
	QueryRowContext(context.Context, string, ...any) *sql.Row
}) (ResearchCheckpoint, error) {
	var c ResearchCheckpoint
	err := q.QueryRowContext(ctx, "SELECT epoch,sequence,head_hash,continuity FROM research_meta WHERE id=1").Scan(&c.Epoch, &c.Sequence, &c.HeadHash, &c.Continuity)
	return c, err
}

func (s *Store) ResearchCheckpoint(ctx context.Context) (ResearchCheckpoint, error) {
	return checkpoint(ctx, s.db)
}

func (s *Store) readWitness() (ResearchCheckpoint, error) {
	var c ResearchCheckpoint
	if err := privatefs.CheckFile(s.researchWitness); err != nil {
		return c, err
	}
	info, err := os.Stat(s.researchWitness)
	if err != nil {
		return c, err
	}
	if info.Size() > 4096 {
		return c, ErrInvalid
	}
	b, err := os.ReadFile(s.researchWitness)
	if err != nil {
		return c, err
	}
	err = json.Unmarshal(b, &c)
	return c, err
}

// This local witness detects ordinary DB-only restore/missing history. It is
// not a trusted monotonic clock or protection against a full disk rollback.
func (s *Store) writeWitness(ctx context.Context) error {
	c, err := checkpoint(ctx, s.db)
	if err != nil {
		return err
	}
	if _, err = os.Lstat(s.researchWitness); err == nil {
		if err = privatefs.CheckFile(s.researchWitness); err != nil {
			return err
		}
	} else if !errors.Is(err, os.ErrNotExist) {
		return err
	}
	b, err := json.Marshal(c)
	if err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(s.researchWitness), ".research-witness-*")
	if err != nil {
		return err
	}
	temp := f.Name()
	defer os.Remove(temp)
	if _, err = f.Write(b); err == nil {
		err = f.Sync()
	}
	closeErr := f.Close()
	if err != nil {
		return err
	}
	if closeErr != nil {
		return closeErr
	}
	if err = os.Rename(temp, s.researchWitness); err != nil {
		return err
	}
	if runtime.GOOS != "windows" {
		d, e := os.Open(filepath.Dir(s.researchWitness))
		if e != nil {
			return e
		}
		e = d.Sync()
		ce := d.Close()
		if e != nil {
			return e
		}
		return ce
	}
	return nil
}

func (s *Store) ensureResearchContinuity(ctx context.Context) error {
	c, err := checkpoint(ctx, s.db)
	if err != nil {
		return err
	}
	w, err := s.readWitness()
	if err != nil || w != c || c.Continuity != "verified" {
		return research.ErrContinuityUnknown
	}
	return s.verifyResearchLedger(ctx)
}

func (s *Store) appendResearch(ctx context.Context, tx *sql.Tx, kind, aggregate string, payload any) error {
	c, err := checkpoint(ctx, tx)
	if err != nil {
		return err
	}
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	e := ledgerEntry{Sequence: c.Sequence + 1, Kind: kind, Aggregate: aggregate, Payload: string(b), PreviousHash: c.HeadHash}
	encoded, err := json.Marshal(e)
	if err != nil {
		return err
	}
	h := hash(encoded)
	if _, err = tx.ExecContext(ctx, "INSERT INTO research_ledger VALUES(?,?,?,?,?,?)", e.Sequence, e.Kind, e.Aggregate, e.Payload, e.PreviousHash, h); err != nil {
		return err
	}
	if _, err = tx.ExecContext(ctx, "UPDATE research_meta SET sequence=?,head_hash=? WHERE id=1", e.Sequence, h); err != nil {
		return err
	}
	return s.event(ctx, tx, "", "research."+kind, aggregate, e.Sequence, string(b))
}

func (s *Store) verifyResearchLedger(ctx context.Context) error {
	c, err := checkpoint(ctx, s.db)
	if err != nil {
		return err
	}
	rows, err := s.db.QueryContext(ctx, "SELECT sequence,kind,aggregate_id,payload,previous_hash,entry_hash FROM research_ledger ORDER BY sequence")
	if err != nil {
		return err
	}
	defer rows.Close()
	var seq int64
	var last ledgerEntry
	head := hash([]byte("asteriade/synthetic-ledger-v1"))
	for rows.Next() {
		var e ledgerEntry
		var h string
		if err = rows.Scan(&e.Sequence, &e.Kind, &e.Aggregate, &e.Payload, &e.PreviousHash, &h); err != nil {
			return err
		}
		b, err := json.Marshal(e)
		if err != nil {
			return err
		}
		if e.Sequence != seq+1 || e.PreviousHash != head || hash(b) != h {
			return research.ErrContinuityUnknown
		}
		seq = e.Sequence
		head = h
		last = e
	}
	if err = rows.Err(); err != nil {
		return err
	}
	if seq != c.Sequence || head != c.HeadHash {
		return research.ErrContinuityUnknown
	}
	// Release the single database connection before reading the projections.
	if err = rows.Close(); err != nil {
		return err
	}
	digest, empty, err := researchProjectionHash(ctx, s.db)
	if err != nil {
		return err
	}
	if seq == 0 {
		if !empty {
			return research.ErrContinuityUnknown
		}
		return nil
	}
	var recorded string
	if last.Kind != "state_checkpoint" || json.Unmarshal([]byte(last.Payload), &recorded) != nil || recorded != digest {
		return research.ErrContinuityUnknown
	}
	return nil
}

func (s *Store) commitResearch(ctx context.Context, tx *sql.Tx) error {
	// Seal the final projection AND receipt state, in the same transaction.
	// Nothing may mutate research authority after this entry is appended.
	digest, _, err := researchProjectionHash(ctx, tx)
	if err != nil {
		return err
	}
	if err = s.appendResearch(ctx, tx, "state_checkpoint", "synthetic-registry", digest); err != nil {
		return err
	}
	if err := tx.Commit(); err != nil {
		return err
	}
	if err := s.writeWitness(ctx); err != nil {
		return fmt.Errorf("research commit durable but witness unavailable: %w", err)
	}
	return nil
}

// No-op write obtains SQLite's writer reservation BEFORE overlap reads. The
// host also keeps its existing exclusive database lock / single connection.
func (s *Store) beginResearch(ctx context.Context) (*sql.Tx, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	if _, err = tx.ExecContext(ctx, "UPDATE research_meta SET sequence=sequence WHERE id=1"); err != nil {
		tx.Rollback()
		return nil, err
	}
	return tx, nil
}

func (s *Store) researchWrite(ctx context.Context, scope, key string, body any, write func(*sql.Tx) (string, error)) (string, error) {
	s.researchMu.Lock()
	defer s.researchMu.Unlock()
	if len(key) == 0 || len(key) > 128 {
		return "", ErrInvalid
	}
	b, err := json.Marshal(body)
	if err != nil {
		return "", err
	}
	if err = s.ensureResearchContinuity(ctx); err != nil {
		return "", err
	}
	tx, err := s.beginResearch(ctx)
	if err != nil {
		return "", err
	}
	defer tx.Rollback()
	ref, replay, err := s.receipt(ctx, tx, scope, key, b)
	if err != nil {
		return "", err
	}
	if replay {
		return ref, nil
	}
	result, err := write(tx)
	if err != nil {
		return "", err
	}
	if err = s.saveReceipt(ctx, tx, scope, key, ref, result); err != nil {
		return "", err
	}
	if err = s.commitResearch(ctx, tx); err != nil {
		return "", err
	}
	return result, nil
}

func (s *Store) initializeResearch(ctx context.Context) error {
	if err := s.verifyResearchLedger(ctx); err != nil {
		return err
	}
	if s.researchFresh {
		if _, err := os.Lstat(s.researchWitness); errors.Is(err, os.ErrNotExist) {
			return s.writeWitness(ctx)
		}
	}
	if err := s.ensureResearchContinuity(ctx); err != nil {
		if err = s.loseResearchContinuity(ctx); err != nil {
			return err
		}
	}
	return s.recoverSynthetic(ctx)
}

func (s *Store) loseResearchContinuity(ctx context.Context) error {
	c, err := checkpoint(ctx, s.db)
	if err != nil {
		return err
	}
	if c.Continuity == "unknown" {
		return nil
	}
	tx, err := s.beginResearch(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	parts, err := loadPartitions(ctx, tx)
	if err != nil {
		return err
	}
	for _, p := range parts {
		x, err := research.ApplyExposure(p.Exposure, "continuity_lost")
		if err != nil {
			return err
		}
		if err = saveExposure(ctx, tx, p.Partition.ID, x); err != nil {
			return err
		}
	}
	for _, q := range []string{"UPDATE research_meta SET continuity='unknown' WHERE id=1", "UPDATE research_claims SET status='outcome_unknown' WHERE status IN ('active','releasing')", "UPDATE research_runs SET status='outcome_unknown' WHERE status IN ('running','preparing')"} {
		if _, err = tx.ExecContext(ctx, q); err != nil {
			return err
		}
	}
	if err = s.appendResearch(ctx, tx, "continuity_lost", c.Epoch, struct {
		Reason string `json:"reason"`
	}{"missing or mismatched local witness; independent evaluation blocked"}); err != nil {
		return err
	}
	return s.commitResearch(ctx, tx)
}

func (s *Store) recoverSynthetic(ctx context.Context) error {
	tx, err := s.beginResearch(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	rows, err := tx.QueryContext(ctx, "SELECT id,partition_id,run_id FROM research_claims WHERE status IN ('active','releasing') ORDER BY id")
	if err != nil {
		return err
	}
	type pending struct{ ID, Partition, Run string }
	var claims []pending
	for rows.Next() {
		var c pending
		if err = rows.Scan(&c.ID, &c.Partition, &c.Run); err != nil {
			rows.Close()
			return err
		}
		claims = append(claims, c)
	}
	err = rows.Err()
	rows.Close()
	if err != nil {
		return err
	}
	if len(claims) == 0 {
		return nil
	}
	for _, c := range claims {
		p, err := loadPartition(ctx, tx, c.Partition)
		if err != nil {
			return err
		}
		x, err := research.ApplyExposure(p.Exposure, "recover")
		if err != nil {
			return err
		}
		if err = saveExposure(ctx, tx, c.Partition, x); err != nil {
			return err
		}
		if _, err = tx.ExecContext(ctx, "UPDATE research_claims SET status='outcome_unknown' WHERE id=?", c.ID); err != nil {
			return err
		}
		if _, err = tx.ExecContext(ctx, "UPDATE research_runs SET status='outcome_unknown' WHERE id=?", c.Run); err != nil {
			return err
		}
		if err = s.appendResearch(ctx, tx, "recovered", c.ID, x); err != nil {
			return err
		}
	}
	return s.commitResearch(ctx, tx)
}
