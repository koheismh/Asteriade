package research

import (
	"errors"
	"fmt"
	"time"
)

var (
	ErrRegistryInvalid   = errors.New("research registry: invalid input")
	ErrExposureConflict  = errors.New("research registry: exposure conflict")
	ErrContinuityUnknown = errors.New("research registry: continuity unknown")
)

// SyntheticPartition describes the underlying information interval, including
// feature/label horizons, not merely displayed bar timestamps. MappingKnown is
// a fixture assertion; it is not a proof of real-market independence.
type SyntheticPartition struct {
	ID               string    `json:"id"`
	DatasetSHA256    string    `json:"dataset_sha256"`
	DataOrigin       string    `json:"data_origin"`
	Venue            string    `json:"venue"`
	Product          string    `json:"product"`
	Base             string    `json:"base"`
	Quote            string    `json:"quote"`
	LineageID        string    `json:"lineage_id"`
	Start            time.Time `json:"start"`
	End              time.Time `json:"end"`
	TimeframeSeconds int64     `json:"timeframe_seconds"`
	Role             string    `json:"role"`
	MappingKnown     bool      `json:"mapping_known"`
}

func (p SyntheticPartition) Validate() error {
	if !validID(p.ID) || !validID(p.LineageID) || !validSHA256(p.DatasetSHA256) || p.DataOrigin != SyntheticEnvironment ||
		p.Venue != "synthetic" || p.Product != "spot" || p.Base != "TOY" || p.Quote != "CASH" ||
		!registryTime(p.Start) || !registryTime(p.End) || !p.Start.Before(p.End) || p.TimeframeSeconds <= 0 ||
		(p.Role != "development" && p.Role != "validation" && p.Role != "holdout") {
		return ErrRegistryInvalid
	}
	return nil
}

func registryTime(t time.Time) bool {
	return !t.IsZero() && t.Location() == time.UTC && t.Year() >= 2000 && t.Year() < 2100
}

func PartitionSHA256(p SyntheticPartition) (string, error) {
	if err := p.Validate(); err != nil {
		return "", err
	}
	return hashValue(p)
}

// Overlaps deliberately ignores revision hash, project, lineage ID and bar
// size: relabelling the same information cannot erase exposure. Unknown
// mapping never establishes independence, even if the labels differ.
func Overlaps(a, b SyntheticPartition) (bool, error) {
	if err := a.Validate(); err != nil {
		return false, err
	}
	if err := b.Validate(); err != nil {
		return false, err
	}
	if !a.MappingKnown || !b.MappingKnown {
		return false, ErrContinuityUnknown
	}
	return a.Venue == b.Venue && a.Product == b.Product && a.Base == b.Base && a.Quote == b.Quote &&
		a.Start.Before(b.End) && b.Start.Before(a.End), nil
}

type Exposure struct {
	State          string `json:"state"`
	Continuity     string `json:"continuity"`
	AccessPossible bool   `json:"access_possible"`
	ResultReleased bool   `json:"result_released"`
	Fence          int64  `json:"fence"`
	Version        int64  `json:"version"`
}

func NewExposure() Exposure { return Exposure{State: "unseen", Continuity: "verified", Version: 1} }

func (x Exposure) Validate() error {
	states := map[string]bool{"unseen": true, "preflight": true, "evaluation_active": true, "inspected": true, "consumed": true, "defect_review": true, "corrected_analysis": true, "retired": true}
	if !states[x.State] || (x.Continuity != "verified" && x.Continuity != "unknown") || x.Version < 1 || x.Fence < 0 ||
		(x.ResultReleased && !x.AccessPossible) || ((x.State == "unseen" || x.State == "preflight") && x.AccessPossible) ||
		(x.State != "unseen" && x.State != "preflight" && x.State != "retired" && !x.AccessPossible) ||
		((x.State == "consumed" || x.State == "corrected_analysis") && !x.ResultReleased) {
		return ErrRegistryInvalid
	}
	return nil
}

// ApplyExposure is a pure reducer. Its access_intent is committed before any
// future broker could read values; it already counts as possible exposure.
func ApplyExposure(x Exposure, event string) (Exposure, error) {
	if err := x.Validate(); err != nil {
		return x, err
	}
	y := x
	if event != "continuity_lost" && x.Continuity != "verified" {
		return x, ErrContinuityUnknown
	}
	switch event {
	case "preflight":
		if x.State != "unseen" {
			return x, ErrExposureConflict
		}
		y.State = "preflight"
	case "preflight_failed":
		if x.State != "preflight" || x.AccessPossible {
			return x, ErrExposureConflict
		}
		y.State = "unseen"
	case "access_intent":
		if x.State != "preflight" || x.AccessPossible {
			return x, ErrExposureConflict
		}
		y.State = "evaluation_active"
		y.AccessPossible = true
		y.Fence++
	case "value_access":
		if x.State != "evaluation_active" {
			return x, ErrExposureConflict
		}
		y.State = "inspected"
	case "release_intent":
		if x.State != "inspected" {
			return x, ErrExposureConflict
		}
		y.State = "consumed"
		y.ResultReleased = true
	case "defect":
		if x.State != "evaluation_active" && x.State != "inspected" && x.State != "consumed" {
			return x, ErrExposureConflict
		}
		y.State = "defect_review"
	case "corrected":
		if x.State != "defect_review" || !x.ResultReleased {
			return x, ErrExposureConflict
		}
		y.State = "corrected_analysis"
	case "recover":
		if !x.AccessPossible {
			return x, ErrExposureConflict
		}
		y.Fence++
	case "retire":
		if x.State == "retired" {
			return x, ErrExposureConflict
		}
		y.State = "retired"
		y.Fence++
	case "continuity_lost":
		if x.Continuity == "unknown" {
			return x, ErrExposureConflict
		}
		y.Continuity = "unknown"
		y.Fence++
	default:
		return x, fmt.Errorf("%w: unknown exposure event", ErrRegistryInvalid)
	}
	y.Version++
	if err := y.Validate(); err != nil {
		return x, err
	}
	return y, nil
}
