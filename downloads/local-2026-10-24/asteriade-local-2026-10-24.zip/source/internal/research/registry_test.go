package research

import (
	"errors"
	"strings"
	"testing"
	"time"
)

func partitionFixture() SyntheticPartition {
	start := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	return SyntheticPartition{ID: "partition-a", DatasetSHA256: strings.Repeat("a", 64), DataOrigin: "synthetic", Venue: "synthetic", Product: "spot", Base: "TOY", Quote: "CASH", LineageID: "lineage-a", Start: start, End: start.Add(2 * time.Hour), TimeframeSeconds: 3600, Role: "holdout", MappingKnown: true}
}

func TestUnderlyingIntervalOverlapIgnoresRevisionAndTimeframe(t *testing.T) {
	a := partitionFixture()
	b := a
	b.ID = "partition-b"
	b.DatasetSHA256 = strings.Repeat("b", 64)
	b.LineageID = "lineage-b"
	b.TimeframeSeconds = 60
	b.Start = a.Start.Add(time.Hour)
	b.End = a.End.Add(time.Hour)
	if overlap, err := Overlaps(a, b); err != nil || !overlap {
		t.Fatalf("partial overlap lost: %v %v", overlap, err)
	}
	b.Start = a.End
	if overlap, err := Overlaps(a, b); err != nil || overlap {
		t.Fatalf("half-open adjacent intervals: %v %v", overlap, err)
	}
	b.Start = a.End.Add(-500 * time.Millisecond)
	if overlap, err := Overlaps(a, b); err != nil || !overlap {
		t.Fatalf("fractional overlap lost: %v %v", overlap, err)
	}
	b.MappingKnown = false
	if _, err := Overlaps(a, b); !errors.Is(err, ErrContinuityUnknown) {
		t.Fatalf("unknown mapping: %v", err)
	}
}

func TestPartitionRejectsRealDataAndAmbiguousIdentity(t *testing.T) {
	for name, change := range map[string]func(*SyntheticPartition){
		"real data":       func(p *SyntheticPartition) { p.DataOrigin = "market" },
		"venue":           func(p *SyntheticPartition) { p.Venue = "bitbank" },
		"alias":           func(p *SyntheticPartition) { p.Base = "toy" },
		"uppercase alias": func(p *SyntheticPartition) { p.Base = "ALIAS" },
		"quote alias":     func(p *SyntheticPartition) { p.Quote = "OTHER" },
		"zero length":     func(p *SyntheticPartition) { p.End = p.Start },
		"reversed":        func(p *SyntheticPartition) { p.End = p.Start.Add(-time.Second) },
		"non utc":         func(p *SyntheticPartition) { p.Start = p.Start.In(time.FixedZone("UTC+1", 3600)) },
		"unknown role":    func(p *SyntheticPartition) { p.Role = "prospective" },
	} {
		t.Run(name, func(t *testing.T) {
			p := partitionFixture()
			change(&p)
			if p.Validate() == nil {
				t.Fatal("accepted invalid partition")
			}
		})
	}
}

func TestPreflightFailureDoesNotConsumeButGrantCannotBeUndone(t *testing.T) {
	x := NewExposure()
	for _, e := range []string{"preflight", "preflight_failed"} {
		var err error
		x, err = ApplyExposure(x, e)
		if err != nil {
			t.Fatal(err)
		}
	}
	if x.State != "unseen" || x.AccessPossible || x.ResultReleased {
		t.Fatal(x)
	}
	for _, e := range []string{"preflight", "access_intent"} {
		var err error
		x, err = ApplyExposure(x, e)
		if err != nil {
			t.Fatal(err)
		}
	}
	if x.State != "evaluation_active" || !x.AccessPossible || x.Fence != 1 {
		t.Fatal(x)
	}
	before := x
	if after, err := ApplyExposure(x, "preflight_failed"); err == nil || after != before {
		t.Fatal("grant rolled back or failed transition mutated state")
	}
	x, err := ApplyExposure(x, "recover")
	if err != nil || x.Fence != 2 || !x.AccessPossible {
		t.Fatal(x, err)
	}
}

func TestExposureRemainsMonotonicAcrossDefectCorrectionAndRetirement(t *testing.T) {
	x := NewExposure()
	for _, e := range []string{"preflight", "access_intent", "value_access", "release_intent", "defect", "corrected", "retire"} {
		old := x
		var err error
		x, err = ApplyExposure(x, e)
		if err != nil {
			t.Fatal(e, err)
		}
		if old.AccessPossible && !x.AccessPossible || old.ResultReleased && !x.ResultReleased {
			t.Fatal("exposure decreased")
		}
	}
	if x.State != "retired" || !x.ResultReleased {
		t.Fatal(x)
	}
	x, err := ApplyExposure(x, "continuity_lost")
	if err != nil {
		t.Fatal(err)
	}
	if _, err = ApplyExposure(x, "preflight"); !errors.Is(err, ErrContinuityUnknown) {
		t.Fatal(err)
	}
}

func TestInvalidExposureProjectionsAreRejected(t *testing.T) {
	for _, x := range []Exposure{{State: "unseen", Continuity: "verified", Version: 1, AccessPossible: true}, {State: "consumed", Continuity: "verified", Version: 1}, {State: "made-up", Continuity: "verified", Version: 1}, {State: "unseen", Continuity: "", Version: 1}} {
		if _, err := ApplyExposure(x, "preflight"); err == nil {
			t.Fatal("invalid projection accepted", x)
		}
	}
}
