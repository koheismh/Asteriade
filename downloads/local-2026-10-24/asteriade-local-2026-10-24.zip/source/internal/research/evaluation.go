package research

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"io/fs"
	"time"
)

const EvaluationSchemaVersion = "asteriade/synthetic-evaluation-v2"
const EvaluationCanonicalization = "asteriade/evaluation-json-v2"

// EvaluationManifest is a separate synthetic-only schema. V1 remains a
// development-only envelope. A manifest never grants OS/data permissions.
type EvaluationManifest struct {
	SchemaVersion           string             `json:"schema_version"`
	CanonicalizationVersion string             `json:"canonicalization_version"`
	ProjectID               string             `json:"project_id"`
	ResearchProgramID       string             `json:"research_program_id"`
	HypothesisID            string             `json:"hypothesis_id"`
	CycleID                 string             `json:"cycle_id"`
	ExperimentID            string             `json:"experiment_id"`
	SelectionFamilyID       string             `json:"selection_family_id"`
	StrategySpec            StrategySpec       `json:"strategy_spec"`
	StrategySpecHash        string             `json:"strategy_spec_hash"`
	Partition               SyntheticPartition `json:"partition"`
	PartitionSHA256         string             `json:"partition_sha256"`
	KernelSHA256            string             `json:"kernel_sha256"`
	CodeSHA256              string             `json:"code_sha256"`
	EnvironmentSHA256       string             `json:"environment_sha256"`
	BenchmarkSHA256         string             `json:"benchmark_sha256"`
	ProtocolSHA256          string             `json:"protocol_sha256"`
	CostSHA256              string             `json:"cost_sha256"`
	MetricsSHA256           string             `json:"metrics_sha256"`
	RequiredGatesSHA256     string             `json:"required_gates_sha256"`
	PolicySHA256            string             `json:"policy_sha256"`
	Seed                    uint64             `json:"seed"`
	FrozenAt                time.Time          `json:"frozen_at"`
	ParentIdentityHash      string             `json:"parent_identity_hash"`
	RevisionReason          string             `json:"revision_reason"`
	IdentityHash            string             `json:"identity_hash"`
}

func FreezeEvaluation(m EvaluationManifest) (EvaluationManifest, error) {
	if m.SchemaVersion != "" && m.SchemaVersion != EvaluationSchemaVersion || m.CanonicalizationVersion != "" && m.CanonicalizationVersion != EvaluationCanonicalization {
		return EvaluationManifest{}, ErrInvalidIdentity
	}
	m.SchemaVersion = EvaluationSchemaVersion
	m.CanonicalizationVersion = EvaluationCanonicalization
	m.IdentityHash = ""
	var err error
	m.StrategySpecHash, err = hashValue(m.StrategySpec)
	if err != nil {
		return EvaluationManifest{}, err
	}
	m.PartitionSHA256, err = PartitionSHA256(m.Partition)
	if err != nil {
		return EvaluationManifest{}, err
	}
	if err = validateEvaluation(m); err != nil {
		return EvaluationManifest{}, err
	}
	m.IdentityHash, err = hashValue(m)
	return m, err
}

func validateEvaluation(m EvaluationManifest) error {
	if m.SchemaVersion != EvaluationSchemaVersion || m.CanonicalizationVersion != EvaluationCanonicalization || !registryTime(m.FrozenAt) {
		return ErrInvalidIdentity
	}
	for _, id := range []string{m.ProjectID, m.ResearchProgramID, m.HypothesisID, m.CycleID, m.ExperimentID, m.SelectionFamilyID} {
		if !validID(id) {
			return ErrInvalidIdentity
		}
	}
	if err := validateStrategySpec(m.StrategySpec); err != nil {
		return err
	}
	if err := m.Partition.Validate(); err != nil {
		return err
	}
	if !m.Partition.MappingKnown || m.StrategySpec.TimeframeSeconds != m.Partition.TimeframeSeconds || m.StrategySpec.Instrument != m.Partition.Base+"-"+m.Partition.Quote {
		return ErrInvalidIdentity
	}
	for _, h := range m.ContentHashes() {
		if !validSHA256(h) {
			return ErrInvalidIdentity
		}
	}
	if m.ParentIdentityHash != "" {
		if !validSHA256(m.ParentIdentityHash) || !validLabel(m.RevisionReason, 1024) {
			return ErrInvalidIdentity
		}
	} else if m.RevisionReason != "" {
		return ErrInvalidIdentity
	}
	return nil
}

func VerifyEvaluation(m EvaluationManifest) error {
	if err := validateEvaluation(m); err != nil {
		return err
	}
	expected, err := FreezeEvaluation(m)
	if err != nil || expected.IdentityHash != m.IdentityHash || expected.StrategySpecHash != m.StrategySpecHash || expected.PartitionSHA256 != m.PartitionSHA256 {
		return ErrInvalidIdentity
	}
	return nil
}

// ContentHashes names content-addressed files required at save AND run creation.
// Canonical Spec and Partition JSON are hashed directly from typed values;
// every external code/data/policy/component definition must also be present.
func (m EvaluationManifest) ContentHashes() []string {
	return []string{m.Partition.DatasetSHA256, m.KernelSHA256, m.CodeSHA256, m.EnvironmentSHA256, m.BenchmarkSHA256, m.ProtocolSHA256, m.CostSHA256, m.MetricsSHA256, m.RequiredGatesSHA256, m.PolicySHA256, m.StrategySpec.Signal.SHA256, m.StrategySpec.Entry.SHA256, m.StrategySpec.Exit.SHA256, m.StrategySpec.Sizing.SHA256, m.StrategySpec.Risk.SHA256}
}

// VerifyEvaluationContent checks actual bytes in a caller-owned synthetic CAS.
// It is NOT a broker, permission grant, or safety check for real data. Callers
// must supply an immutable/trusted FS; a later dispatch would need revalidation.
func VerifyEvaluationContent(m EvaluationManifest, files fs.FS) error {
	if err := VerifyEvaluation(m); err != nil {
		return err
	}
	if files == nil {
		return ErrInvalidIdentity
	}
	seen := map[string]bool{}
	for _, h := range m.ContentHashes() {
		if seen[h] {
			continue
		}
		seen[h] = true
		f, err := files.Open(h)
		if err != nil {
			return fmt.Errorf("%w: missing referenced content %s", ErrInvalidIdentity, h)
		}
		info, err := f.Stat()
		if err != nil || !info.Mode().IsRegular() || info.Size() > 16<<20 {
			f.Close()
			return fmt.Errorf("%w: unsupported synthetic content", ErrInvalidIdentity)
		}
		digest := sha256.New()
		n, readErr := io.Copy(digest, io.LimitReader(f, (16<<20)+1))
		closeErr := f.Close()
		if readErr != nil || closeErr != nil || n > 16<<20 || hex.EncodeToString(digest.Sum(nil)) != h {
			return fmt.Errorf("%w: referenced content mismatch %s", ErrInvalidIdentity, h)
		}
	}
	return nil
}
