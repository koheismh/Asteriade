package research

import (
	"crypto/sha256"
	"encoding/hex"
	"io/fs"
	"testing"
	"testing/fstest"
	"time"
)

func evaluationFixture(t *testing.T) (EvaluationManifest, fstest.MapFS) {
	t.Helper()
	files := fstest.MapFS{}
	content := func(name string) string {
		b := []byte("synthetic fixture: " + name)
		h := sha256.Sum256(b)
		s := hex.EncodeToString(h[:])
		files[s] = &fstest.MapFile{Data: b, Mode: 0600}
		return s
	}
	p := partitionFixture()
	p.DatasetSHA256 = content("dataset")
	m := EvaluationManifest{ProjectID: "project-001", ResearchProgramID: "program-001", HypothesisID: "hypothesis-001", CycleID: "cycle-001", ExperimentID: "experiment-001", SelectionFamilyID: "family-001", Partition: p, Seed: 7, FrozenAt: time.Date(2026, 1, 2, 0, 0, 0, 0, time.UTC)}
	m.StrategySpec = StrategySpec{Version: StrategySpecVersion, Environment: SyntheticEnvironment, Instrument: "TOY-CASH", TimeframeSeconds: 3600, Signal: ComponentRef{content("signal")}, Entry: ComponentRef{content("entry")}, Exit: ComponentRef{content("exit")}, Sizing: ComponentRef{content("sizing")}, Risk: ComponentRef{content("risk")}}
	m.KernelSHA256 = content("kernel")
	m.CodeSHA256 = content("code")
	m.EnvironmentSHA256 = content("environment")
	m.BenchmarkSHA256 = content("benchmark")
	m.ProtocolSHA256 = content("protocol")
	m.CostSHA256 = content("cost")
	m.MetricsSHA256 = content("metrics")
	m.RequiredGatesSHA256 = content("gates")
	m.PolicySHA256 = content("policy")
	frozen, err := FreezeEvaluation(m)
	if err != nil {
		t.Fatal(err)
	}
	return frozen, files
}

func TestEvaluationFreezeBindsPartitionPolicyAndActualContent(t *testing.T) {
	m, files := evaluationFixture(t)
	if err := VerifyEvaluationContent(m, files); err != nil {
		t.Fatal(err)
	}
	again, err := FreezeEvaluation(m)
	if err != nil || again != m {
		t.Fatal("nondeterministic freeze", err)
	}
	for name, change := range map[string]func(*EvaluationManifest){
		"partition range":  func(x *EvaluationManifest) { x.Partition.End = x.Partition.End.Add(time.Second) },
		"policy":           func(x *EvaluationManifest) { x.PolicySHA256 = x.CodeSHA256 },
		"seed":             func(x *EvaluationManifest) { x.Seed++ },
		"schema":           func(x *EvaluationManifest) { x.SchemaVersion = "v999" },
		"canonicalization": func(x *EvaluationManifest) { x.CanonicalizationVersion = "rfc8785" },
		"spec hash":        func(x *EvaluationManifest) { x.StrategySpecHash = x.CodeSHA256 },
	} {
		t.Run(name, func(t *testing.T) {
			x := m
			change(&x)
			if VerifyEvaluation(x) == nil {
				t.Fatal("mutation accepted")
			}
			if VerifyEvaluation(m) != nil {
				t.Fatal("value-copy mutation changed original")
			}
		})
	}
	h := m.KernelSHA256
	old := files[h]
	files[h] = &fstest.MapFile{Data: []byte("changed kernel"), Mode: 0600}
	if VerifyEvaluationContent(m, files) == nil {
		t.Fatal("actual byte tamper accepted")
	}
	files[h] = old
	delete(files, m.PolicySHA256)
	if VerifyEvaluationContent(m, files) == nil {
		t.Fatal("missing policy accepted")
	}
	if VerifyEvaluationContent(m, fs.FS(nil)) == nil {
		t.Fatal("absent content accepted")
	}
}

func TestEvaluationRevisionAndSyntheticOnlyCompatibility(t *testing.T) {
	m, _ := evaluationFixture(t)
	v1 := fixture()
	v1.PartitionRole = "holdout"
	if _, err := Freeze(v1); err == nil {
		t.Fatal("v1 holdout restriction relaxed")
	}
	v1.PartitionRole = DevelopmentPartition
	v1.SchemaVersion = EvaluationSchemaVersion
	if _, err := Freeze(v1); err == nil {
		t.Fatal("v1 accepted v2")
	}
	for name, change := range map[string]func(*EvaluationManifest){
		"real":                    func(x *EvaluationManifest) { x.Partition.DataOrigin = "real" },
		"unknown mapping":         func(x *EvaluationManifest) { x.Partition.MappingKnown = false },
		"instrument mismatch":     func(x *EvaluationManifest) { x.StrategySpec.Instrument = "OTHER-CASH" },
		"timeframe mismatch":      func(x *EvaluationManifest) { x.Partition.TimeframeSeconds = 60 },
		"revision without reason": func(x *EvaluationManifest) { x.ParentIdentityHash = m.IdentityHash },
		"reason without parent":   func(x *EvaluationManifest) { x.RevisionReason = "fix" },
	} {
		t.Run(name, func(t *testing.T) {
			x := m
			change(&x)
			if _, err := FreezeEvaluation(x); err == nil {
				t.Fatal("invalid evaluation accepted")
			}
		})
	}
	m.ParentIdentityHash = m.IdentityHash
	m.RevisionReason = "synthetic correction"
	m.Seed++
	r, err := FreezeEvaluation(m)
	if err != nil || r.IdentityHash == r.ParentIdentityHash {
		t.Fatal("revision identity", err)
	}
}
