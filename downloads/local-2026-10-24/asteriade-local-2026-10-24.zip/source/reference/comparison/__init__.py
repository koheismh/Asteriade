"""Offline development comparisons, never a product execution adapter."""
