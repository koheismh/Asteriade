"""Small synthetic execution comparison with explicit semantic mismatches.

Backtrader is optional, loaded only from the verified local source directory
named by ASTERIADE_BACKTRADER_SOURCE. No network/install happens here.
"""

from dataclasses import asdict
from datetime import datetime, timedelta, timezone
from fractions import Fraction
import hashlib
import importlib
import json
import os
from pathlib import Path
import sys

from asteriade_synthetic.clock import BarClock, validate_fill_time
from asteriade_synthetic.spot import SpotLedger
from comparison.vectors import INITIAL_CASH, QUOTE_FEE_RATE, VECTORS


BACKTRADER_COMMIT = "b853d7c90b6721476eb5a5ea3135224e33db1f14"
BACKTRADER_ARCHIVE_SHA256 = "5683f83894999bbc3e42c528a0d943a4b7437c545dce42bb536443a61e8a7127"
BACKTRADER_TREE_SHA256 = "d6d91657f0abd4f3ac2aac9d636cbd933b95e26cd10c1e8f2136e36a780045d1"


def replay_reference(fills, mark, initial_cash=INITIAL_CASH):
    """Preflight the whole fill list before any candidate engine is invoked.

    The comparison boundary enforces long-only/inventory, cash and unique fill
    IDs through the existing reference. This is not a Backtrader sandbox.
    """
    ledger = SpotLedger(initial_cash)
    for fill in fills:
        ledger.apply_fill(fill.fill_id, fill.side, fill.quantity, fill.price, fill.fee)
        if Fraction(fill.fee) != Fraction(fill.quantity) * Fraction(fill.price) * Fraction(QUOTE_FEE_RATE):
            raise ValueError("comparison supports the fixed quote fee rate only")
    return ledger.mark(mark)


def _engine_module():
    root = Path(os.environ["ASTERIADE_BACKTRADER_SOURCE"]).resolve()
    digest = hashlib.sha256()
    paths = sorted(p for p in root.rglob("*") if p.is_file()
                   and "__pycache__" not in p.parts and p.suffix != ".pyc")
    for path in paths:
        digest.update(path.relative_to(root).as_posix().encode() + b"\0"
                      + hashlib.sha256(path.read_bytes()).digest())
    if digest.hexdigest() != BACKTRADER_TREE_SHA256:
        raise ValueError("Backtrader source tree does not match the pinned archive")
    sys.path.insert(0, str(root))
    try:
        module = importlib.import_module("backtrader")
    finally:
        sys.path.pop(0)
    if Path(module.__file__).resolve().parent != root / "backtrader":
        raise ValueError("another Backtrader module is already loaded")
    return module


def _run_orders(rows, fills, source_start):
    bt = _engine_module()

    class SyntheticFeed(bt.feed.DataBase):
        def __init__(self):
            self.row_index = 0

        def _load(self):
            if self.row_index == len(rows):
                return False
            self.lines.datetime[0] = bt.date2num(source_start + timedelta(hours=self.row_index))
            price = float(rows[self.row_index])
            for field in (self.lines.open, self.lines.high, self.lines.low, self.lines.close):
                field[0] = price
            self.lines.volume[0] = 1000
            self.lines.openinterest[0] = 0
            self.row_index += 1
            return True

    class ScheduledOrders(bt.Strategy):
        def __init__(self):
            self.executions = []
            self.trade_events = []

        def next(self):
            index = len(self) - 1
            if index < len(fills):
                fill = fills[index]
                action = self.buy if fill.side == "buy" else self.sell
                action(size=float(fill.quantity))

        def notify_order(self, order):
            if order.status == order.Completed:
                self.executions.append({
                    "size": order.executed.size,
                    "price": order.executed.price,
                    "fee": order.executed.comm,
                    "at": bt.num2date(order.executed.dt, tz=timezone.utc).replace(tzinfo=timezone.utc).isoformat(),
                })
            elif order.status in (order.Canceled, order.Margin, order.Rejected, order.Expired):
                raise RuntimeError("candidate order did not execute: " + order.getstatusname())

        def notify_trade(self, trade):
            self.trade_events.append({"size": trade.size, "pnl": trade.pnl,
                                      "pnlcomm": trade.pnlcomm, "fee": trade.commission,
                                      "closed": trade.isclosed})

    cerebro = bt.Cerebro(stdstats=False)
    cerebro.adddata(SyntheticFeed(timeframe=bt.TimeFrame.Minutes, compression=60))
    cerebro.addstrategy(ScheduledOrders)
    cerebro.broker.setcash(float(INITIAL_CASH))
    cerebro.broker.setcommission(commission=float(QUOTE_FEE_RATE),
                                 commtype=bt.CommInfoBase.COMM_PERC,
                                 stocklike=True, percabs=True, leverage=1.0)
    cerebro.broker.set_slippage_perc(0.0)
    # No cheat-on-close/open and no custom filler: use default next-bar-open.
    strategy = cerebro.run()[0]
    if len(strategy.executions) != len(fills):
        raise RuntimeError("not all scheduled orders executed")
    position = strategy.getposition()
    trade = strategy._trades[strategy.data][0][-1]
    return {
        "cash": cerebro.broker.getcash(), "quantity": position.size,
        "equity": cerebro.broker.getvalue(),
        "total_fees": sum(item["fee"] for item in strategy.executions),
        "position_cost_excluding_fee": position.size * position.price,
        "trade_pnl": trade.pnl, "trade_pnlcomm": trade.pnlcomm,
        "trade_closed": trade.isclosed,
        "closed_trade_pnlcomm": sum(event["pnlcomm"] for event in strategy.trade_events if event["closed"]),
        "executions": strategy.executions,
    }


def run_backtrader(fills, mark):
    replay_reference(fills, mark)
    # The seed row lets each requested price become the following row's open.
    # These are prescribed toy prices, not an as-of availability adapter.
    rows = [fills[0].price] + [fill.price for fill in fills] + [mark]
    return _run_orders(rows, fills, datetime(2026, 1, 1, tzinfo=timezone.utc))


def clock_negative_vector():
    bar = BarClock(datetime(2026, 1, 1, 10, tzinfo=timezone.utc),
                   datetime(2026, 1, 1, 11, tzinfo=timezone.utc),
                   datetime(2026, 1, 1, 11, 0, 2, tzinfo=timezone.utc),
                   datetime(2026, 1, 1, 11, 0, 5, tzinfo=timezone.utc))
    signal = bar.received_at
    eligible = datetime(2026, 1, 1, 12, tzinfo=timezone.utc)
    from comparison.vectors import Fill
    result = _run_orders(["10", "11", "12"],
                         (Fill("clock-buy", "buy", "1", "11", "0.011"),), bar.start)
    actual = datetime.fromisoformat(result["executions"][0]["at"])
    try:
        validate_fill_time(bar, signal, eligible, actual)
    except ValueError as error:
        reason = str(error)
    else:
        raise AssertionError("default engine unexpectedly passed the delayed-receipt clock")
    validate_fill_time(bar, signal, eligible, eligible)
    return {"published_at": bar.published_at.isoformat(), "signal_at": signal.isoformat(),
            "default_fill_at": actual.isoformat(), "first_eligible_open": eligible.isoformat(),
            "rejected_by_reference": reason,
            "engine_decision_bar_label": bar.start.isoformat()}


def main():
    output = {"engine_commit": BACKTRADER_COMMIT, "archive_sha256": BACKTRADER_ARCHIVE_SHA256,
              "tree_sha256": BACKTRADER_TREE_SHA256, "vectors": {}}
    for vector in VECTORS:
        reference = asdict(replay_reference(vector.fills, vector.mark))
        output["vectors"][vector.name] = {
            "oracle": dict(vector.expected),
            "reference": {key: str(value) for key, value in reference.items()},
            "backtrader": run_backtrader(vector.fills, vector.mark),
        }
    output["clock_negative"] = clock_negative_vector()
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
