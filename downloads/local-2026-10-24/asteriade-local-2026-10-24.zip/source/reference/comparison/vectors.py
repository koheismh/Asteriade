"""Parent-fixed literals; these expectations are not engine-generated."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Fill:
    fill_id: str
    side: str
    quantity: str
    price: str
    fee: str


@dataclass(frozen=True)
class Vector:
    name: str
    fills: tuple[Fill, ...]
    mark: str
    expected: tuple[tuple[str, str], ...]
    # Raw Backtrader Trade subtracts all entry fees, including the open part.
    expected_trade_pnlcomm: str
    expected_position_cost_excluding_fee: str
    expected_trade_closed: bool


INITIAL_CASH = "1000"
QUOTE_FEE_RATE = "0.001"
ABSOLUTE_TOLERANCE = 1e-9

VECTORS = (
    Vector("A", (
        Fill("a-buy", "buy", "2", "10", "0.02"),
        Fill("a-sell", "sell", "1", "12", "0.012"),
    ), "11", (
        ("cash", "991.968"), ("quantity", "1"),
        ("realized_net", "1.978"), ("remaining_cost_basis", "10.01"),
        ("unrealized_net", "0.99"), ("equity", "1002.968"),
        ("total_fees", "0.032"),
    ), "1.968", "10", False),
    Vector("B", (
        Fill("b-buy", "buy", "2", "10", "0.02"),
        Fill("b-sell", "sell", "2", "9", "0.018"),
    ), "9", (
        ("cash", "997.962"), ("quantity", "0"),
        ("realized_net", "-2.038"), ("remaining_cost_basis", "0"),
        ("unrealized_net", "0"), ("equity", "997.962"),
        ("total_fees", "0.038"),
    ), "-2.038", "0", True),
    Vector("C", (
        Fill("c-buy-1", "buy", "1", "10", "0.01"),
        Fill("c-buy-2", "buy", "1", "14", "0.014"),
        Fill("c-sell", "sell", "1", "15", "0.015"),
    ), "13", (
        ("cash", "990.961"), ("quantity", "1"),
        ("realized_net", "2.973"), ("remaining_cost_basis", "12.012"),
        ("unrealized_net", "0.988"), ("equity", "1003.961"),
        ("total_fees", "0.039"),
    ), "2.961", "12", False),
)
