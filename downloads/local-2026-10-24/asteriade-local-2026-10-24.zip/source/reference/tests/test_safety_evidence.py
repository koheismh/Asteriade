"""Synthetic metadata tests, never evidence of Windows isolation."""

import copy
from datetime import datetime, timedelta, timezone
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


SCRIPT = Path(__file__).resolve().parents[2] / "scripts" / "safety_evidence.py"
spec = importlib.util.spec_from_file_location("safety_evidence", SCRIPT)
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)


class SafetyEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.now = datetime.now(timezone.utc).replace(microsecond=0)
        self.bundle = evidence.template()
        profile = self.bundle["profile"]
        profile.update(os="windows", edition="Windows 11 Pro", build=26100, ubr=100, arch="amd64")
        profile["tools"] = {name: evidence.digest(("synthetic-" + name).encode()) for name in evidence.TOOLS}
        profile["identities"] = {name: f"S-1-5-21-1-2-3-{1000 + i}" for i, name in enumerate(evidence.ROLES)}
        profile["appcontainer_sid"] = "S-1-15-2-1-2-3-4-5-6-7"
        profile["policy_sha256"] = evidence.digest(b"synthetic policy")
        profile["fixture_sha256"] = evidence.digest(b"synthetic fixture")
        self.fingerprint = evidence.profile_fingerprint(profile)
        self.bundle.update(run_id="synthetic-run", started_at=self.stamp(self.now - timedelta(minutes=2)),
                           finished_at=self.stamp(self.now - timedelta(minutes=1)), profile_sha256=self.fingerprint)
        for case in self.bundle["cases"]:
            case.update(status="passed", reason="synthetic validator test only")
            for phase in ("positive", "negative"):
                obs = dict(schema=evidence.OBSERVATION_SCHEMA, run_id=self.bundle["run_id"],
                           profile_sha256=self.fingerprint, test_id=case["id"], phase=phase,
                           recorded_at=self.bundle["finished_at"], execution_id="synthetic-probe",
                           subject_role="worker", subject_sid=profile["identities"]["worker"],
                           policy_sha256=profile["policy_sha256"], procedure="synthetic metadata validation only",
                           fixture_before_sha256=profile["fixture_sha256"], fixture_after_sha256=profile["fixture_sha256"],
                           sink_received=1 if phase == "positive" else 0, remaining_processes=0,
                           result="passed", expected="synthetic expectation", observed="synthetic observation",
                           exit_code=0, os_error=0 if phase == "positive" else 5)
                name = case["id"] + "-" + phase + ".json"
                raw = json.dumps(obs).encode()
                (self.root / name).write_bytes(raw)
                case[phase] = dict(file=name, sha256=evidence.digest(raw))

    @staticmethod
    def stamp(value):
        return value.isoformat().replace("+00:00", "Z")

    def verify(self):
        return evidence.verify(self.bundle, self.root, self.fingerprint, now=self.now)

    def change_observation(self, field, value):
        ref = self.bundle["cases"][0]["negative"]
        path = self.root / ref["file"]
        obs = json.loads(path.read_text())
        obs[field] = value
        raw = json.dumps(obs).encode()
        path.write_bytes(raw)
        ref["sha256"] = evidence.digest(raw)

    def test_complete_evidence_only_requests_review(self):
        # Freeze the pre-fix canonical profile/hash contract for valid SIDs.
        self.assertEqual(self.fingerprint, "288bda61d74d6345dd2b5910ae4513facc67b098f22da54d69388f566be9ebd1")
        report = self.verify()
        self.assertEqual(report["status"], "review_required")
        self.assertFalse(report["execution_enabled"])
        self.assertEqual(report["issues"], [])

    def test_template_is_unrun_and_cannot_enable_execution(self):
        template = evidence.template()
        self.assertTrue(all(c["status"] == "unrun" and c["positive"] is None for c in template["cases"]))
        with self.assertRaises(ValueError):
            evidence.verify(template, self.root, self.fingerprint, now=self.now)

    def test_each_nonpass_and_missing_case_blocks_review(self):
        for status in ("failed", "blocked", "skipped", "unrun"):
            with self.subTest(status=status):
                self.bundle["cases"][0]["status"] = status
                report = self.verify()
                self.assertEqual(report["status"], "blocked")
                self.assertFalse(report["execution_enabled"])
        self.bundle["cases"].pop(0)
        self.assertIn("SV-16-files:missing", self.verify()["issues"])

    def test_duplicate_or_unknown_case_is_rejected(self):
        self.bundle["cases"][-1] = copy.deepcopy(self.bundle["cases"][0])
        with self.assertRaises(ValueError):
            self.verify()
        self.bundle["cases"][-1]["id"] = "invented"
        with self.assertRaises(ValueError):
            self.verify()

    def test_expected_profile_is_independent_of_bundle_claim(self):
        self.bundle["profile"]["tools"]["worker"] = evidence.digest(b"changed worker")
        self.bundle["profile_sha256"] = evidence.profile_fingerprint(self.bundle["profile"])
        with self.assertRaisesRegex(ValueError, "profile_mismatch"):
            self.verify()

    def test_platform_identity_policy_and_kernel_change_fingerprint(self):
        original = copy.deepcopy(self.bundle["profile"])
        for path, value in [(('build',), 26101), (('ubr',), 101), (('tools', 'kernel'), evidence.digest(b"new kernel")),
                            (('policy_sha256',), evidence.digest(b"new policy")),
                            (('identities', 'worker'), 'S-1-5-21-1-2-3-2000')]:
            with self.subTest(path=path):
                profile = copy.deepcopy(original)
                target = profile
                for key in path[:-1]:
                    target = target[key]
                target[path[-1]] = value
                self.assertNotEqual(evidence.profile_fingerprint(profile), self.fingerprint)
        original['identities']['worker'] = original['identities']['host']
        with self.assertRaisesRegex(ValueError, "identities_not_separated"):
            evidence.profile_fingerprint(original)

    def test_linux_or_unknown_tool_hash_cannot_be_windows_evidence(self):
        self.bundle["profile"]["os"] = "linux"
        with self.assertRaises(ValueError):
            self.verify()
        self.bundle["profile"]["os"] = "windows"
        self.bundle["profile"]["tools"]["worker"] = "0" * 64
        with self.assertRaises(ValueError):
            self.verify()

    def test_every_account_subauthority_rejects_overflow_and_noncanonical_numbers(self):
        for index in range(4):
            for value in ("4294967296", "9999999999", "01", "00", "+1", "-1", "１", "١", "1 ", " 1", "1\n", "0x1", "1e1", ""):
                with self.subTest(index=index, value=value):
                    profile = copy.deepcopy(self.bundle["profile"])
                    parts = ["1", "2", "3", "1003"]
                    parts[index] = value
                    profile["identities"]["worker"] = "S-1-5-21-" + "-".join(parts)
                    with self.assertRaisesRegex(ValueError, "invalid_account_sid"):
                        evidence.profile_fingerprint(profile)

    def test_every_appcontainer_subauthority_rejects_overflow_and_noncanonical_numbers(self):
        for index in range(7):
            for value in ("4294967296", "9999999999", "01", "00", "+1", "-1", "１", "١", "1 ", " 1", "1\n", "0x1", "1e1", ""):
                with self.subTest(index=index, value=value):
                    profile = copy.deepcopy(self.bundle["profile"])
                    parts = ["1", "2", "3", "4", "5", "6", "7"]
                    parts[index] = value
                    profile["appcontainer_sid"] = "S-1-15-2-" + "-".join(parts)
                    with self.assertRaisesRegex(ValueError, "invalid_appcontainer_sid"):
                        evidence.profile_fingerprint(profile)

    def test_same_sid_with_numeric_alias_cannot_fake_separate_identities(self):
        for alias in ("S-1-5-21-01-2-3-1000", "S-1-5-21-1-2-3-0001000"):
            profile = copy.deepcopy(self.bundle["profile"])
            profile["identities"]["worker"] = alias
            with self.assertRaisesRegex(ValueError, "invalid_account_sid"):
                evidence.profile_fingerprint(profile)

    def test_sid_uint32_boundaries_are_accepted_without_mutating_profile(self):
        for key, prefix, parts in (("identities", "S-1-5-21-", ["1", "2", "3", "1003"]),
                                   ("appcontainer_sid", "S-1-15-2-", ["1", "2", "3", "4", "5", "6", "7"])):
            for index in range(len(parts)):
                for value in ("0", "4294967295"):
                    with self.subTest(key=key, index=index, value=value):
                        profile = copy.deepcopy(self.bundle["profile"])
                        changed = parts.copy()
                        changed[index] = value
                        sid = prefix + "-".join(changed)
                        if key == "identities":
                            profile[key]["worker"] = sid
                        else:
                            profile[key] = sid
                        original = copy.deepcopy(profile)
                        self.assertEqual(len(evidence.profile_fingerprint(profile)), 64)
                        self.assertEqual(profile, original)

    def test_sid_prefix_and_subauthority_count_are_not_coerced(self):
        for key, invalid, reason in (
                ("identities", ("S-1-5-21-1-2-3", "S-1-5-21-1-2-3-4-5", "S-1-5-22-1-2-3-4", None), "invalid_account_sid"),
                ("appcontainer_sid", ("S-1-15-2-1-2-3-4-5-6", "S-1-15-2-1-2-3-4-5-6-7-8", "S-1-15-3-1-2-3-4-5-6-7", None), "invalid_appcontainer_sid")):
            for value in invalid:
                with self.subTest(key=key, value=value):
                    profile = copy.deepcopy(self.bundle["profile"])
                    if key == "identities":
                        profile[key]["worker"] = value
                    else:
                        profile[key] = value
                    with self.assertRaisesRegex(ValueError, reason):
                        evidence.profile_fingerprint(profile)

    def test_stale_future_or_reversed_time_is_rejected(self):
        for field, value in [("started_at", self.now - timedelta(hours=73)),
                             ("finished_at", self.now + timedelta(seconds=1)),
                             ("started_at", self.now)]:
            with self.subTest(field=field, value=value):
                original = self.bundle[field]
                self.bundle[field] = self.stamp(value)
                with self.assertRaises(ValueError):
                    self.verify()
                self.bundle[field] = original

    def test_positive_control_missing_or_negative_tampered(self):
        ref = self.bundle["cases"][0]["positive"]
        self.bundle["cases"][0]["positive"] = None
        with self.assertRaises(ValueError):
            self.verify()
        self.bundle["cases"][0]["positive"] = ref
        (self.root / ref["file"]).write_bytes(b"tampered evidence")
        with self.assertRaisesRegex(ValueError, "artifact_hash_mismatch"):
            self.verify()

    def test_rehashed_wrong_run_profile_phase_or_result_is_rejected(self):
        original = {p.name: p.read_bytes() for p in self.root.iterdir()}
        original_ref = copy.deepcopy(self.bundle["cases"][0]["negative"])
        for field, value in [("run_id", "other-run"), ("profile_sha256", evidence.digest(b"other")),
                             ("phase", "positive"), ("test_id", "SV-04-privacy"), ("result", "failed"),
                             ("recorded_at", self.stamp(self.now)), ("exit_code", False),
                             ("subject_sid", "S-1-5-21-1-2-3-9999"), ("policy_sha256", evidence.digest(b"wrong policy")),
                             ("fixture_before_sha256", evidence.digest(b"wrong fixture")), ("procedure", "")]:
            with self.subTest(field=field):
                ref = self.bundle["cases"][0]["negative"] = copy.deepcopy(original_ref)
                (self.root / ref["file"]).write_bytes(original[ref["file"]])
                self.change_observation(field, value)
                with self.assertRaises(ValueError):
                    self.verify()

    def test_artifact_paths_and_symlinks_are_rejected(self):
        ref = self.bundle["cases"][0]["positive"]
        original = ref["file"]
        for name in ("../escape.json", "/absolute.json", "C:secret.json", "dir/file.json", "a.json:stream"):
            with self.subTest(name=name):
                ref["file"] = name
                with self.assertRaises(ValueError):
                    self.verify()
        ref["file"] = original
        target = self.root / "link.json"
        try:
            target.symlink_to(self.root / original)
        except OSError:
            return  # Symlink creation is not assumed on Windows test accounts.
        ref["file"] = target.name
        with self.assertRaises(ValueError):
            self.verify()

    def test_network_positive_control_and_descendant_counts_are_required(self):
        for case_id, phase, field, value in [("SV-18-network", "positive", "sink_received", 0),
                                           ("SV-18-network", "negative", "sink_received", 1),
                                           ("SV-18-network", "negative", "sink_received", None),
                                           ("SV-17-tree", "negative", "remaining_processes", 1)]:
            with self.subTest(case=case_id, phase=phase):
                case = next(c for c in self.bundle["cases"] if c["id"] == case_id)
                ref = case[phase]
                path = self.root / ref["file"]
                old = path.read_bytes()
                obs = json.loads(old)
                obs[field] = value
                raw = json.dumps(obs).encode()
                path.write_bytes(raw)
                ref["sha256"] = evidence.digest(raw)
                with self.assertRaises(ValueError):
                    self.verify()
                path.write_bytes(old)
                ref["sha256"] = evidence.digest(old)

    def test_duplicate_keys_nonfinite_and_unknown_fields_are_rejected(self):
        for raw in (b'{"a":1,"a":2}', b'{"x":{"a":1,"a":2}}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                evidence.strict_json(raw)
        self.bundle["execution_enabled"] = True
        with self.assertRaises(ValueError):
            self.verify()

    def test_cli_reports_blocked_without_echoing_private_content(self):
        path = self.root / "bundle.json"
        path.write_text('{"private":"DO_NOT_ECHO_SYNTHETIC_MARKER"}')
        result = subprocess.run([sys.executable, str(SCRIPT), "--bundle", str(path), "--artifacts", str(self.root),
                                 "--expected-profile", self.fingerprint], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertNotIn("DO_NOT_ECHO_SYNTHETIC_MARKER", result.stdout + result.stderr)
        self.assertFalse(json.loads(result.stdout)["execution_enabled"])

    def test_cli_complete_bundle_still_cannot_enable_runner(self):
        path = self.root / "bundle.json"
        path.write_text(json.dumps(self.bundle))
        result = subprocess.run([sys.executable, str(SCRIPT), "--bundle", str(path), "--artifacts", str(self.root),
                                 "--expected-profile", self.fingerprint], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "review_required")
        self.assertFalse(json.loads(result.stdout)["execution_enabled"])


if __name__ == "__main__":
    unittest.main()
