"""Literal toy records; no external source, market prices, or network calls."""

from copy import deepcopy
from dataclasses import FrozenInstanceError
import hashlib
import json
import unittest

from asteriade_synthetic.quality import MAX_INPUT_BYTES, QualityError, validate_batch


def fixture():
    return {
        "schema": "synthetic-bars-v1", "source": "synthetic", "pair": "TOY-CASH",
        "timeframe_seconds": 3600, "request_start": "2026-01-01T00:00:00Z",
        "request_end": "2026-01-01T03:00:00Z", "fetched_at": "2026-01-01T04:00:00Z",
        "outcome": "ok", "revision_id": "revision-1", "bars": [
            {"start": "2026-01-01T00:00:00Z", "end": "2026-01-01T01:00:00Z",
             "published_at": "2026-01-01T01:00:02Z", "received_at": "2026-01-01T01:00:05Z",
             "open": "10", "high": "12", "low": "9", "close": "11", "volume": "2"},
            {"start": "2026-01-01T01:00:00Z", "end": "2026-01-01T02:00:00Z",
             "published_at": "2026-01-01T02:00:02Z", "received_at": "2026-01-01T02:00:05Z",
             "open": "11", "high": "13", "low": "10", "close": "12", "volume": "0"},
            {"start": "2026-01-01T02:00:00Z", "end": "2026-01-01T03:00:00Z",
             "published_at": "2026-01-01T03:00:02Z", "received_at": "2026-01-01T03:00:05Z",
             "open": "12", "high": "14", "low": "11", "close": "13", "volume": "3"},
        ],
    }


def encode(value):
    return json.dumps(value, separators=(",", ":")).encode("utf-8")


class SyntheticQualityTests(unittest.TestCase):
    def assertReason(self, reason, raw, previous=None):
        with self.assertRaises(QualityError) as raised:
            validate_batch(raw, previous)
        self.assertEqual(raised.exception.reason, reason)

    def test_complete_literals_and_raw_hash(self):
        raw = encode(fixture())
        result = validate_batch(raw)
        self.assertEqual((result.status, result.reason, result.ready), ("ready", "complete", True))
        self.assertEqual((result.records_count, result.expected_records_count), (3, 3))
        self.assertEqual(result.gaps, ())
        self.assertEqual(result.revised_timestamps, ())
        self.assertEqual(result.raw_sha256, hashlib.sha256(raw).hexdigest())
        self.assertEqual(len(result.dataset_sha256), 64)
        self.assertIsNone(result.previous_dataset_sha256)

    def test_error_outcomes_are_retryable_not_missing_data(self):
        for outcome in ("rate_limited", "transport_error"):
            with self.subTest(outcome=outcome):
                data = fixture()
                data.update(outcome=outcome, bars=[])
                result = validate_batch(encode(data), encode(fixture()))
                self.assertEqual((result.status, result.reason, result.ready), ("retryable_error", outcome, False))
                self.assertEqual(result.records_count, 0)
                self.assertEqual(result.gaps, ())
                self.assertEqual(result.revised_timestamps, ())
                self.assertIsNone(result.dataset_sha256)
                self.assertFalse(result.same_snapshot)

    def test_error_outcome_cannot_carry_records(self):
        for outcome in ("rate_limited", "transport_error"):
            data = fixture()
            data["outcome"] = outcome
            self.assertReason("error_outcome_has_bars", encode(data))

    def test_success_empty_is_distinct_from_error(self):
        data = fixture()
        data["bars"] = []
        result = validate_batch(encode(data))
        self.assertEqual((result.status, result.reason, result.ready), ("not_ready", "empty", False))
        self.assertEqual(result.gaps, ("2026-01-01T00:00:00Z", "2026-01-01T01:00:00Z", "2026-01-01T02:00:00Z"))
        self.assertIsNotNone(result.dataset_sha256)

    def test_gaps_at_start_middle_end_are_explicit(self):
        expected = ("2026-01-01T00:00:00Z", "2026-01-01T01:00:00Z", "2026-01-01T02:00:00Z")
        for missing in range(3):
            with self.subTest(missing=missing):
                data = fixture()
                del data["bars"][missing]
                result = validate_batch(encode(data))
                self.assertEqual((result.status, result.reason, result.ready), ("not_ready", "gap", False))
                self.assertEqual((result.records_count, result.expected_records_count), (2, 3))
                self.assertEqual(result.gaps, (expected[missing],))

    def test_duplicate_and_order_have_different_reasons(self):
        data = fixture()
        data["bars"].append(deepcopy(data["bars"][0]))
        self.assertReason("duplicate_bar_start", encode(data))
        data = fixture()
        data["bars"].reverse()
        self.assertReason("bars_not_ascending", encode(data))

    def test_real_source_or_pair_and_unknown_schema_rejected(self):
        for field, value, reason in (("source", "bitbank", "synthetic_identity_required"),
                                     ("pair", "BTC-JPY", "synthetic_identity_required"),
                                     ("schema", "synthetic-bars-v2", "unsupported_schema")):
            data = fixture()
            data[field] = value
            self.assertReason(reason, encode(data))

    def test_unknown_missing_and_nonobject_fields_rejected(self):
        data = fixture()
        data["provider"] = "anything"
        self.assertReason("unknown_fields", encode(data))
        data = fixture()
        data["bars"][0]["strategy_code"] = "raise RuntimeError('never execute')"
        self.assertReason("unknown_fields", encode(data))
        data = fixture()
        del data["fetched_at"]
        self.assertReason("missing_fields", encode(data))
        data = fixture()
        del data["bars"][0]["volume"]
        self.assertReason("missing_fields", encode(data))
        self.assertReason("object_required", b"[]")
        data = fixture()
        data["bars"][0] = "not an object"
        self.assertReason("object_required", encode(data))

    def test_duplicate_json_keys_at_both_levels_rejected(self):
        raw = encode(fixture())
        self.assertReason("duplicate_json_key", raw[:-1] + b',"source":"synthetic"}')
        self.assertReason("duplicate_json_key", raw.replace(b'"open":"10"', b'"open":"10","open":"10"', 1))

    def test_json_bytes_only_and_invalid_json(self):
        for raw in ("{}", {}, bytearray(b"{}"), None):
            self.assertReason("bytes_required", raw)
        for raw in (b"{", b"\xff", b"null", b"true"):
            expected = "object_required" if raw in (b"null", b"true") else "invalid_json"
            self.assertReason(expected, raw)
        self.assertReason("input_too_large", b" " * (MAX_INPUT_BYTES + 1))

    def test_bytes_subclass_cannot_run_custom_decode(self):
        class CustomBytes(bytes):
            def decode(self, *args, **kwargs):
                self.fail_if_called = True
                raise AssertionError("custom input code must not run")

        self.assertReason("bytes_required", CustomBytes(encode(fixture())))

    def test_top_level_types_are_not_coerced(self):
        for field, values, reason in (
            ("timeframe_seconds", (True, 3600.0, "3600", None, 60), "unsupported_timeframe"),
            ("revision_id", (None, 1, [], "", "x" * 129, "bad\nrevision"), "invalid_revision_id"),
            ("outcome", (None, [], 1, "unknown"), "invalid_outcome"),
            ("bars", ({}, "[]", None), "array_required"),
        ):
            for value in values:
                with self.subTest(field=field, value=value):
                    data = fixture()
                    data[field] = value
                    self.assertReason(reason, encode(data))

    def test_request_and_bar_utc_hour_boundaries(self):
        for field, value, reason in (
            ("request_start", "2026-01-01T00:01:00Z", "not_hour_boundary"),
            ("request_end", "2026-01-01T03:00:00.000001Z", "not_hour_boundary"),
            ("request_start", "2026-01-01T00:00:00", "invalid_timestamp"),
            ("request_start", "2026-01-01T09:00:00+09:00", "invalid_timestamp"),
            ("request_start", "2026-02-30T00:00:00Z", "invalid_timestamp"),
            ("request_start", 0, "invalid_timestamp"),
            ("fetched_at", None, "invalid_timestamp"),
            ("fetched_at", "2026-01-01T04:00:00.0000001Z", "invalid_timestamp"),
        ):
            data = fixture()
            data[field] = value
            self.assertReason(reason, encode(data))
        data = fixture()
        data["bars"][0]["start"] = "2026-01-01T00:00:01Z"
        self.assertReason("not_hour_boundary", encode(data))

    def test_request_range_and_limit(self):
        for end, reason in (("2026-01-01T00:00:00Z", "invalid_request_range"),
                            ("2025-12-31T23:00:00Z", "invalid_request_range"),
                            ("2028-01-01T00:00:00Z", "request_too_large")):
            data = fixture()
            data["request_end"] = end
            self.assertReason(reason, encode(data))
        data = fixture()
        data["bars"] = [data["bars"][0]] * 10001
        self.assertReason("too_many_bars", encode(data))

    def test_expected_count_exactly_10000_is_allowed(self):
        data = fixture()
        data.update(request_end="2027-02-21T16:00:00Z", bars=[])
        result = validate_batch(encode(data))
        self.assertEqual(result.expected_records_count, 10000)
        self.assertEqual(len(result.gaps), 10000)
        self.assertEqual((result.reason, result.ready), ("empty", False))
        data["request_end"] = "2027-02-21T17:00:00Z"
        self.assertReason("request_too_large", encode(data))

    def test_duration_and_out_of_range(self):
        data = fixture()
        data["bars"][0]["end"] = "2026-01-01T02:00:00Z"
        self.assertReason("invalid_bar_duration", encode(data))
        data = fixture()
        data["request_start"] = "2026-01-01T01:00:00Z"
        self.assertReason("bar_out_of_range", encode(data))
        data = fixture()
        data["request_end"] = "2026-01-01T02:00:00Z"
        self.assertReason("bar_out_of_range", encode(data))

    def test_publication_receipt_fetch_order(self):
        for field, value, reason in (
            ("published_at", "2026-01-01T00:59:59Z", "published_before_end"),
            ("received_at", "2026-01-01T01:00:01Z", "received_before_published"),
            ("received_at", "2026-01-01T04:00:01Z", "received_after_fetched"),
            ("published_at", "yesterday", "invalid_timestamp"),
        ):
            data = fixture()
            data["bars"][0][field] = value
            self.assertReason(reason, encode(data))

    def test_inclusive_clock_boundaries(self):
        data = fixture()
        data["bars"] = data["bars"][:1]
        data["request_end"] = "2026-01-01T01:00:00Z"
        data["fetched_at"] = "2026-01-01T01:00:00Z"
        data["bars"][0].update(published_at="2026-01-01T01:00:00Z", received_at="2026-01-01T01:00:00Z")
        self.assertTrue(validate_batch(encode(data)).ready)

    def test_decimal_strings_and_lengths(self):
        for value in (10, 10.0, True, None, "NaN", "Infinity", "1e1", "-1", "+1", "01", " 1", "1.", ".1", "1" * 65):
            with self.subTest(value=value):
                data = fixture()
                data["bars"][0]["open"] = value
                self.assertReason("invalid_decimal", encode(data))
        for field in ("open", "high", "low", "close"):
            data = fixture()
            data["bars"][0][field] = "0"
            self.assertReason("nonpositive_price", encode(data))
        data = fixture()
        data["bars"][0]["volume"] = "-1"
        self.assertReason("invalid_decimal", encode(data))
        data["bars"][0]["volume"] = "1" * 64
        self.assertTrue(validate_batch(encode(data)).ready)

    def test_nonfinite_json_numbers_rejected(self):
        for value in (float("nan"), float("inf"), float("-inf")):
            data = fixture()
            data["bars"][0]["open"] = value
            self.assertReason("nonfinite_json_number", encode(data))

    def test_64_character_prices_are_not_rounded_by_decimal_context(self):
        data = fixture()
        data["bars"][0].update(open="0." + "1" * 62, close="0." + "1" * 62,
                               high="0." + "2" * 62, low="0." + "0" * 61 + "1")
        previous = encode(data)
        self.assertTrue(validate_batch(previous).ready)
        data["bars"][0]["open"] = "0." + "1" * 61 + "2"
        result = validate_batch(encode(data), previous)
        self.assertEqual(result.status, "conflict")
        self.assertNotEqual(result.dataset_sha256, result.previous_dataset_sha256)

    def test_ohlc_inconsistencies(self):
        for field, value in (("high", "10"), ("low", "12"), ("open", "13"), ("close", "8")):
            data = fixture()
            data["bars"][0][field] = value
            self.assertReason("invalid_ohlc_bounds", encode(data))

    def test_retrieval_metadata_does_not_change_dataset(self):
        previous = encode(fixture())
        data = fixture()
        data["fetched_at"] = "2026-01-02T04:00:00Z"
        data["bars"][0]["received_at"] = "2026-01-02T03:00:00Z"
        current = encode(data)
        result = validate_batch(current, previous)
        self.assertNotEqual(result.raw_sha256, validate_batch(previous).raw_sha256)
        self.assertEqual(result.dataset_sha256, result.previous_dataset_sha256)
        self.assertEqual(result.revised_timestamps, ())
        self.assertTrue(result.same_snapshot)
        self.assertTrue(result.ready)

    def test_json_decimal_timestamp_representation_is_canonical(self):
        previous = encode(fixture())
        data = fixture()
        data["bars"][0]["open"] = "10.0000"
        data["request_start"] = "2026-01-01T00:00:00+00:00"
        data["bars"][0]["published_at"] = "2026-01-01T01:00:02.000000+00:00"
        current = json.dumps(data, indent=2, sort_keys=True).encode()
        result = validate_batch(current, previous)
        self.assertTrue(result.same_snapshot)
        self.assertTrue(result.ready)
        self.assertNotEqual(current, previous)

    def test_new_revision_ohlcv_and_publication_changes_require_review(self):
        previous = encode(fixture())
        for field, value in (("open", "10.5"), ("volume", "3"),
                             ("published_at", "2026-01-01T01:00:03Z")):
            data = fixture()
            data["revision_id"] = "revision-2"
            data["bars"][0][field] = value
            result = validate_batch(encode(data), previous)
            self.assertEqual((result.status, result.reason, result.ready), ("requires_review", "dataset_revision", False))
            self.assertEqual(result.revised_timestamps, ("2026-01-01T00:00:00Z",))
            self.assertNotEqual(result.dataset_sha256, result.previous_dataset_sha256)
            self.assertFalse(result.same_snapshot)

    def test_disappeared_bar_is_revision_and_gap(self):
        data = fixture()
        data["revision_id"] = "revision-2"
        del data["bars"][1]
        result = validate_batch(encode(data), encode(fixture()))
        self.assertEqual((result.status, result.reason, result.ready), ("requires_review", "dataset_revision", False))
        self.assertEqual(result.gaps, ("2026-01-01T01:00:00Z",))
        self.assertEqual(result.revised_timestamps, ("2026-01-01T01:00:00Z",))

    def test_same_revision_changed_content_is_conflict(self):
        previous = encode(fixture())
        data = fixture()
        data["bars"][0]["volume"] = "3"
        result = validate_batch(encode(data), previous)
        self.assertEqual((result.status, result.reason, result.ready), ("conflict", "revision_id_conflict", False))
        self.assertEqual(result.revised_timestamps, ("2026-01-01T00:00:00Z",))

    def test_gap_completion_has_new_snapshot_and_same_revision_conflicts(self):
        old = fixture()
        del old["bars"][1]
        previous = encode(old)
        data = fixture()
        self.assertEqual(validate_batch(encode(data), previous).status, "conflict")
        data["revision_id"] = "revision-2"
        result = validate_batch(encode(data), previous)
        self.assertTrue(result.ready)
        self.assertFalse(result.same_snapshot)
        self.assertNotEqual(result.dataset_sha256, result.previous_dataset_sha256)
        self.assertEqual(result.revised_timestamps, ())

    def test_revision_label_only_retains_same_content(self):
        data = fixture()
        data["revision_id"] = "revision-2"
        result = validate_batch(encode(data), encode(fixture()))
        self.assertTrue(result.same_snapshot)
        self.assertTrue(result.ready)

    def test_previous_is_revalidated_and_scope_must_match(self):
        current = encode(fixture())
        self.assertReason("bytes_required", current, fixture())
        self.assertReason("invalid_json", current, b"{")
        old = fixture()
        old["revision_id"] = None
        self.assertReason("invalid_revision_id", current, encode(old))
        old = fixture()
        old["bars"][0]["volume"] = "NaN"
        self.assertReason("invalid_decimal", current, encode(old))
        old = fixture()
        old["request_end"] = "2026-01-01T04:00:00Z"
        self.assertReason("previous_identity_mismatch", current, encode(old))
        old.update(outcome="rate_limited", bars=[])
        old["request_end"] = "2026-01-01T03:00:00Z"
        self.assertReason("previous_not_verified_dataset", current, encode(old))

    def test_report_is_immutable_and_has_no_permission_claim(self):
        result = validate_batch(encode(fixture()))
        with self.assertRaises(FrozenInstanceError):
            result.ready = False
        self.assertIsInstance(result.gaps, tuple)
        self.assertIsInstance(result.revised_timestamps, tuple)
        self.assertFalse(hasattr(result, "rights_valid"))
        self.assertFalse(hasattr(result, "market_profile_valid"))


if __name__ == "__main__":
    unittest.main()
