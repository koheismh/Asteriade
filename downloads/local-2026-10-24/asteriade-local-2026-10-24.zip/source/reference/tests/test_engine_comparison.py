"""Independent literals, plus an optional pinned candidate engine comparison."""

from dataclasses import replace
from datetime import datetime
from fractions import Fraction
import os
import tempfile
import unittest
from unittest.mock import patch

from comparison.engine_comparison import (
    _engine_module, clock_negative_vector, replay_reference, run_backtrader,
)
from comparison.vectors import ABSOLUTE_TOLERANCE, Fill, VECTORS


class ReferenceComparisonTests(unittest.TestCase):
    def test_parent_fixed_goldens(self):
        for vector in VECTORS:
            with self.subTest(vector=vector.name):
                actual = replay_reference(vector.fills, vector.mark)
                for field, expected in vector.expected:
                    self.assertEqual(getattr(actual, field), Fraction(expected), field)

    def test_invalid_fills_rejected_before_candidate_engine(self):
        buy = VECTORS[0].fills[0]
        cases = (
            ((Fill("too-large", "buy", "1000", "10", "10"),), "insufficient cash"),
            ((Fill("naked-sell", "sell", "1", "10", "0.01"),), "insufficient inventory"),
            ((buy, Fill("oversell", "sell", "3", "12", "0.036")), "insufficient inventory"),
            ((buy, buy), "duplicate fill_id"),
            ((replace(buy, fee="0"),), "fixed quote fee rate"),
        )
        for fills, reason in cases:
            with self.subTest(reason=reason, fills=fills), patch("comparison.engine_comparison._engine_module") as engine:
                with self.assertRaisesRegex(ValueError, reason):
                    replay_reference(fills, "11")
                with self.assertRaisesRegex(ValueError, reason):
                    run_backtrader(fills, "11")
                engine.assert_not_called()

    def test_changed_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as source:
            with patch.dict(os.environ, {"ASTERIADE_BACKTRADER_SOURCE": source}):
                with self.assertRaisesRegex(ValueError, "source tree"):
                    _engine_module()


@unittest.skipUnless(os.environ.get("ASTERIADE_BACKTRADER_SOURCE"),
                     "optional pinned Backtrader source not configured")
class BacktraderComparisonTests(unittest.TestCase):
    def assertNear(self, actual, expected):
        self.assertLessEqual(abs(actual - float(expected)), ABSOLUTE_TOLERANCE)

    def test_cash_quantity_equity_and_fees(self):
        for vector in VECTORS:
            with self.subTest(vector=vector.name):
                actual = run_backtrader(vector.fills, vector.mark)
                expected = dict(vector.expected)
                for field in ("cash", "quantity", "equity", "total_fees"):
                    self.assertNear(actual[field], expected[field])
                self.assertEqual(len(actual["executions"]), len(vector.fills))
                for execution, fill in zip(actual["executions"], vector.fills):
                    signed = float(fill.quantity) * (1 if fill.side == "buy" else -1)
                    self.assertNear(execution["size"], signed)
                    self.assertNear(execution["price"], fill.price)
                    self.assertNear(execution["fee"], fill.fee)

    def test_trade_pnl_is_not_partial_realized_net(self):
        for vector in VECTORS:
            with self.subTest(vector=vector.name):
                actual = run_backtrader(vector.fills, vector.mark)
                self.assertNear(actual["trade_pnlcomm"], vector.expected_trade_pnlcomm)
                self.assertNear(actual["position_cost_excluding_fee"], vector.expected_position_cost_excluding_fee)
                self.assertEqual(actual["trade_closed"], vector.expected_trade_closed)
                reference_realized = dict(vector.expected)["realized_net"]
                if vector.expected_trade_closed:
                    self.assertNear(actual["trade_pnlcomm"], reference_realized)
                    self.assertNear(actual["closed_trade_pnlcomm"], reference_realized)
                else:
                    self.assertGreater(abs(actual["trade_pnlcomm"] - float(reference_realized)), ABSOLUTE_TOLERANCE)
                    self.assertNear(actual["closed_trade_pnlcomm"], "0")

    def test_fractional_quantity_has_no_lot_rounding(self):
        actual = run_backtrader((Fill("fraction", "buy", "0.25", "10", "0.0025"),), "11")
        # Additional hand-calculated resolution probe; A/B/C remain unchanged.
        for field, expected in (("quantity", "0.25"), ("cash", "997.4975"),
                                ("total_fees", "0.0025"), ("equity", "1000.2475")):
            self.assertNear(actual[field], expected)

    def test_default_next_open_fails_delayed_receipt(self):
        actual = clock_negative_vector()
        self.assertEqual(actual["default_fill_at"], "2026-01-01T11:00:00+00:00")
        self.assertEqual(actual["first_eligible_open"], "2026-01-01T12:00:00+00:00")
        self.assertEqual(actual["rejected_by_reference"], "fill precedes eligibility")
        self.assertLess(datetime.fromisoformat(actual["default_fill_at"]),
                        datetime.fromisoformat(actual["signal_at"]))


if __name__ == "__main__":
    unittest.main()
