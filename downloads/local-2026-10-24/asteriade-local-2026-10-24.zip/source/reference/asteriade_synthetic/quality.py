"""Bounded, offline quality checks for synthetic JSON bytes only.

This module neither acquires data nor authorizes its release to a strategy.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal
import hashlib
import json
import re


MAX_BARS = 10_000
MAX_INPUT_BYTES = 16 * 1024 * 1024
_HOUR = timedelta(hours=1)
_DECIMAL = re.compile(r"(?:0|[1-9][0-9]*)(?:\.[0-9]+)?\Z")
_UTC = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?(?:Z|\+00:00)\Z")
_TOP_FIELDS = frozenset(("schema", "source", "pair", "timeframe_seconds", "request_start",
                         "request_end", "fetched_at", "outcome", "revision_id", "bars"))
_BAR_FIELDS = frozenset(("start", "end", "published_at", "received_at", "open", "high", "low", "close", "volume"))
_PRICE_FIELDS = ("open", "high", "low", "close", "volume")


class QualityError(ValueError):
    """Rejected input, with a stable reason code and a bounded field location."""

    def __init__(self, reason: str, location: str = ""):
        self.reason = reason
        self.location = location
        super().__init__(reason + (": " + location if location else ""))


@dataclass(frozen=True)
class QualityReport:
    status: str
    reason: str
    raw_sha256: str
    dataset_sha256: str | None
    previous_dataset_sha256: str | None
    records_count: int
    expected_records_count: int
    gaps: tuple[str, ...]
    revised_timestamps: tuple[str, ...]
    revision_id: str
    same_snapshot: bool
    ready: bool


def _stamp(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _time(value, location: str, *, boundary: bool = False) -> datetime:
    if not isinstance(value, str) or not _UTC.fullmatch(value):
        raise QualityError("invalid_timestamp", location)
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise QualityError("invalid_timestamp", location) from None
    if boundary and (result.minute or result.second or result.microsecond):
        raise QualityError("not_hour_boundary", location)
    return result


def _decimal(value, location: str, *, positive: bool) -> str:
    if not isinstance(value, str) or len(value) > 64 or not _DECIMAL.fullmatch(value):
        raise QualityError("invalid_decimal", location)
    if positive and Decimal(value) <= 0:
        raise QualityError("nonpositive_price", location)
    # String normalization avoids Decimal context rounding of 64-digit inputs.
    return value.rstrip("0").rstrip(".") if "." in value else value


def _keys(value, expected, location: str) -> None:
    if not isinstance(value, dict):
        raise QualityError("object_required", location)
    if value.keys() - expected:
        raise QualityError("unknown_fields", location)
    if expected - value.keys():
        raise QualityError("missing_fields", location)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise QualityError("duplicate_json_key")
        result[key] = value
    return result


def _nonfinite(_value):
    raise QualityError("nonfinite_json_number")


@dataclass(frozen=True)
class _Bar:
    start: datetime
    end: datetime
    published_at: datetime
    received_at: datetime
    prices: tuple[str, ...]

    def content(self) -> dict:
        return {"start": _stamp(self.start), "end": _stamp(self.end),
                "published_at": _stamp(self.published_at),
                **dict(zip(_PRICE_FIELDS, self.prices))}


@dataclass(frozen=True)
class _Batch:
    raw_sha256: str
    request_start: datetime
    request_end: datetime
    outcome: str
    revision_id: str
    bars: tuple[_Bar, ...]
    expected_count: int
    gaps: tuple[str, ...]
    dataset_sha256: str | None


def _parse(raw: bytes) -> _Batch:
    if type(raw) is not bytes:
        raise QualityError("bytes_required")
    if len(raw) > MAX_INPUT_BYTES:
        raise QualityError("input_too_large")
    try:
        data = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object, parse_constant=_nonfinite)
    except QualityError:
        raise
    except (ValueError, UnicodeDecodeError, RecursionError):
        raise QualityError("invalid_json") from None
    _keys(data, _TOP_FIELDS, "batch")
    if data["schema"] != "synthetic-bars-v1":
        raise QualityError("unsupported_schema", "schema")
    if data["source"] != "synthetic" or data["pair"] != "TOY-CASH":
        raise QualityError("synthetic_identity_required")
    if type(data["timeframe_seconds"]) is not int or data["timeframe_seconds"] != 3600:
        raise QualityError("unsupported_timeframe", "timeframe_seconds")
    start = _time(data["request_start"], "request_start", boundary=True)
    end = _time(data["request_end"], "request_end", boundary=True)
    if start >= end:
        raise QualityError("invalid_request_range")
    expected = (end - start) // _HOUR
    if expected > MAX_BARS:
        raise QualityError("request_too_large")
    fetched = _time(data["fetched_at"], "fetched_at")
    outcome = data["outcome"]
    if not isinstance(outcome, str) or outcome not in ("ok", "rate_limited", "transport_error"):
        raise QualityError("invalid_outcome", "outcome")
    revision = data["revision_id"]
    if not isinstance(revision, str) or not revision or len(revision) > 128 or any(ord(c) < 32 for c in revision):
        raise QualityError("invalid_revision_id", "revision_id")
    records = data["bars"]
    if not isinstance(records, list):
        raise QualityError("array_required", "bars")
    if len(records) > MAX_BARS:
        raise QualityError("too_many_bars", "bars")
    if outcome != "ok" and records:
        raise QualityError("error_outcome_has_bars", "bars")

    bars = []
    seen = set()
    for index, record in enumerate(records):
        location = f"bars[{index}]"
        _keys(record, _BAR_FIELDS, location)
        bar_start = _time(record["start"], location + ".start", boundary=True)
        bar_end = _time(record["end"], location + ".end", boundary=True)
        if bar_end - bar_start != _HOUR:
            raise QualityError("invalid_bar_duration", location)
        if bar_start < start or bar_end > end:
            raise QualityError("bar_out_of_range", location)
        if bar_start in seen:
            raise QualityError("duplicate_bar_start", location)
        if bars and bar_start < bars[-1].start:
            raise QualityError("bars_not_ascending", location)
        published = _time(record["published_at"], location + ".published_at")
        received = _time(record["received_at"], location + ".received_at")
        if published < bar_end:
            raise QualityError("published_before_end", location)
        if received < published:
            raise QualityError("received_before_published", location)
        if received > fetched:
            raise QualityError("received_after_fetched", location)
        prices = tuple(_decimal(record[field], location + "." + field, positive=field != "volume")
                       for field in _PRICE_FIELDS)
        open_, high, low, close, _volume = map(Decimal, prices)
        if high < max(open_, close, low) or low > min(open_, close, high):
            raise QualityError("invalid_ohlc_bounds", location)
        bars.append(_Bar(bar_start, bar_end, published, received, prices))
        seen.add(bar_start)

    # Transport/429 is not an empty dataset or a list of missing market bars.
    gaps = tuple(_stamp(start + n * _HOUR) for n in range(expected)
                 if start + n * _HOUR not in seen) if outcome == "ok" else ()
    dataset_hash = None
    if outcome == "ok":
        content = {"schema": "synthetic-bars-v1", "source": "synthetic", "pair": "TOY-CASH",
                   "timeframe_seconds": 3600, "request_start": _stamp(start), "request_end": _stamp(end),
                   "bars": [bar.content() for bar in bars]}
        canonical = json.dumps(content, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
        dataset_hash = hashlib.sha256(canonical).hexdigest()
    return _Batch(hashlib.sha256(raw).hexdigest(), start, end, outcome, revision,
                  tuple(bars), expected, gaps, dataset_hash)


def validate_batch(raw: bytes, previous: bytes | None = None) -> QualityReport:
    """Validate a toy batch and optionally compare a prior raw snapshot.

    Invalid structure/values raise QualityError. Valid but incomplete, failed,
    or revised batches return a report with ready=False. All inputs are checked
    again; no caller-supplied object is treated as previously verified state.
    """
    batch = _parse(raw)
    prior = _parse(previous) if previous is not None else None
    if prior is not None:
        if (batch.request_start, batch.request_end) != (prior.request_start, prior.request_end):
            raise QualityError("previous_identity_mismatch")
        if prior.outcome != "ok":
            raise QualityError("previous_not_verified_dataset")

    same = prior is not None and batch.dataset_sha256 is not None and batch.dataset_sha256 == prior.dataset_sha256
    revised = ()
    if prior is not None and batch.outcome == "ok":
        current = {bar.start: bar.content() for bar in batch.bars}
        revised = tuple(_stamp(bar.start) for bar in prior.bars if current.get(bar.start) != bar.content())

    if batch.outcome != "ok":
        status, reason = "retryable_error", batch.outcome
    elif prior is not None and not same and batch.revision_id == prior.revision_id:
        status, reason = "conflict", "revision_id_conflict"
    elif revised:
        status, reason = "requires_review", "dataset_revision"
    elif not batch.bars:
        status, reason = "not_ready", "empty"
    elif batch.gaps:
        status, reason = "not_ready", "gap"
    else:
        status, reason = "ready", "complete"
    return QualityReport(status, reason, batch.raw_sha256, batch.dataset_sha256,
                         prior.dataset_sha256 if prior else None, len(batch.bars), batch.expected_count,
                         batch.gaps, revised, batch.revision_id, same, status == "ready")
