# 合成入力の品質・改訂検査（2026-10-23）

**状態: PRE-04の開発用準備。正式MKT-04はBLOCKEDのまま。** 実行モデル指定は`gpt-6.1-sol`。開始HEADは`6d01d08897b4ed53de01138ee737cc6ef9deb119`、既存の未commit変更を保全した。変更は[quality.py](../../reference/asteriade_synthetic/quality.py)、[専用試験](../../reference/tests/test_quality.py)、本書の新規3ファイルだけ。

親が固定した人工データ契約について、JSONの型・品質・穴・改訂をローカルで検査する。外部通信、実source、実価格API、第三者データ、Provider、Runner、ユーザーのコード実行、ファイル保存は扱わない。[市場調査](BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)のBTC現物・1市場1ペア・1h調査前提とは別の`TOY-CASH` fixtureである。権利、market profile、Windows境界、実データ取込の合格や、strategyへデータを公開する許可を返すものではない。

## APIと入力契約

`validate_batch(raw: bytes, previous: bytes | None = None) -> QualityReport`は標準ライブラリだけを使う純粋関数。UTF-8 JSON bytesを毎回検査する。任意dict、typed object、bytes subclassも受け付けず、呼出側のcustom decode等を実行しない。入力上限は16 MiBで、JSONの重複key、未知field、欠落field、非有限JSON数値を拒否する。type不正や時刻不正を`unknown`へ置き換えない。不正入力は理由コードを持つ`QualityError`、妥当な入力はfrozenな`QualityReport`を返す。

top-level fieldは次の10個だけ。

| field | 条件 |
|---|---|
| `schema` | `synthetic-bars-v1`固定 |
| `source` / `pair` | `synthetic` / `TOY-CASH`固定。実source・実pairを拒否 |
| `timeframe_seconds` | 整数3600。bool、float、文字列の3600も拒否 |
| `request_start` / `request_end` | UTCの1h境界、start < end。区間は`[start,end)`、期待本数は区間から計算し1〜10000 |
| `fetched_at` | UTC timestamp |
| `outcome` | `ok` / `rate_limited` / `transport_error`。後二者はbars空を要求 |
| `revision_id` | 空でない最大128文字の文字列。制御文字を拒否 |
| `bars` | 最大10000件の配列 |

timestampはISO形式の`Z`または`+00:00`のみ。小数秒は最大6桁。非UTC offset、naive時刻、不正日付を拒否する。

各barは`start,end,published_at,received_at,open,high,low,close,volume`の9 fieldだけ。start/endはUTCの1h境界で、差は正確に1h、要求範囲内、start昇順、重複startなしを要求する。`end <= published_at <= received_at <= fetched_at`。OHLCは正、volumeは非負、小数点を含む最大64文字の通常10進文字列だけを受理する。binary float、指数、符号、NaN/Infinity、空白、先頭ゼロの多桁整数、文字列でない数値は拒否する。`high >= max(open,close,low)`かつ`low <= min(open,close,high)`を検査する。

## 状態と理由を分ける

| 条件 | status / reason | ready / 内容 |
|---|---|---|
| transport失敗 | `retryable_error / transport_error` | false、dataset hashなし、gapsなし |
| 429相当 | `retryable_error / rate_limited` | false、dataset hashなし、gapsなし |
| 同じrevisionでcanonical内容が変化 | `conflict / revision_id_conflict` | false、新旧hashを保持 |
| 新revisionで既存barの消失・内容変更 | `requires_review / dataset_revision` | false、変更/消失した既存startを提示 |
| 成功したが空配列 | `not_ready / empty` | false、要求全体の未収録startをgapsに提示 |
| 成功したが途中等に穴 | `not_ready / gap` | false、未収録startをgapsに提示 |
| 完全で上記問題なし | `ready / complete` | true、入力品質の範囲だけ |

表は妥当な入力に対する優先順。改訂でbarが消えた場合は`requires_review`とgapsを同時に返し、同revisionなら`conflict`を優先する。error応答を既存barの削除やデータ欠損へ変換しない。空・穴をfill/forward-fillする処理はない。retryableは分類であり、自動通信・retry・有料処理を開始しない。

不正値の拒否理由も区別する。例は`duplicate_json_key`、`duplicate_bar_start`、`bars_not_ascending`、`invalid_decimal`、`nonpositive_price`、`invalid_ohlc_bounds`、`invalid_timestamp`、`published_before_end`、`received_before_published`、`received_after_fetched`。結果のrecords countは返却bar数、expected records countは要求区間由来の本数であり、通信失敗時の0件を品質上の欠損件数とは呼ばない。

## hash、再取得metadata、改訂

reportはraw bytesのSHA256、canonical dataset SHA256、新旧dataset hash、records count、expected count、gaps、revised timestamps、revision ID、same snapshot、readyを保持する。gaps/revised timestampsは変更不可tuple。新hashを旧snapshotへ保存・上書きする機能はない。将来の保存層は新旧の原本・hash・改訂関係を別々に保存する必要がある。

canonical datasetは、固定schema/source/pair/timeframe、正規化したrequest bounds、各barのstart/end/published_at/OHLCVだけを射影し、keyをsortした空白なしJSONをUTF-8でhashする。UTC表記を`Z`へ正規化し、小数文字列の末尾ゼロを除去する。64文字の入力をDecimal contextで丸めず、数値比較だけにDecimalを使う。OHLCVの末尾桁の変更も別hashになる。

`fetched_at`と`received_at`は再取得metadataとしてcanonical内容から除外する。`revision_id`も版ラベルとして別に保持する。同内容の再取得、JSONの空白/key順、等価なUTC/小数表記の変更は、raw hashが変わっても`same_snapshot=True`。fetched/received時刻を変えた場合も、時刻の整合性検査自体は省略しない。publication時刻はデータ内容なので、変更を改訂として検出する。

`previous`もraw bytesを同じ検査へ毎回通し、同じ要求区間・固定identityであることを検査する。不正previous、範囲違い、通信errorのpreviousは拒否する。`ok`で品質確認した部分snapshotも比較できるが、previousを渡しただけで権利や改訂の承認済み状態になるわけではない。既存barの変更・消失はレビュー待ち。新revisionで以前の穴にbarが追加された場合は新snapshotとして扱い、既存barが不変なら通常のcomplete/gap判定へ進む。同revisionでの追加はcanonicalが変わるためconflict。同内容で版ラベルだけが変わっても同じdataset hashを維持する。

**SHAが一致しても、保管権・AI送信権・公開権や実sourceの真正性・品質を確認したことにはならない。** raw SHAは入力bytesの識別で、電子署名や第三者による証明ではない。実sourceはこの検査器の入力として拒否する。strategyへのデータ公開・Holdout露出を認可する仕組みでもない。

## 手で追えるfixtureと実測

専用試験の3本は2026-01-01 UTCの00–01、01–02、02–03。OHLCVは順に`10/12/9/11/2`、`11/13/10/12/0`、`12/14/11/13/3`という人工値。各barはendの2秒後公開、5秒後受領、fetched_atは04:00、要求は00:00〜03:00。第三者市場データの転載ではない。

正常なら3件・期待3件・gaps空でready。中央barを除けば2件・期待3件、gapは01:00。新revisionで除くと改訂startとgapの両方が01:00、requires_review。同revisionで最初のvolumeを2から3へ変えるとconflict。fetched_at/received_atだけを翌日へ変えるとraw hashは変わるがdataset hashは同じ。これらの正解をテスト内のliteralから検証する。

```bash
PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -p test_quality.py -v
```

Linux/Python 3.12.14で**専用31件成功、失敗/skip 0**。transport/429、empty/gap、重複key/時刻・順序、改訂/消失/追加・同revision競合、再取得metadata、previous再検査、時計・OHLC・decimal、最大期待10000本の境界、64文字の末尾桁保持、immutable reportを検証した。原本入力上限16 MiB、最大bars10000の超過も拒否する。全体の回帰実行と最終レビューは親が統合する。実データ、Windows、アプリ/Store/Runnerとの統合、保存/復旧、取引所の実時刻・品質・権利は未検証であり、MKT-04の開始条件を満たしたとは扱わない。
