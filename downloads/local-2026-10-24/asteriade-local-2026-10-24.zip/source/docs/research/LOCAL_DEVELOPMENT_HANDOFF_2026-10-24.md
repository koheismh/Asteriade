# ローカルPCで開発を再開する手順

2026-10-24（Asia/Tokyo）。クラウド環境の編集開始APIが403になるため、現在のソースと未commit作業を手元のPCへ移して継続する。クラウド環境を消去・再作成する手順ではない。このチャットからローカルPCを直接操作する接続はなく、移行後はローカルで実行できるCodex/IDEで本フォルダを開く。

## 引き継ぐ状態

- branch: `codex/model-task-plan`
- HEAD: `6d01d08897b4ed53de01138ee737cc6ef9deb119`
- 基準のGit履歴と、tracked/nonignored untrackedの全作業ファイルを別々に同梱する。未commit変更を含むので、GitHubのmasterをcloneするだけでは同じ状態にならない。
- `tasks.md`、本書、`HANDOFF.md`、設計・実測記録が現在地。移行のためのcommit/pushは行っていない。
- 製品RunnerはBLOCKEDのまま。移行・単体試験の成功をWindows安全ゲート、実データ権利、Stage 0合格に読み替えない。

配布ZIPには`base.bundle`、`source/`、`manifest.json`、`restore.py`、差分patch、検証サマリーを含める。Gitのローカル設定・認証情報・実行中process・アプリDBは引き継がない。クラウド専用のproxyやcache設定もPCへ設定しない。任意比較に使用したBacktrader sourceは非同梱で、通常のPython検査は外部engineの4件がskipとなる。

## 開発用の前提

1. Git。
2. Python 3.12（復元と参照検査に使用）。
3. 公式Go **1.27.2**。OS/CPUに合う公式配布物を選び、公式のSHA-256と照合する。Windows製品対象はWindows 11 x64。
4. ローカルの作業フォルダを操作できるCodex CLIまたはIDE拡張。現行の導入方法は[公式Codex repo](https://github.com/openai/codex)を参照し、手元の環境で利用可能な方式を使う。認証もPC側の正規手順で行う。無断で別の従量APIへ切り替えない。

Git/Python/Goは開発用。製品の起動依存としてPythonやNode/npmを追加したものではない。PC側のCodex導入・認証・対応モデルはクラウドから未検証。

## ZIPの確認と復元（Windows PowerShell）

ZIPをDownloadsへ保存した例。クラウド側から提示するZIPのSHA-256と、次の結果が一致することを確認する。

```powershell
Get-FileHash "$env:USERPROFILE\Downloads\asteriade-local-2026-10-24.zip" -Algorithm SHA256
```

Git/Pythonを用意してから、まだ存在しない復元先を使う。

```powershell
Expand-Archive -LiteralPath "$env:USERPROFILE\Downloads\asteriade-local-2026-10-24.zip" `
  -DestinationPath "$env:USERPROFILE\Downloads\asteriade-local-2026-10-24"
New-Item -ItemType Directory -Force "$env:USERPROFILE\source" | Out-Null
py -3.12 "$env:USERPROFILE\Downloads\asteriade-local-2026-10-24\restore.py" `
  --destination "$env:USERPROFILE\source\Asteriade-local"
```

展開先/復元先が既にあれば新しい名前を選び、既存作業を上書きしない。復元器はpayloadのhash・size・pathを検査してから、新規フォルダにlocal Git bundleをcloneする。外部へのfetch/pushやcommit、依存install、アプリ実行はしない。復元後にHEAD・全ソースhash・未commitのGit statusを照合する。途中失敗時の新規フォルダは調査用に残るため、成功表示なしで使い始めない。

復元先のoriginは公開repoのHTTPS URLに設定するが、資格情報は含めず、通信もしない。復元先だけの`core.autocrlf=false`で元のbytesを保持し、ユーザーのglobal Git設定は変更しない。全体SHA-256は配布物の一致確認であり、署名・Windows安全性の証明ではない。

復元器内のGit子processはsystem/global設定と設定注入を引き継がず、許可protocolを`file`だけに制限し、fsmonitorを無効化する。URL書換え設定で外部へ接続したり、ユーザーのhelperを起動したりすることを防ぐための局所設定であり、通常の端末やCodex自身のGit/proxy/CA設定を変更しない。

## Windowsでの基準確認

```powershell
Set-Location "$env:USERPROFILE\source\Asteriade-local"
git status --short
git branch --show-current
git rev-parse HEAD
go version
py -3.12 --version
go mod download
go mod verify
go test -count=1 -p 4 ./...
$env:PYTHONPATH = 'reference'
$env:PYTHONDONTWRITEBYTECODE = '1'
py -3.12 -m unittest discover -s reference/tests -v
$env:CGO_ENABLED = '0'
go build -trimpath -o bin/asteriade.exe ./cmd/asteriade
```

`go version`が1.27.2であることを確認する。Pythonは標準構成で82件中78成功・任意比較4skipを既報の基準とするが、PCで実測して件数・失敗/skip理由を記録する。GoのWindows試験結果は未確定であり、Linuxの164成功をPCの成功として記録しない。PowerShell script実行が許可される環境では[Windows検証手順](../WINDOWS_VALIDATION.md)の`verify-windows.ps1`も使用できる。実行policyを無効化して通さない。

## macOS/Linuxの場合

標準のGit、Python 3.12、OS/CPUに合うGo 1.27.2を用意し、ZIPを新しいフォルダへ展開後、`python3 restore.py --destination /新しい復元先`を使う。SHAはLinuxの`sha256sum`、macOSの`shasum -a 256`で照合する。

`scripts/setup.sh`はLinux x86_64専用、`scripts/env.sh`の既定cacheは`/workspace`なので、手元のMac/Linuxでは通常のGo installationで直接`go`を実行する。クラウド専用のproxy・CA・環境変数をコピーしない。

```bash
go version
go mod download
go mod verify
go test -count=1 -p 4 ./...
PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s reference/tests -v
CGO_ENABLED=0 go build -trimpath -o bin/asteriade ./cmd/asteriade
```

Mac/Linuxの成功はWindows実機のACL・sandboxを証明しない。Windows環境でSAFE-02/03を満たす条件は保持する。

## ローカルCodexへ渡す依頼

復元した`Asteriade-local`フォルダをローカルCodexで開き、次を渡す。

```text
Asteriadeのローカル開発を引き継いでください。
AGENTS.md、tasks.md、docs/research/HANDOFF.md、
docs/research/LOCAL_DEVELOPMENT_HANDOFF_2026-10-24.mdを最初に読んでください。
Git branch/HEADと未commit作業を確認し、既存変更を保全してください。
Go 1.27.2/Python 3.12/Gitを確認し、本書のOS別基準検証を実行して結果を記録してください。
このPCのネットワーク方針と許可を確認し、通常の許可経路でMKT-01の公式文書調査を再開してください。
クラウドの403とローカルの接続可否は別に確認し、拒否や権利不明を迂回しないでください。
価格・足・板・約定・pair設定等の市場データAPIや問い合わせ送信は行わず、公式文書だけを読みます。
保存・AI送信・公開の権利、料金/適用日、時計/確定/訂正/履歴・数量条件を別々に記録してください。
市場選定・科学仕様・engine採否・安全承認は担当する上位モデルへ渡してください。
Runner能力やGATEDを開放せず、push/公開/追加課金は行わないでください。
Linuxや移行時の試験結果をローカル/Windowsの実測に転記せず、今回の観測を記録してください。
```

ローカルで条件が揃えばMKT-01の調査を進められるが、保存/AI送信/公開の第三者権利や市場選定・Windows境界の未決は残る。[タスク台帳](../../tasks.md)を正とする。

## 移行パッケージの検証記録

クラウド内の別の新規フォルダへZIPから復元し、115ソースのbytes/SHA-256、HEAD、branch、未commitのGit statusの一致を確認した。bundleには現在branchの祖先履歴を含み、他branchの全refや個人Git設定を移したものではない。

復元先のLinuxでGo `go test -count=1 -p 4 -json ./...`を実行し、164成功・subprocess helper 1skip・失敗0。標準Pythonは82件中78成功・任意Backtrader比較4skip・失敗0。これは今回のLinux復元検証であり、手元PC・Windows/macOSの試験成功ではない。実行ログはクラウドのignored `.local/validation/local-migration-2026-10-24/`、要約はZIPの`evidence/`。

ソース改変、bundle改変、path traversal、大小文字衝突、未知file、symlink、既存destinationの7ケースを拒否し、出力先の作成/上書きが起きないことを確認した。さらにGit global/設定注入によるURL書換えを与えても、設定を引き継がず正常にローカル復元できることを確認した。

Sol指定のread-onlyレビューでGit設定継承の問題を発見し修正した。既知形式の秘密値patternは115作業ファイルと履歴108 blobで検出されなかったが、これは任意の機密内容がないことの証明ではない。配布対象はユーザー自身のローカル開発向けで、GitHubへ公開/pushしていない。
