# Windows証跡の事前検査（PRE-03）

2026-10-23。開発専用、Python標準ライブラリのみ。[境界ADR](WINDOWS_BOUNDARY_ADR_2026-10-23.md)の12ケースを対象に、証跡の完全性・hash・対応関係を検査する。Windowsのprobe実行器、証拠の真正性保証、SAFE-02/03の合格判定は未実装である。製品Runnerとの接続はなく、結果の`execution_enabled`は常に`false`。

## 使用方法

リポジトリルートで未実施テンプレートを作る。専用の空ディレクトリを使い、既存証跡を上書きしない。

```bash
mkdir -p .local/safety-preflight
python3 scripts/safety_evidence.py --template > .local/safety-preflight/unrun.json
```

テンプレートのOS・SID・hash・時刻は未入力で、全ケースが`unrun`。生成コマンドは現在のOSを調査せず、Windows試験を実行したことにもならない。

将来、管理されたWindows試験で採取したbundleとartifactの**非公開で変更されないコピー**に対し、別途profileレビューで固定したSHA-256を指定する。

```bash
python3 scripts/safety_evidence.py \
  --bundle .local/safety-preflight/bundle.json \
  --artifacts .local/safety-preflight/artifacts \
  --expected-profile "$ASTERIADE_REVIEWED_PROFILE_SHA256"
```

`ASTERIADE_REVIEWED_PROFILE_SHA256`はレビュー済みの値を設定する。bundle自身の値を抽出して承認値として渡さない。profile fingerprintの計算仕様は、固定キー/型を検証後、キー順に整列したASCII JSONを空白なし・区切り`,:`でエンコードしSHA-256を取るもの。実装の`profile_fingerprint`が計算できても、対象構成の採用承認にはならない。

| 結果 | exit code | 意味 |
|---|---|---|
| `blocked` | 1 | 不正形式、hash不一致、古い証跡、未実施・欠落・失敗等 |
| `review_required` | 0 | 完全性検査を通過。trusted収集過程・実機観測・全variantをSAFE-03で確認する必要がある |

引数不正はargparseのexit code 2。`--template`のexit code 0はテンプレート出力成功だけを表す。いずれのcodeも能力開放に使用しない。

## 検査契約

- profileはWindows 11 edition/build/**UBR**/amd64、backend、6実行物hash、5役割の異なるaccount SID、AppContainer SID、policy/fixture hashを束縛する。変更すれば別fingerprintとなる。
- account SIDは`S-1-5-21`の後4要素、AppContainer SIDは`S-1-15-2`の後7要素を要求する。各要素はASCIIの通常10進表記で0〜4294967295、先頭ゼロは単独の`0`以外拒否する。別表記を正規化してhashを書換えず、入力を拒否する。これは文字列表現の検査であり、実在するaccount/tokenや実際のidentity分離の確認ではない。
- 12ケースすべての同一run/profileにpositive/negativeの別artifactを要求する。`failed/blocked/skipped/unrun`、missing、case重複、artifactの再使用は合格扱いにしない。
- observationはrun/profile/case/phase/time、実行ID、role/SID、policy、手順、fixture hash前後、期待と観測、OS error/exit codeを記録する。networkは陽性sink受信1件以上・否定0件、process treeは終了後残存0件を要求する。
- 開始から72時間以内、終了が現在以前、各観測がrun期間内であることを検査する。72時間はこの開発用preflightの鮮度上限であり、72時間の安全性を保証しない。
- JSONは未知キー・重複キー・非有限値を拒否し、各文書は4 MiB以下。artifactは単階層のJSONファイル名のみ。通常のsymlink/域外path/ADSとhash不一致を拒否する。
- 不正bundleのCLI出力は一般化した理由に限り、入力のprivate値やpathをそのまま表示しない。

件数・文字列・hashが正しくても、手順の有効性、OSによる実際の拒否、秘密markerの不在、通信経路や子孫の全variantはこれだけでは証明できない。fixtureの変更可否も各試験手順に従ってレビューする。実行中にartifactディレクトリを別processが変更する状況でのTOCTOU防御や、署名・遠隔attestationは提供しない。収集器とレビュー経路の実装はSAFE-02に残る。

## Linuxでの検証

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s reference/tests -p test_safety_evidence.py -v
```

15件成功。合成JSONと一時ディレクトリで、完全bundleでもreview止まり、未実施/欠落、改変・別run/SID/policy、profile変更、stale/future、path、sink/子孫、未知/重複JSON、CLI出力を検証した。これらのテストはWindowsでの実測を作っていない。最終の全体結果は[継続作業記録](STAGE0_CONTINUATION_2026-10-23.md)を参照。

同日のSol引継ぎ後、SIDのDWORD超過・先頭ゼロによる別表記を受理する不備を修正した。全subauthority位置の不正表記、0/UINT32_MAX、要素数/prefix、profile不変、正常profileの既存hashを回帰検証。[引継ぎ後の修正記録](SOL_STAGE0_READINESS_2026-10-23.md)を参照する。上の15件は修正前増分の実績として保持する。
