# Stage 0残課題の実装契約 — Holdout・凍結・実行境界

作成: 2026-10-22（Asia/Tokyo）。担当: 上位モデル（親）。状態: **設計初稿を作成・レビュー済み。実装／Windows実証／Stage 0合格ではない。**

基準: `6d01d08897b4ed53de01138ee737cc6ef9deb119` の[要件v2](../REQUIREMENTS.md)、[基本設計](../ARCHITECTURE.md)、[研究プロトコル](../RESEARCH_PROTOCOL.md)、[安全性検証計画](../SECURITY_VALIDATION.md)。実装担当と依存順は [tasks.md](../../tasks.md)。本書は既存方針を実装単位へ具体化する追加設計で、未確定の市場仕様・配布方式を採用済みにしない。

後続の合成実装は[2026-10-22検証記録](STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)を参照。本書の製品契約全体を実装済みとは扱わず、実際に確認したlibrary/Store経路とBroker/市場/Windowsの未実証を分ける。

## 1. 現在地と今回の判断

| 論点 | 確認した事実 | 今回定める契約／残る判断 |
|---|---|---|
| 開発基準 | masterは旧v1.1文書のみ。最新作業系統は投資研究v2 | 最新作業系統を計画基準にする。既定ブランチへ採用済みとは扱わない |
| 市場範囲 | 最新[調査](BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)はBTC現物・1市場1ペア・1時間足を前提とする | 1時間足の選択を再質問しない。venue/quote/期間/権利/費用は未確定のまま別ゲートにする |
| 市場profile | bitbank BTC/JPYは調査優先案。正式選定ではない | 不明なfee/tick/lot/保管権を仮定で埋めた実行可能profileは作らない |
| identity | `internal/research/identity.go` はsynthetic developmentのみ受理 | 既存v1を緩めず、後続のpartition対応は別のschema/versionとして実装・試験する |
| データ安全性 | 現行hashは整合性検査。署名・認証・OS隔離ではない | Registry・アクセス仲介・Windows境界を別々の証拠で判定する |
| 会計 | `reference/` は開発用の合成参照例 | 製品kernelへ直結せず、独立goldenと配布／隔離評価を通して採否を決める |
| 実行能力 | `internal/runner/runner.go` は全能力false、`CheckReady`は拒否 | 純粋なモデル試験の成功で研究Runnerを有効化しない |

## 2. コンポーネントの責務と信用境界

```mermaid
flowchart LR
    M[Manager / Engineer] -->|提案・型付きSpec| G[Research Governor]
    G --> R[共有Registry / 永続イベント]
    G -->|凍結ID・許可した操作| B[Data Broker]
    B -->|限定入力| E[固定Evaluator / Kernel]
    E --> Q[未公開成果物領域]
    Q -->|機械検査・公開記録| G
    G -->|許可済み要約| M
```

- GovernorのみがRun claim、ゲート判定、アクセス許可、結果公開を管理する。AIの文章で状態を更新しない。
- Registryは全Project共通。ProjectごとにDBを分けても、共通露出台帳への照会を省略できない。
- BrokerだけがHoldout原本を開ける。UI、Provider、一般Worker、戦略生成コードへファイルパス・ハンドル・認証情報を渡さない。
- 初期Evaluatorの候補は、固定したkernelが型付き・有限のStrategySpecを解釈する方式。未信頼コードを同じプロセスへ動的ロードしない。任意Python/Goプラグインが必要なら別の隔離・IPC設計を要する。
- Kernelだけが会計と許可された評価時計を処理する。戦略側へ渡す特徴量は判断時刻までのviewに限る。kernelと戦略が同じアドレス空間で任意コードを実行する構成では、未来データを隠せたと認めない。
- 生成コードの開発WorkerはDevelopmentデータだけを扱う。将来のHoldout用Evaluatorとは資格・入力・出力権限を分ける。
- 具体的な言語、Runner同梱方式、Windows backendは `ENG-02` / `SAFE-01` の判断事項。図は実装済みプロセス配置ではない。

## 3. 実験identityと互換性

既存`asteriade/frozen-manifest-v1`と`asteriade/freeze-json-v1`は保存済みgoldenとともに維持する。`PartitionRole=holdout`を通すためだけの条件削除はしない。次版の最小契約は次のとおり。

| 必須情報 | 型・意味 | 欠落／変更時 |
|---|---|---|
| schema / canonicalization version | 対応表で認識した文字列。任意JSONを既存v1と同じhashと呼ばない | 未知版を拒否。旧readerで新schemaを無理に開かない |
| project / program / hypothesis / cycle / experiment / selection family | 空でないID。候補集合・派生元は別の追記台帳へ参照 | 行方不明の選抜履歴を独立な初回試行へ置換しない |
| frozen spec / kernel / code / environment | 内容hashと版、依存lock、実行profileのfingerprint | どれか変われば親identityと理由を持つ新revision |
| dataset snapshot / partition / source lineage | 内容hashに加え、商品、source世代、期間、partition role | hash一致だけで権利や科学的独立性を認定しない |
| benchmark / cost / metrics / criteria / gates | 結果を読む前に固定した定義へのhash参照 | 未確認値は実行不可。結果閲覧後の差替えは別実験 |
| parameters / search space / seed set | 型・範囲を限定。10進量は文字列または規定整数 | NaN、Infinity、重複key、未知componentを拒否 |
| approval scope / data use policy | 許可範囲と版への参照。秘密値を含めない | 期限切れ・scope変化で再評価。hashだけで承認成立にしない |

`RunID`は試行ごとに新規発行し、凍結manifestとは別に保存する。同じ入力での再実行は同じmanifestに新Runがぶら下がる。出力に影響する変更は新manifestを要する。検証器は実ファイルのhash、承認済みkernel、policy、Registry来歴も照合する。攻撃者が内容とhashを同時に書換えられる保存先を信頼しない。

## 4. Registryの最小永続モデル

以下は追加schemaの論理契約。SQLと移行は`HLD-03`で実装する。既存SQLite v1のDDL・migration checksum・旧Projectデータは変更しない。

| 集約 | 最小フィールドと制約 |
|---|---|
| DatasetSnapshot | ID、content hash、source/vintage、親snapshot、商品識別子、UTC範囲、足種、権利記録ID。immutable |
| Partition | ID、snapshot ID、role、元データへの範囲対応、状態、row version、continuity状態 |
| ExposureEvent | 一意event ID、全体sequence、partition/run/manifest/actor、event type、時刻、公開範囲、証拠参照。追記専用 |
| EvaluationClaim | claim ID、run ID、partition集合、fencing generation、状態、policy fingerprint。重複アクセスを排他 |
| Candidate / Selection | family ID、候補ID、親候補、全variant/seed、選抜集合、採否理由、使用partitionと参照結果。失敗候補も残す |
| Run / Artifact | 新規Run ID、manifest hash、status、validation status、成果物hash、証拠クラス、公開状態。成功とvalidを別管理 |
| ContinuityRecord | 台帳epoch、最終確認sequence、復元/import元、検証証拠、`verified / unknown / invalid`。新しいDB名は新鮮性の証明にならない |

アクセスを許可する更新は、状態行・ExposureEvent・outbox・idempotency receiptを同じtransactionで確定する。idempotency keyは操作scope＋payload hashに束縛し、同key・異なる内容は競合。同keyの再送で新grantを発行しない。

重複照会は最低限、同一の基礎商品（venue/product/base/quoteを正規化）、UTC半開区間`[start,end)`、元snapshotの対応関係を使う。別hash・改訂データ・別時間足・別Projectでも期間が重なれば照会対象。派生特徴量は親データ範囲とlabel horizonを引き継ぐ。境界の重複や学習期間の漏れを単純なbar timestampだけで除外しない。

異venueの相関商品や別仮説による適応は、ID一致検査だけでは独立性を保証できない。関連候補・既知露出として併記し、対応不明は`unknown`として独立確認を止める。高度な統計補正は後段でも、選抜集合の保存はStage 1Aから必須。

## 5. Holdout状態と露出の単調性

状態名だけで巻き戻し可否を決めない。追記台帳から`access_granted`、`value_access_possible`、`result_released`、`decision_exposure`を導出し、一度立った事実を消さない。`continuity != verified`なら見かけの状態が`unseen`でも独立評価不可。

| 入力状態／イベント | 必要な証拠 | 次状態・許否 |
|---|---|---|
| unseen → preflight | Registry連続性、重複照会、凍結／安全／権利ゲート | 値はまだ渡さない。metadataだけ検査 |
| preflight中に失敗 | grantなし、Brokerで値を開いていない、結果も公開していないことを台帳で確認 | 未使用維持可能。失敗イベントは残す。証拠が欠ければunknown |
| preflight → evaluation_active | 排他claimとaccess intentをdurable commit後、Brokerがfence照合 | grant後は値アクセス可能だった扱い。空の出力でも自動的にunseenへ戻さない |
| evaluation_active → inspected | 値アクセス／検査事実 | 結果がなくても露出履歴を維持 |
| inspected → consumed | 結果公開または意思決定への参照 | 同じ期間を独立未使用へ再分類しない |
| active以降に科学バグ判明 | 露出範囲・kernel差分・影響分析 | defect_review。修正後はcorrected_analysis等として履歴を継承 |
| 結果を見て戦略・閾値を変更 | 新manifest、派生候補、選抜理由 | 元の消費を維持。新候補でも同一区間の独立性は復活しない |
| 中断・クラッシュ・不明な結果公開 | durable intent、Broker/Worker終了証拠、公開記録を照合 | Runはoutcome_unknown、露出は保守的に維持。履歴不足はunknown |
| 保管期限・権利失効 | 破棄範囲と残るmetadata、再現性の限界 | retired。生データを消しても過去の露出は削除しない |

`preflight`の失敗から未使用を維持できることと、評価開始後のインフラ再試行は別。後者は承認済みの同一実験の再試行として扱える場合でも、独立データの再獲得とは呼ばない。

## 6. クラッシュ／競合に耐えるアクセス手順

1. Governorがmanifest・権利・policy・profileを検査。Brokerはまだ値を読まない。
2. Registryのwrite transaction（SQLiteでは`BEGIN IMMEDIATE`相当）で、全Projectを含む期間重複と未完了claimを再確認。claim、fence、access intent、outboxをまとめてcommitする。事前の読み取りだけで排他を保証しない。
3. Brokerがcommit済みclaim、対象hash、actor、fence、policyを照合して限定入力を渡す。transaction失敗・DB停止・fence不一致なら送出しない。
4. 出力は非公開stagingへ保存。kernel/manifest/出力schema/テスト結果を検査し、状態とhashを追記する。
5. AI／ユーザーへの結果公開前に、宛先と公開内容hashを持つrelease intentをcommitする。表示・送信のackは別イベント。ackなしでも「未露出」と推定しない。
6. 再起動時はpending intent、未終了Worker、結果公開を照合。曖昧な操作はoutcome_unknownで停止し、同じ入力の無条件再送をしない。

DB commitとファイル送出／画面表示は一つの原子操作にできない。この隙間は「必ず一回だけ実行できる」という主張で埋めず、**先にintentを記録し、曖昧時は露出可能として停止**する。

Lease期限だけで古いWorkerの権限が消えたとは扱わない。Brokerは各アクセスをfenceで拒否し、既に渡した値は取り消せない。新claim前に旧プロセス木の停止／ハンドル無効化と台帳整合を確認する。安全性を確認できなければ新評価を開始しない。

## 7. バックアップ・復元の限界

ローカルのhash chain、DB checksum、自己署名だけでは、DBと証跡をまとめて古い状態へ戻す攻撃を検出できない。`PRAGMA integrity_check`成功も科学的な未使用性の証明ではない。

- 通常再起動は、登録済み台帳とBroker記録の連続性を確認して回復する。
- backup restore、別PC移動、registry import、履歴欠損を検知した場合はcontinuityをunknownにする。元より新しい露出履歴を信頼できる記録と照合するまで、該当データによる独立確認を止める。
- 検知可能性を超えるディスク全体のrollbackや管理者による改竄を防げたと主張しない。独立した最新性の証拠を保つ方法はWindows実証で評価する。未解決なら運用上その制約を明示し、復元データをunseen扱いしない。
- 新しいpartition ID、別Project、データ再ダウンロードは露出履歴のリセット手段にしない。
- unknown時も許可されたDevelopment研究は可能。Holdoutによる独立確認と証拠クラス昇格を止める。

## 8. 実装担当へ渡す合成受け入れベクトル

以下は新規試験の仕様であり、今回実行した24件の既存テストとは別。`HLD-01`が値と期待イベントを独立に固定し、`HLD-02`〜`HLD-04`で実装・検証する。

| ID | 操作／故障注入 | 期待結果 | 要件 |
|---|---|---|---|
| HC-01 | preflightでmanifest不一致、grant前に停止 | 値read 0、grant 0、失敗履歴あり、未使用維持 | AT-13 |
| HC-02 | access intent commit直後、送出前に停止 | active/unknown維持。自動unseenなし | AT-13/25 |
| HC-03 | 値を読んだ直後にWorker停止、結果なし | 露出可能履歴維持、Run outcome_unknown | AT-14/25 |
| HC-04 | 結果公開後に科学バグ修正 | 新kernel/manifest、corrected_analysis、消費維持 | AT-14/15 |
| HC-05 | 別Project・別hash・別足種で元期間が部分重複 | 関連露出を検出し、独立未使用として拒否 | AT-37 |
| HC-06 | 2つの同時claimが重複区間を要求 | 一方だけgrant、他方はconflict。DB再起動後も一致 | AT-25/37 |
| HC-07 | 古いlease/fenceでアクセス、強制終了未確認 | 旧grant拒否、新評価開始なし | AT-26/37 |
| HC-08 | receipt同key同payload再送／異payload再送 | 前者は同結果でgrant追加0、後者はconflict | AT-25 |
| HC-09 | 古いbackupを復元、元露出記録が欠損 | continuity unknown、独立確認不可 | AT-14/37 |
| HC-10 | release intent後ack前に停止 | 未露出に戻さない。再公開の判定履歴を残す | AT-14/25 |
| HC-11 | 候補失敗・棄却・再設計、別AIの再提案 | 全候補と親系譜が残り、初回試行へ数え直さない | AT-19/32 |
| HC-12 | 未知商品alias、期間対応不明、registry欠落 | unknownを返し、独立評価は停止 | AT-07/37 |

純粋な状態機械の合格、SQLite故障注入の合格、Windowsで値を物理的に隠す試験の合格を別々に報告する。

## 9. 市場profileと時計のgolden準備

`MKT-03`で公式仕様を反映する前に、次の区別を維持する。

- 10:00–11:00足が11:00:02公開、11:00:05受領／判断なら、11:00 openでの約定は不許可。1時間境界だけを使う提案モデルでは12:00以降の適格openが候補。これは実約定の再現主張ではない。
- `feature_ready_at`を含む全入力のavailability以下にsignalを置かない。fillはsignal後、かつprofileが定める実行可能時刻以降。同時刻の順序はイベント順も固定し、時刻の等号だけで有利に判定しない。
- 歴史データを今日取得した事実と、過去当時の公開／受領証拠を区別する。後者がなければ明示的latency仮定とし、as-of実証済みと呼ばない。
- fee通貨、rebate、tick/lot、丸め、最小量、数量不足、gap、両barrier touch、部分売却、MTM/DDを個別goldenへ。非対応はunsupportedと記録する。
- 現在のquote・非負feeのtoy会計をbase feeやvenue固有丸めへ流用しない。未確認の値をゼロとしてテストを通さない。
- benchmark、期間、費用シナリオ、比較不能な条件は結果を見る前に凍結する。高安幅をspreadの代用にしない。

## 10. Stage 0出口の証拠

`GATE-00`の親レビューでは次の全項目の対象commit、環境、実測、未実施を確認する。

| 必要証拠 | 主担当タスク | 不足時 |
|---|---|---|
| 固定Goで既存テスト・build・local smokeを再現 | DEV-01 | ツールチェーンの未確認を残す |
| source/権利・市場profile・独立golden | MKT-01〜04 | 実データ取込／市場kernel評価停止 |
| engine同条件比較・配布判断 | ENG-01/02 | 未検証engineを製品採用しない |
| freeze次版・共有Registry・故障／復元試験 | HLD-01〜04、INT-01 | Holdout独立評価停止 |
| 採用engine/配布物のfingerprintに対応したWindowsのfile/process/network/secret/IPC境界 | ENG-02、SAFE-01〜03 | 研究Runnerを閉じる。実行物・identity・policy変更で旧判定失効 |
| 実注文能力なし・私的情報の送信拒否（合成入力と送信stub） | SAFE-02 | 対応経路を開放しない |

Stage 0は合成のProvider/export境界試験を使う。Stage 1で実adapterを導入する`A1-01`では、導入した経路について秘匿・費用・通信境界を再検証する。後段adapterの完成をStage 0出口の前提にせず、合成試験だけで実adapterも安全と推定しない。

本書作成と既存合成テストの成功だけでは上記の出口を通過しない。合格証拠と対象Stageの開始許可は別に記録する。
