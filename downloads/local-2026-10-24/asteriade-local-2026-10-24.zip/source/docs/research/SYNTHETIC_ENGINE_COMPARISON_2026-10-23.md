# 市場非依存の合成engine比較（2026-10-23）

**状態: ENG-01の準備・部分根拠。ENG-01全体、engine採用、Stage 0出口の合格ではない。** 実行モデル指定は`gpt-6.1-sol`。開始HEADは`6d01d08897b4ed53de01138ee737cc6ef9deb119`、既存の未commit変更を保全した。

[Stage 0B比較](STAGE0B_REUSE_EVALUATION_2026-10-21.md)で予備比較器としたBacktraderを、既存の[SpotLedger](../../reference/asteriade_synthetic/spot.py)と、親が先に固定した定数oracleへ照合した。対象は人工の`TOY/CASH`だけ。[市場調査](BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)のBTC現物・1市場1ペア・1時間足は今後の調査前提であり、このtoy試験をBTC/JPYや特定venueのgoldenに読み替えない。MKT-03の市場時計・会計契約、旧資産の利用権、実市場のfee/丸め/権利等は未解決である。

## 固定sourceと依存

| 項目 | 今回の確認 |
|---|---|
| 上流 | [mementum/backtrader](https://github.com/mementum/backtrader/tree/b853d7c90b6721476eb5a5ea3135224e33db1f14) |
| 要求したcommit | `b853d7c90b6721476eb5a5ea3135224e33db1f14`（0Bと同じ固定URL） |
| codeload tar.gz SHA256 | `5683f83894999bbc3e42c528a0d943a4b7437c545dce42bb536443a61e8a7127` |
| 展開tree fingerprint | 378 files、SHA256 `d6d91657f0abd4f3ac2aac9d636cbd933b95e26cd10c1e8f2136e36a780045d1` |
| version.py | `1.9.78.123` |
| ライセンス | [setup.py](https://github.com/mementum/backtrader/blob/b853d7c90b6721476eb5a5ea3135224e33db1f14/setup.py)が`GPLv3+`を宣言し、冒頭にversion 3 or later、[LICENSE](https://github.com/mementum/backtrader/blob/b853d7c90b6721476eb5a5ea3135224e33db1f14/LICENSE)にGPLv3本文があることを再確認 |
| runtime dependencies | setup.pyの`install_requires=['six']`はコメント。必須runtime依存の宣言はない。`plotting` extraはmatplotlib。今回はsetup.py/pipを実行せず、plotting/追加依存も導入しない |
| 実行環境 | Linux、Python `3.12.14`。Windows未実行 |

sourceは通常のproxy/TLS検証を保ったHTTPSで取得し、ignoredな`.local/engine-comparison/`へ展開した。第三者コードの改変・リポジトリへの転載・製品同梱はしていない。archive hashは今回のTLS取得物から計算した固定値であり、上流の署名や別経路で公開されたchecksumの検証ではない。Git commit署名も検証していない。

実行前に比較器がtree fingerprintを検査し、違うsourceや、別ディレクトリから既にimportされたBacktraderを拒否する。fingerprintは相対path順に`path UTF-8 + NUL + file SHA256の32 raw bytes`を連結したSHA256。`__pycache__`と`.pyc`だけを除外する。これは実験の再現性確認で、信頼できないコードを安全に実行する機構ではない。

今回の開発用実行を、GPLの配布条件やAsteriade製品との適合が確認済みであることにしない。ランタイム採用・リンク/同梱・配布・保守の判断は親レビューとENG-02に残す。

## 共通条件と独立oracle

初期cashは1000、long-only、quote fee rateは`0.001`、slippageは0、レバレッジ1。tick/lot/丸めを適用せず、任意小数の数量を許すtoy条件とした。Backtraderにはstocklike/percentage commission/`percabs=True`を明示し、標準の成行・next-bar-openを使う。cheat-on-close/open、独自filler、market-data adapterは使わない。

定数は[vector定義](../../reference/comparison/vectors.py)へ先に記述した。Backtrader出力からoracleを生成・更新しない。SpotLedgerは7項目を`Fraction`で厳密比較し、Backtraderの共通項目（cash、quantity、equity、total_fees）と各約定価格/数量/feeは、絶対誤差`1e-9`以内で比較する。相対誤差で許容を拡大しない。

| vector / 操作 | cash | qty | realized_net | 残存原価（entry fee込） | unrealized_net | equity | fees |
|---|---:|---:|---:|---:|---:|---:|---:|
| A: buy 2@10 fee .02 → sell 1@12 fee .012 → mark 11 | 991.968 | 1 | 1.978 | 10.01 | .99 | 1002.968 | .032 |
| B: buy 2@10 fee .02 → sell 2@9 fee .018 | 997.962 | 0 | -2.038 | 0 | 0 | 997.962 | .038 |
| C: buy 1@10 fee .01 → buy 1@14 fee .014 → sell 1@15 fee .015 → mark 13 | 990.961 | 1 | 2.973 | 12.012 | .988 | 1003.961 | .039 |

SpotLedgerはA/B/Cすべての期待値と一致。Backtrader共通4項目の最大絶対誤差はAが`1.1368683772161603e-13`、Bが`6.938893903907228e-18`、Cが0だった。追加の手計算probe（A/B/Cは変更せず）では、`.25@10` fee `.0025`、mark 11に対しcash `997.4975`、qty `.25`、equity `1000.2475`、fees `.0025`を確認し、lot整数丸めをしていないことを確かめた。実venueの最小数量・丸めを実証した結果ではない。

価格の比較では、seed row、各約定の指定価格、最終markの順に全OHLCを同じ値にした人工足を与え、前のrowで注文する。したがって既定の次足openが指定価格となる。これは事前指定した価格と会計の照合であり、その価格で当時発注可能だったことや実約定能力の証明にはならない。

## 部分決済のPnLは同じ指標ではない

[trade.py](https://github.com/mementum/backtrader/blob/b853d7c90b6721476eb5a5ea3135224e33db1f14/backtrader/trade.py)の`Trade.pnlcomm = pnl - commission`は、未決済部分のentry feeも含め、trade全体で累積したcommissionを差し引く。SpotLedgerの`realized_net`は売却数量に対応するentry feeだけを按分し、未決済分を残存原価に残す。

| vector | Backtrader raw Trade.pnlcomm | SpotLedger realized_net | 差（参照−raw） | Backtrader closed tradeのみのPnL合計 |
|---|---:|---:|---:|---:|
| A（保有中） | 1.968 | 1.978 | .01（残存entry fee） | 0 |
| B（全決済） | -2.038 | -2.038 | 0 | -2.038 |
| C（保有中） | 2.961 | 2.973 | .012（残存entry fee） | 0 |

Backtraderのposition原価はentry feeを含まないため、Aは10、Cは12。参照の10.01/12.012と直接同じ指標として比較しない。候補engineのraw値を報告し、変換adapterでこの差を隠していない。raw realized/原価/未実現PnLが全面一致したとは宣言しない。cash/数量/資産/feeが一致し、全決済Bのnetが一致することを、部分決済の報告契約との差と分ける。

## 時計negative: next-bar-openだけでは不適格

別vectorは、10:00–11:00の足、11:00:02公開、11:00:05受領/判断、1h境界の最初のeligible openが12:00という契約を使う。すべてUTC、日付は人工の2026-01-01。

Backtraderへopenラベル10:00、11:00、12:00の足を与え、最初の`next()`で注文すると、既定の次足openは**11:00:00**で約定した。比較器は11:00:05という実時間のsignalをBacktraderに注入しておらず、engineにはpublication/receiptの概念を追加していない。この不足を可視化するnegativeである。10:00というbarラベルを、その足の情報が受領済みの時刻に読み替えてはいけない。

既存`validate_fill_time`へ受領/判断11:00:05、eligible12:00、実測fill11:00を渡すと`fill precedes eligibility`で拒否する。12:00の対照fillは受理した。11:00のopenはsignalより前なので不適格。次足openという名前だけで、この市場時計契約を満たしたとは扱わない。互換adapterで翌々足へずらして合格に見せる修正はしていない。

## 拒否の責任範囲

比較器はBacktraderを呼ぶ前に、全fillを一時的なSpotLedgerで検査する。cash不足、裸売り/在庫超過、重複fill ID、固定quote fee rate以外を拒否し、候補engineのimport/実行が呼ばれないことをmockで確認した。既存の原子的拒否試験も回帰実行した。

これは比較用の入力境界であり、Backtrader本体がlong-only、unique fill、注文権限を強制するという試験ではない。Backtraderのshort能力を製品境界で閉じた証拠にもならない。比較器にはDB、注文API、外部通信やOS隔離を持たせていない。

## 再現手順と実測

リポジトリrootから実行。必須installはなく、通常suiteは標準libのみ。

```bash
PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s reference/tests -v
```

結果は31件中27成功、optional engineの4件skip、失敗0。Backtraderを自動download/importしない。追加ファイルは[比較器](../../reference/comparison/engine_comparison.py)、[固定vector](../../reference/comparison/vectors.py)、[テスト](../../reference/tests/test_engine_comparison.py)で、既存reference primitivesは未変更。

固定sourceを今回と同じ方法で配置する場合（通常proxy/TLSを維持）:

```bash
mkdir -p .local/engine-comparison
curl --fail --location --proto '=https' --tlsv1.2 --max-time 90 \
  https://codeload.github.com/mementum/backtrader/tar.gz/b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  -o .local/engine-comparison/backtrader-b853d7c.tar.gz
sha256sum --check <<'CHECKSUM'
5683f83894999bbc3e42c528a0d943a4b7437c545dce42bb536443a61e8a7127  .local/engine-comparison/backtrader-b853d7c.tar.gz
CHECKSUM
tar -xzf .local/engine-comparison/backtrader-b853d7c.tar.gz -C .local/engine-comparison
```

checksumの不一致では停止し、新しい値へ自動更新しない。source/ライセンスの確認後、任意の比較を実行する:

```bash
ASTERIADE_BACKTRADER_SOURCE=.local/engine-comparison/backtrader-b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -v
ASTERIADE_BACKTRADER_SOURCE=.local/engine-comparison/backtrader-b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m comparison.engine_comparison > .local/engine-comparison/result-2026-10-23.json
```

固定source付きsuiteは**31件すべて成功、skip/失敗0**。新規7件（うちoptional4件）、既存24件。Backtrader上流の`cerebro.py` 675/717行からPython 3.12のinvalid escape SyntaxWarningが2件出たが、第三者コードを修正・警告抑制していない。raw JSONと実行ログはignoredな`.local/engine-comparison/`へ保存した。`git diff --check`も成功。Goアプリ/製品コードを変更していないためGo試験は今回再実行していない。

今回検証していないもの: venue時計、確定/改訂、遅延・as-ofデータ隔離、実価格/流動性、spread/impact、base/複数通貨fee・rebate、tick/lot/丸め/最低量、同一足のstop/target順、板・部分約定生成、連続時間DD、統計的優位性、Windows/OS境界、製品Runner、Provider、実データ取込。旧quantのコード/実データも移植・取得していない。ENG-01の市場profileでの同条件比較、ENG-02の採否、安全ゲートは別途必要である。
