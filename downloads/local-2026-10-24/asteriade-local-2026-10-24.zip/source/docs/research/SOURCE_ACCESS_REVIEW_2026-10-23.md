# DOC-02 / MKT-01 公式出典・アクセス再確認

取得日: **2026-10-23（Asia/Tokyo）00:41–00:44** / 2026-10-22 15:41–15:44 UTC。担当: **GPT-6.1-Sol**（指定GPT-6.1-Lunaが利用不可のため代行）。開始HEAD: `6d01d08897b4ed53de01138ee737cc6ef9deb119`。既存変更を保全し、本ファイルだけを追加した。

**結論: GitHubの公開範囲とPR #2/#3/#4の表示を更新確認できた。取引所公式サイトとGitHub APIは引き続きCONNECT 403で、DOC-02 / MKT-01の完了条件は未充足。** [市場選定調査](BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)の条件付きbitbank案を正式採用へ変更する根拠は増えていない。価格・ローソク足・板・約定・ペア設定データAPIを呼ばず、profile凍結、データ取得、取引、課金、外部照会送信、push、PR変更を行っていない。

## 1. 通信経路と観測の限界

cloud-environment-runtime skill、networking参考文書、`/etc/codex/network-policy.json`を確認した。起動時policyはversion 1、HTTP restricted、VPNなし、TCP追加許可なし。GitHub・raw.githubusercontent.com等は掲載されている一方、下表5hostは掲載されていない。今回の`environment_status`呼出しは`INVALID_ARGUMENT: The environment configuration changed. Try again.`で観測を返さなかった。従ってこの結果から最新設定の適用済み・readyを主張しない。親担当の直前観測でも追加hostの適用は確認できていない。

継承proxy・CA trustとTLS検証を保ち、各未到達hostへ下記URLを**1回ずつ**通常HTTPSで確認した。全件curl exit 56、HTTP origin応答未取得（write-out `000`）、proxyの`CONNECT tunnel failed, response 403`。403は取引所が資料公開や利用を拒否したという証拠ではなく、この環境で本文へ到達していない証拠である。proxy応答Dateは2026-10-22 15:41:41 GMT。拒否後に再試行・別hostへの迂回・proxy解除・TLS無効化を行っていない。

| URL | 目的 | 今回の結果 / 公表日・適用日 |
|---|---|---|
| <https://api.github.com/repos/koheismh/Asteriade> | repo metadataの読取 | CONNECT 403。metadata本文未取得 |
| <https://bitbank.cc/> | 公式の料金・規約の入口 | CONNECT 403。公表日・適用日未確認 |
| <https://www.bitbank.cc/> | 既存許可案の別hostの到達確認 | CONNECT 403。公表日・適用日未確認 |
| <https://api.coin.z.com/docs/> | GMO公式API文書 | CONNECT 403。仕様の公表日・適用日未確認 |
| <https://coin.z.com/> | GMO料金・規約の入口 | CONNECT 403。公表日・適用日未確認 |

## 2. DOC-02: 公開HTMLとGit refsで確認できた範囲

`https://github.com/koheismh/Asteriade`はHTTP 200で**Public**表示を確認した。取得時点の公開HTMLでの確認であり、管理画面の設定履歴を調べたものではない。`git ls-remote --symref origin ...`は既定HEADがmasterであることと下表のSHAを返した。Gitの読取のみでremote変更はない。

| 対象 / URL | 今回の公開HTML表示 | 固定Git SHA |
|---|---|---|
| 既定HEAD / master | repo公開HTMLもmaster表示 | `8b55314cb6e5ea655400b9fb46dfa00eee8964bc` |
| [PR #2](https://github.com/koheismh/Asteriade/pull/2) | HTTP 200、Draft、base `codex/investment-research-stage0`、head `docs/scope-reduction-review-20261021` | pull head `58ba796c8bdfdf4b048ed76db70d3855a4ba6fea` |
| [PR #3](https://github.com/koheismh/Asteriade/pull/3) | HTTP 200、Draft、base `codex/investment-research-stage0`、head `codex/lean-mvp-synthetic-stage0c` | pull head `e77638eb644df7791f1997c2f8a84ad7970bb21d` |
| [PR #4](https://github.com/koheismh/Asteriade/pull/4) | HTTP 200、Draft、base `codex/lean-mvp-synthetic-stage0c`、head `codex/btc-spot-profile-research` | pull head `6d01d08897b4ed53de01138ee737cc6ef9deb119` |
| `codex/investment-research-stage0` | branch ref読取 | `f721104b6adc6880e6d4bd8671cf78bc4aa5ff6c` |

3件とも公開HTMLのReviewer欄は`No reviews`。ただし動的領域は`There was an error while loading`を含むため、認証付きレビュー・全コメント・status checksの完全取得を意味しない。PR本文のテスト件数は過去報告であり今回の再実行ではない。

- [open PR一覧](https://github.com/koheismh/Asteriade/pulls)はHTTP 200だが`Failed to load pull requests`。#2/#3/#4がPR全件だとは確定しない。
- [Actions画面](https://github.com/koheismh/Asteriade/actions)はHTTP 404。Actions無効・runなし・CI成功のいずれとも確定しない。
- branch protection / rulesets / required checks / merge制限は未確認。公開HTMLに見えないことを、保護なしやmerge可能の根拠にしない。
- Gitが返した`refs/pull/2/merge`、`3/merge`、`4/merge`はそれぞれ`dd5181cb22d7da7b32c7f17d0b5b191964426925`、`5a485c25571b10ce9b25aa20f6a7255159986038`、`5d6c6e0c129d1a38c13535faa052bdd872259460`。これらのrefの存在はマージ実行・承認・CI合格の証拠ではない。

## 3. MKT-01: bitbank公式文書の固定版を再取得

[bitbank公式API文書repo](https://github.com/bitbankinc/bitbank-api-docs/tree/0badd68019646171826625b074cfef4235c3e713)を通常Git HTTPSで文書のみ一時cloneし、rawの固定SHA文書もHTTP 200で読んだ。最新HEADは既報と同じ`0badd68019646171826625b074cfef4235c3e713`。commit author/committer日時は**2026-09-11T13:54:51+09:00**。これはrepoのcommit日時であり、各API仕様・料金・規約の発効日ではない。

| 固定版資料 | 再確認できた内容 | 引き続き未確認 |
|---|---|---|
| [pairs.md L15](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/pairs.md#L15) | `btc_jpy / btc / jpy / delisted=false`の文書記載 | 現時点の稼働状態・実際のpair設定値 |
| [public-api.md L293](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/public-api.md#L293)、[日本語版 L294](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/public-api_JP.md#L294) | `1hour`は`YYYYMMDD`要求、OHLCV末尾はUnix ms、response `timestamp`は公開日時 | 日付bucketのtimezone、足start/end、確定・訂正条件、最古日・保持期限・連続性、各足当時のpublication/receipt |
| [rest-api.md L946](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/rest-api.md#L946) | `fee_amount_base` / `fee_amount_quote`、約定時刻等のschema | BTC現物の現行料率・徴収通貨・適用日・丸め・例外 |
| [rest-api.md L1653](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/rest-api.md#L1653) | base/quote別maker/taker rate、最小量、最大量、桁、停止flagのフィールド定義 | 実値・tick/lot/丸め。無認証との記載もデータAPI呼出し許可とは扱わない |

英日両版のCandlestick節を照合したが、上記未確認項目を補う明記は確認できなかった。認証timestampに関するUTCの記載を日付bucketのtimezoneへ転用しない。repo treeにLICENSEファイルは見つからなかった。これは市場データの使用権を肯定も否定もせず、API仕様の公開から市場データ保存等の許諾を導けない。

### PR #4の追加コメントは調査先を示す補助根拠

[追加コメント](https://github.com/koheismh/Asteriade/pull/4#issuecomment-6321277066)はHTML上の投稿時刻が**2026-10-21T16:39:57Z（2026-10-22 01:39:57 JST）**、本文が「2026-10-22 / 公式公開情報、未マージの補足」。別の閲覧環境での確認と明記されている。今回読めたのはGitHub上のコメントであり、以下の取引所本文ではない。コメントの数値や時刻を現行公式条件として採用しない。

| コメント内の公式URL | コメントが述べる内容 / 今回の扱い |
|---|---|
| <https://api.coin.z.com/docs/> | 現物`BTC`とレバレッジ`BTC_JPY`の区別、1hour日付切替JST06の所在。今回本文未到達、現行契約として未確認 |
| <https://coin.z.com/jp/corp/guide/fees/> | 現物BTCのMaker -0.01% / Taker 0.05%という閲覧時表示の報告。今回の検証値ではなく、発効日・tier・通貨・例外を含め未確認 |
| <https://bitbank.cc/blog/articles/726061459> | 「2026年2月2日付BTC/JPY料金改定」の所在。告知日・発効日・具体料率は公式本文未確認 |
| <https://bitbank.cc/docs/fees/> | 現行料金表の照合先。今回未到達host内のため追加requestなし |
| <https://support.bitbank.cc/hc/ja/articles/360019410033-API%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6> | API説明の所在。今回未アクセス。APIが公開されていることとデータ利用権を区別 |

### 保管・外部AI送信・再配布の権利は別々に保留

| 候補 | Raw/正規化データの保管 | 外部AIへの送信 | 再配布・GitHub公開 |
|---|---|---|---|
| bitbank | 未確認: 適用規約・条項・用途・期間の一次根拠なし | 未確認: 委託先処理/外部送信の範囲・条件を未取得 | 未確認: Raw/加工データ/成果物の各許諾を未取得 |
| GMOコイン | 未確認: 旧研究の保存実績は根拠にしない | 未確認: 公開APIから許諾を推定しない | 未確認: 旧repo公開から許諾を推定しない |

料金表は執行費用の一部であり、spread/slippage、足品質、実執行可能性の根拠とは分ける。権利が不明のまま実データ取込へ進めず、ユーザーの承認だけで第三者の許諾不足を補わない。今回先方へ問い合わせていない。

## 4. 必要な接続先と残blocker

接続可能にするには通常の環境設定ワークフローによる反映が必要。本調査では設定変更・適用を実行していない。

| host | 必要な読取 | 状態 |
|---|---|---|
| `api.github.com` | PR base/head、reviews/checks、repo visibility、rulesets/branch protection等 | 既存追加案。今回CONNECT 403。到達後もendpointに応じた既存identityの権限確認は別 |
| `bitbank.cc`, `www.bitbank.cc` | 現行料金表、改定告知、規約・API/情報利用条件 | 既存追加案。今回両host CONNECT 403 |
| `api.coin.z.com` | `/docs/`の静的API仕様 | 既存追加案。今回CONNECT 403。市場データendpoint取得とは別 |
| `coin.z.com` | 現行料金・利用規約・データの取扱い条件 | 既存追加案。今回CONNECT 403 |
| `support.bitbank.cc` | 上記公式API説明、必要なら利用条件の所在 | PR #4にリンクがある追加候補。policy未掲載、今回は未アクセス |
| `blog.bitbank.cc` | 公式文書READMEが案内する`/tag/service`のAPI変更告知 | 追加候補。policy未掲載、今回は未アクセス。`bitbank.cc/blog/...`と同じhostではない |

DOC-02は公開HTMLからDraft/base/head/Publicの部分を更新できたが、レビュー/CI全件・branch保護の完全性が残る。新しい個人tokenを要求せず、適用済み接続と既存identityで読取可能な範囲をまず確認する。取得できない管理設定は「不明」として扱う。

MKT-01は固定bitbank文書の再確認と照合先の整理まで。公式規約の適用日・具体条項・上記3権利、GMO現行仕様、両候補の現行fee/丸め・履歴/時計の根拠が残る。文書に保証がなければ、将来の小標本の明示許可や先方回答など別の証拠が必要であり、今回の通信許可だけで埋まる項目とは限らない。MKT-02のユーザーによるvenue/quote・研究範囲の選択、実データ取得の対象/期間/保存先/量の許可、Windows実証やStage出口は別途残す。

## 5. 証跡と検証

読取コマンドは通常の`curl`（redirect自動追従なし、TLS検証有効）、`git ls-remote`、公式文書repoの一時clone、文書の静的照合。市場APIの例示curlや旧データCLIを実行していない。取得本文は一時領域`/tmp/asteriade-source-review-20261023/`にあり、repoには本文・credential・市場データを追加していない。一時領域の存続は保証しないため、固定文書はSHA URL、可変HTMLは下記checksumで今回読んだsnapshotを識別する。

| snapshot | SHA-256 |
|---|---|
| repo公開HTML | `5a0d547a0edc90735396d1b2aaeba8ef169d619abce482341098adccb9f4726f` |
| PR #2 HTML | `ab405ab1764dbaa6b120bba59e7dfbad6aa85e91baf09087a47bb46f7ff96f79` |
| PR #3 HTML | `595fbeae45f587dddfcedce7e9618ccd84875466350d22713c23e80321ebe59d` |
| PR #4 HTML | `3c7278e7a91d754428f815c8268111014fdfc3432d58f69af7a400fe1002f0e9` |
| bitbank固定版 public-api.md | `58d1756e2fb82ab66df920036b3c60e2a43b84d5a953705756d3390bfe93fed4` |
| bitbank固定版 rest-api.md | `f15555be193d332febe1a800ed0f93dcd6f61e61fbc5dd350ad011e38d9201d8` |
| bitbank固定版 pairs.md | `3e3638cbf74c542d75c5c9a0ff5be7ee2ff79175234a75623f808d50c553c324` |

文書の相対リンク・固定SHA表記・権利の区別とdiff whitespaceを確認した。アプリや依存を変更しない資料調査のため、アプリテスト・Windows実機・市場データ品質試験は実行していない。台帳上の提案はDOC-02 / MKT-01とも**部分進捗を添えたBLOCKED維持**であり、DONEへの更新は提案しない。
