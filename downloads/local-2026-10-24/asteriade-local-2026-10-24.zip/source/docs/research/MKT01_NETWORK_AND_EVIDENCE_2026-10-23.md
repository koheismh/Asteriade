# MKT-01: 通信設定と一次資料の確認状況

2026-10-24 03:16 JST追記: 実環境と下書きの状態は前回と同じ。反映手順を調べ直し、**ユーザー画面での設定保存によるruntime更新要求**と**Publishによるsnapshot公開**を区別した。詳細は末尾の追記を参照。市場資料の新規取得は未実施。

確認日: **2026-10-23 07:37 JST（Asia/Tokyo）**。担当はこのチャット（Sol担当としてLuna割当を代行）、サブエージェント未使用。branch `codex/model-task-plan`、HEAD `6d01d08897b4ed53de01138ee737cc6ef9deb119`。既存未commit作業を保全した。

**MKT-01はBLOCKEDを維持する。** 追加通信先は下書きにあるが、現在の実行環境で適用を確認できない。ユーザーの「許可の適用を確認できない場合や、接続が拒否された場合は、迂回・繰り返し再試行をせず、不足条件を記録」に従い、今回の公式サイトへのrequestは0件。過去のCONNECT 403を今回の実測結果とは記載しない。

## 1. 下書き・Publish・実環境を区別した観測

cloud-environment-runtime [SKILL.md](skill://plugin_connector_1p_c5b7d5df5d7081918f2c4be5a633ed5d/cloud-environment-runtime/SKILL.md)の「Network policy is applied only when its current state is `enforced`.」に従い、`environment_status`、環境設定下書きの読取、起動時の`/etc/codex/network-policy.json`を確認した。

| 対象 | 今回の読取結果 | 判断できる範囲 |
|---|---|---|
| 環境設定下書き | revision 3、restricted、custom host 7件 | 必要な通信先が下書きに保存されている |
| Publishの実施状況 | 今回の読取だけでは確定できない | 下書きの存在やrevisionからPublish実施済みとは推定しない |
| 現在の実行環境 | `observations_current=true`、spec/observed revision 2、network `state=unknown`、`allowed_hosts=[]` | 必要6 hostはいずれもeffective policyにない。適用済み・enforcedを確認できない |
| 起動時policy | version 1、restricted、VPNなし、必要6 hostの掲載なし | 実環境への適用確認を補う観測。起動時snapshotだけで現在の全状態を断定しない |

下書きの7 hostは`api.github.com`と、今回対象の`api.coin.z.com`、`coin.z.com`、`bitbank.cc`、`www.bitbank.cc`、`support.bitbank.cc`、`blog.bitbank.cc`。下書きrevisionとruntime spec revisionは異なる種類の番号で、大小だけから公開/適用状態を判断しない。現在のinstanceは下書きのbase versionと同じconfig versionを参照しているが、それも公開版一覧を照会した結果ではない。

設定の変更・Publish・proxy/TLS変更・接続先の迂回は行っていない。下書きを再保存しても現在の適用不足を解決した証拠にはならないため、今回再保存していない。

## 2. 保存済みのbitbank固定版だけをローカル再照合

[前回の取得記録](SOURCE_ACCESS_REVIEW_2026-10-23.md)は同日00:41–00:44 JSTの取得。今回その記録と保存済み原本を照合し、3文書すべてのSHA-256が前回記録・一時clone内の同名ファイルと一致した。cloneの固定commitは`0badd68019646171826625b074cfef4235c3e713`。**今回の最新サイト取得・最新HEAD確認ではない。** commit日付を仕様の公表日/発効日へ転用しない。

| 固定版の公式資料 | 今回ローカルで再確認した記載 | 依然unknownの条件 |
|---|---|---|
| [pairs.md L15](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/pairs.md#L15) | `btc_jpy`、base `btc`、quote `jpy`、delisted=false | 現時点の稼働状態・実際のpair設定値 |
| [public-api.md L293](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/public-api.md#L293) | `1hour`の要求日付は`YYYYMMDD`。OHLCV末尾はUnix ms、response `timestamp`はpublished atと記載 | 日付bucketのtimezone、足start/end、確定/訂正、当時の各足のpublication/receipt、最古履歴・保持・網羅性・取得制限の十分な根拠 |
| [rest-api.md L946](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/rest-api.md#L946) | `fee_amount_base`、`fee_amount_quote`、`maker_taker`、`executed_at`のschema | BTC現物の現行料率、適用日、実際の徴収通貨、例外、丸め |
| [rest-api.md L1653](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/rest-api.md#L1653) | base/quote別maker/taker rate、最小量・最大量、price/amount digits等の参照フィールドの所在 | tick/lot・最低数量・最小代金・丸めの実値/適用条件。桁数や最小量だけからstepを推定しない |
| [rest-api.md L162](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/rest-api.md#L162) | Private REST APIの節に、ユーザー別の通常QUERY 10回/秒、UPDATE 6回/秒、system-wide制限、HTTP 429の記載がある | Public OHLCVの取得上限としては未確認。Privateのbase endpointとPublicのbase endpointが異なり、この数値を取込profileへ転用しない |

responseの公開時刻を過去の全足の当時の公開時刻として扱わない。文書にあるcurl・認証・API呼出しの例は読取対象であり、実行していない。

rate limitについて[固定CHANGELOG](https://github.com/bitbankinc/bitbank-api-docs/blob/0badd68019646171826625b074cfef4235c3e713/CHANGELOG.md#L357)は2022-12-15に説明追加と記録している。これは文書変更の記録で、現行料率・データ条件の発効日やPublic APIへの適用を証明しない。ローカルREADMEの公式変更告知URLも照合した。規約・権利・timezone・保持・丸め等を固定文書内で検索したが、この作業で不足条件を補う根拠は得られなかった。文書内で見つからないことを権利の許可/禁止の断定に使わない。

## 3. 権利と市場条件の不足

| 権利 | bitbank | GMOコイン |
|---|---|---|
| Raw/正規化データのローカル保存 | **unknown**。許可条項・用途・保存期間の一次根拠なし | **unknown**。旧研究の保存実績は許諾ではない |
| 外部AIへの送信・委託処理 | **unknown**。送信先/加工の条件を未取得 | **unknown**。公開APIであることから推定しない |
| 公開・再配布 | **unknown**。Raw/加工データ/成果物を分けた許諾未確認 | **unknown**。旧repo公開から推定しない |

| 調査項目 | bitbankの残条件 | GMOコインの残条件 |
|---|---|---|
| 現行手数料 | 公式料金表と改定告知を取得し、公表日/適用日、maker/taker、徴収通貨、例外/丸めを照合 | 同左。GitHubコメントの料率は現行公式条件として採用しない |
| 1時間足の時計 | 日付bucket/timezone、足start/endを根拠付きで確認 | 現物とレバレッジのsymbol/sourceを確認し、bucket/timezone/start/endを確認。旧JST06を自動採用しない |
| 確定・訂正・availability | 条件と公表/受領時刻の意味を確認 | 現行の公式本文が未取得。旧研究の仮定を代用しない |
| 履歴・保持・取得制限 | 最古日/保持/連続性/上限の明記と限界を確認 | 同左。旧研究の開始日を提供開始日と呼ばない |
| tick/lot・最低数量 | 公式の現物仕様と適用条件・実値の所在を確認 | 現物BTCの公式仕様・適用条件を確認 |

公式本文の取得を再開する際の既報の照合先は以下。**今回は未アクセスで、以下の公表日・適用日・具体条項は新たに確認していない。** 規約の正確なURLは公式サイト内の案内から確認し、未確認のpathを作らない。

- bitbank料金: <https://bitbank.cc/docs/fees/>、既報の改定告知: <https://bitbank.cc/blog/articles/726061459>
- bitbank API説明: <https://support.bitbank.cc/hc/ja/articles/360019410033-API%E3%81%AB%E3%81%A4%E3%81%84%E3%81%A6>
- bitbank変更告知の入口: <https://blog.bitbank.cc/tag/service>
- GMO API文書: <https://api.coin.z.com/docs/>、料金: <https://coin.z.com/jp/corp/guide/fees/>

## 4. 上位モデルへの引継ぎと再開条件

1. 環境設定画面で公開済み設定を確認し、必要6 hostを含む設定がこの実行環境で有効になる手順を確認する。読取だけではPublishが実施されたか、既存タスクへどのように反映されるかは確定できない。
2. 実環境でcurrentな観測と`state=enforced`、必要hostを確認してから通常の許可経路で公式本文を読む。接続拒否時は再試行や迂回をしない。外部問い合わせは今回の範囲外。
3. 条項・公表日/適用日が得られた欄だけを根拠付きで更新する。公式に記載がない条件はunknownを維持し、ユーザーの承認だけで第三者の許諾不足を補わない。
4. 上位モデルのMKT-02/03には、公式根拠に加えてvenue/quote・研究目的/期間の選択が必要。今回のbitbank優先案を正式採用せず、未知のfee/時計/丸めや研究期間を凍結しない。基準費用・benchmark/coverage・独立goldenはその後に決める。

今回の変更は本書・tasks.md・HANDOFF.mdだけ。観測と原本照合の証跡はignoredな`.local/validation/mkt01-network-2026-10-23.json`、`mkt01-cached-sources-2026-10-23.json`に保存した。追加で読んだREADME/CHANGELOGも固定commitのGit blobと照合して一致した。原本は一時領域なので存続保証はなく、前回記録の固定URL/hashを参照する。

`git diff --check`、変更文書3件のローカルリンク47件、task数41/MKT-01のBLOCKED維持を確認。作業前40ファイルのhashと比較し、既存ファイルで変更したのはtasks.md/HANDOFF.mdだけ。アプリ/依存/CI・数値試験は変更/実行していない。市場データAPI、取引、課金、問い合わせ送信、公開/pushは行っていない。

## 5. 2026-10-24: 反映手順の診断と残る画面操作

03:16 JSTの再観測はcurrent、runtime spec/observed revision 2、追加allowed_hosts空、state unknown。下書きrevision 3の必要hostは保存済み。起動時policyにも必要6 hostはない。今回も未許可先へのrequestは行わず、同じ下書きの再保存・proxy/TLS変更・迂回はしていない。

利用可能ツールを確認した結果、runtime読取・下書き読取/保存はあるが、runtime適用・Publishを実行するツールはない。独立したagentへ再依頼しても、このツール範囲は変わらないため委任していない。

cloud-environment-onboarding [SKILL.md](skill://plugin_connector_1p_ed5feb9070a08191b08c81c47947bc16/setup/SKILL.md)は「Saving persists configuration; it does not execute scripts, apply runtime changes, or publish.」と明記する。[onboarding.md](skill://plugin_connector_1p_ed5feb9070a08191b08c81c47947bc16/setup/references/onboarding.md)では「Saving configuration edits through the user-facing editor can request a runtime update; propagation can be asynchronous.」と説明されている。

従って、先の「Publishして反映」という案内だけでは手順の区別が不十分だった。次の操作が必要である。

1. **環境設定画面**でネットワークの許可先を開く。保存済みの必要6 host（および既存api.github.com）を保持する。
2. **その画面から設定を保存**し、製品が提供するruntime更新フローに従う。画面からの保存は更新を要求できるが、反映完了は保証しない。
3. 再開時にagentがruntimeを再観測し、current/enforcedと必要hostを確認後、公式文書の取得を行う。

Publishは準備したfilesystemのsnapshot・active version作成・onboarding環境の復元/再接続に関わる別の処理で、無関係な既存タスクを移行しない。今回これらを実行済みとは扱わず、タスクやcheckoutを作り直す操作も行っていない。

現在の制約は担当モデルではなく、製品側での設定保存/反映操作が残っていること。MKT-01/MKT-02/03は未完了を維持する。今回の観測はignoredな`.local/validation/mkt01-network-2026-10-24.json`に保存した。数値試験・原本再取得は行っていない。
