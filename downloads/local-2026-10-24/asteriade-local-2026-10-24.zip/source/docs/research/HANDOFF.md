# Asteriade 現在地と引き継ぎ

更新: 2026-10-24（Asia/Tokyo）。方向: Windows 11ローカルの自律AI投資研究。**Stage 0合成実装に加え、文書整合・Windows境界設計・engine比較・入力品質/証跡の事前検査まで実施。市場profileの公式根拠・Windows実効境界は未確定、Stage 0全体未合格、Stage 1A/1B未着手、実注文なし。**

## ローカルPCへの移行準備（2026-10-24）

- [ローカル引継ぎ手順](LOCAL_DEVELOPMENT_HANDOFF_2026-10-24.md)。ユーザーは全環境で編集開始が失敗し、画像で環境編集用`POST /api/codex-cloud/v1/environment-configs/…/drafts`の403・空responseを確認した。ブラウザ通常/シークレットと新旧環境で再現。原因の詳細は未確定で、公式サイトへのproxy CONNECT 403とは別の観測である。
- ユーザーの依頼に従い、現在のbranch/HEAD、現在branchのGit履歴、未commitを含む115作業ソース、検証サマリーをローカル用ZIPへまとめた。元checkoutを保全し、commit/pushや環境削除は行っていない。Linuxの新規フォルダへ復元してHEAD/hash/status一致、Go164成功/helper1skip、Python78成功/4skipを確認。改変等7ケースは出力を上書きせず拒否。Git設定継承のレビュー指摘を修正し、復元器内のGitは設定注入を無効化・file protocol限定。手元PC/Windowsの検証ではない。
- このチャットの実行環境はクラウドのまま。PCでは復元先をローカルCodexで開いて基準検証し、そのPCで許可された通常経路からMKT-01の文書調査を再開する。Windows/市場権利/Stageの未決は保持する。

## MKT-01の反映手順診断（2026-10-24 03:16 JST）

- Sol担当として通信状態を再確認。下書き7 hostは保存済みだが、runtimeの追加許可空・state unknownは変わらず、公式サイトへ接続していない。
- [調査記録§5](MKT01_NETWORK_AND_EVIDENCE_2026-10-23.md)に反映手順を明確化。**環境設定画面からの保存**がruntime更新を要求できる。agentの下書き保存には適用機能がなく、Publishはsnapshot/active version作成等の別処理である。
- 次はユーザー画面で必要hostを保持して設定保存→runtime更新→agentがcurrent/enforced/hostを確認→MKT-01再開。利用可能ツールに適用/Publish機能がないため、同じ下書き保存や接続を反復しない。MKT-01はBLOCKEDを維持。アプリ/数値試験は未実施、既存作業は保全。

## MKT-01の最新確認（2026-10-23 07:37 JST）

- [通信設定と一次資料の確認記録](MKT01_NETWORK_AND_EVIDENCE_2026-10-23.md)。このチャットがSol担当としてLuna割当を代行。下書きrevision 3に必要hostがある一方、現在のruntimeは追加allowed_hosts空・state unknown。Publishの実施有無を断定せず、実環境への適用未確認とした。
- ユーザー指定に従い今回は公式サイトへのrequestなし。保存済みbitbank固定commitの3文書を前回hashとローカルcloneへ照合し、一致を確認した。新しい料金・時計・規約の公式本文を取得したとは扱わない。
- 保存/AI送信/公開の権利は各候補ともunknown。MKT-01はBLOCKEDのまま。次は通信設定の実反映確認→公式本文→上位MKT-02/03。市場選定・profile凍結・実データ取得は行っていない。文書3件のみ変更、アプリ/数値試験は未実施。

## Sol引継ぎ後の修正（2026-10-23）

- [今回の前提確認と修正記録](SOL_STAGE0_READINESS_2026-10-23.md)。同じbranch/HEADと既存未commit作業を保全。ENG-01/SAFE-02/MKT-04の不足条件が残ることを確認し、本体の状態を維持した。
- SAFE-02準備用の既存preflightで、DWORD超過SIDと先頭ゼロの別表記を受理する不備を修正。全subauthorityをcanonical ASCII decimal/uint32に限定し、正常profileの既存hashを維持。PRE-01〜04の再実装ではない。
- このチャットが実装・記録・検証を担当し、`gpt-6.1-sol`指定の子がread-onlyレビュー。追加指摘なし。今回のPython全体は82成功、標準構成は78成功/4skip。Go/依存/Store/Runnerは変更なし、Windows実機と市場取得は未実施。
- runtime観測は追加allowed_hosts空、state unknown、spec revision 2。下書き7 hostの実適用を確認できず、拒否先へ再試行していない。次は公式資料/市場選択→上位MKT-02/03→Sol ENG-01→上位ENG-02→WindowsでSol SAFE-02→上位SAFE-03。

## 最新の継続作業（2026-10-23）

- [tasks.md](../../tasks.md)のSAFE-01/DOC-01、追加したPRE-01〜04を完了。[継続作業記録](STAGE0_CONTINUATION_2026-10-23.md)に成果・再現手順・次の条件を記録。41タスク/42AT、モデル担当と依存を保持する。
- 親が[Windows境界ADR](WINDOWS_BOUNDARY_ADR_2026-10-23.md)と[証跡preflight](WINDOWS_EVIDENCE_PREFLIGHT_2026-10-23.md)を担当。Solが文書/出典調査、親の固定契約に沿う[合成engine比較](SYNTHETIC_ENGINE_COMPARISON_2026-10-23.md)と[入力品質検査](SYNTHETIC_INPUT_QUALITY_2026-10-23.md)を担当し、親がレビュー・再実行。GPT-6.1-Lunaは未提供のため未実行。
- 最終Python77件成功。外部engineなしの標準構成は73成功/4skip。既存Go/依存は前回の最終検証後から変更なし。Python/Backtraderを製品実行依存にしていない。全能力false、実市場・Windows実機は未検証。
- [公開HTMLと公式文書の再確認](SOURCE_ACCESS_REVIEW_2026-10-23.md)でPublic表示とPR #2/#3/#4のDraft/base/headを確認。branch保護/CI/レビュー全件、取引所の規約・料金・時計等は未確認。DOC-02/MKT-01はBLOCKEDのまま。
- 必要な7 hostを環境設定下書きへ保存し再読取で確認。設定画面での確認・保存/Publishと実環境反映が残る。repository refは依頼時のmasterであり、今回の未commit実装が新環境で自動復元される保証はない。既存作業checkoutを保全する。
- 次は一次資料と市場選択→親MKT-02/03→Sol ENG-01→親ENG-02→WindowsでSol SAFE-02→親SAFE-03。現環境だけで新たに完了できるREADYはなく、Lunaだけの残件ではない。commit/push/PR変更は未実施。

## 合成Registryの実装記録（2026-10-22）

- 最初に [tasks.md](../../tasks.md) を読む。最適モデル、依存、状態、完了条件、実担当、全42AT対応を記録している。製品Manager/Reviewerの固定モデル指定ではない。
- GitHubの7ブランチをread-only確認し、最新の `codex/btc-spot-profile-research` / `6d01d08897b4ed53de01138ee737cc6ef9deb119` を基準に、既存チェックアウトでローカル `codex/model-task-plan` を作成。masterへ未統合。今回commit/push/PR作成なし。作業変更を保全する。
- 親が[上流契約](UPSTREAM_EXECUTION_CONTRACT_2026-10-22.md)と[独立試験ベクトル](HOLDOUT_TEST_VECTORS.md)を作成し、DEV-01/HLD-02/HLD-03/HLD-04/INT-01と前提HLD-01を実施した。[実装・検証記録](STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)が今回の証拠。
- 合成`TOY/CASH`だけの状態・期間重複、schema v2、原子的claim/receipt/outbox、immutable manifest、新Run、公開/訂正、候補履歴、故障復旧を追加。v1 DDL/checksumとfreeze v1は維持。研究APIはGo内部のみ、Runnerの全能力falseを維持し、科学的validへ昇格させない。
- Open/研究書込/claim確認で追記履歴と全研究投影・receiptのhashを照合。DB隣のwitnessが欠落・不一致ならunknown。復元で未使用性を復活させない。全ディスクrollback・管理者改竄への耐性やWindows実効境界は未証明。
- 親がコード・試験・統合を担当。GPT-6.1-Sol指定の子が読み取りレビューを行い、投影巻戻し・商品alias・訂正条件を指摘、親が修正・回帰追加。最終レビューで新たな重大不整合なし。GPT-6.1-Lunaは選択不可のため未実行で、旧GPT-6-Lunaに読み替えていない。
- 固定Go 1.27.2のsetupと再実行成功。最終race付きGo164件（58トップレベル）成功、failed 0、subprocess専用helper 1件skip。Python24件、vet、Linux live smoke、Windows cross-build成功。生成物・JSONログはignored領域。Windows実行は未確認。
- cloud-environment-onboardingのinstall_script/start_skillを現在のGo開発手順へ下書き保存。保存は公開や新タスク復元実証ではない。ネットワーク・秘密・repository設定は変更していない。
- GitHub APIはForbiddenで、PR/Actions/保護設定の最新状態は未確認。Git読取成功からAPI権限や公開範囲を推定しない。
- 最新市場調査はBTC現物・1市場1ペア・1時間足が前提。venue/quote/期間/権利/fee等は未確定。古い時間足未定の記述はDOC-01で時点を区別して整合する。
- 次は親SAFE-01、Luna DOC-01。残るSol作業は市場golden/権利・採用engine・Windowsの依存待ち。後段はGATEDのまま。

**以下は直前までの調査・実装記録。今回の実行結果・許可を意味しない。**

開発基準は[REQUIREMENTS.md](../REQUIREMENTS.md)。前回の合成参照検証ブランチは `codex/lean-mvp-synthetic-stage0c`、開始元はfetch済み `codex/investment-research-stage0` の `f721104b6adc6880e6d4bd8671cf78bc4aa5ff6c`。masterへマージしていない。PR #2は参照のみで、マージ/クローズしない。受領Draft 2/判断原本と過去記録は保全する。

## 直前の限定調査（2026-10-22）

- [Draft PR #3](https://github.com/koheismh/Asteriade/pull/3)の公開本文・Draft/base/headとGit head `e77638e`を確認。PRの追加/動的コメント全件は未確認。PR #2/#3のマージ・クローズ・編集は行っていない。
- 現在の作業ブランチは `codex/btc-spot-profile-research`、PR #3 headを起点とする。[BTC現物profile比較](BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)が今回の記録。前回のブランチ/Push記録は履歴として下に保全する。
- 候補はbitbankとGMOのBTC/JPY現物に絞る。bitbankの公式API仕様を固定SHAで確認し、bitbank/BTC-JPY/1hour/単一public OHLCVを**調査優先案として暫定推奨**。保管権、現行料金、GMOの現行公式仕様、実履歴の最古日/網羅性が未確認で、正式選定ではない。今回のユーザー範囲でBTC現物・1市場1ペア1時間足を扱う。
- bitbank文書repo `0badd68019646171826625b074cfef4235c3e713`、旧quant `9a0aee09965da55b5050af7a981ace3f5eec8dc7` を静的参照。最新fee数値やデータ保管許諾を推測で埋めない。旧20bps/JST06 financing/日付境界を別venueへ流用しない。
- 未受領データ/足openの先取りを避ける例、fee/丸め・履歴・権利の確認表、unsupportedな売買方式と探索範囲、ユーザー選択/技術決定/証拠待ちを記録した。
- 通常proxyでGMO公式文書にCONNECT 403。環境設定下書きに既存`api.github.com`を保持し、`api.coin.z.com`、`coin.z.com`、`bitbank.cc`、`www.bitbank.cc`を追加したが、実行環境には未反映。反映後に**文書だけ**を読み、規約・料金の比較を仕上げる。実データ/有料サービス/Runner/注文/大規模実装は今回禁止のまま。
- アプリ/依存/CI/合成参照コードは変更せず、前回のテスト件数を今回実行済みとは記載しない。今回確認したのは出典/差分/Markdownリンクで、数値エンジン試験ではない。

## 完了した範囲

- 旧Go/SQLite/loopback UI/API・承認・停止/復旧基盤を維持。Runnerは全能力false、unverified、start API拒否。
- 0A: `internal/research`の最小Spec envelope/凍結identity。[記録](STAGE0A_IDENTITY_2026-10-21.md)。今回改変せず、製品RunnerやDB研究schemaへ未接続。
- 0B: quant-btc-lab/Freqtrade/Backtraderの固定ソース調査・再利用判断。[比較報告](STAGE0B_REUSE_EVALUATION_2026-10-21.md)、[引き継ぎ](STAGE0B_HANDOFF.md)。実データ・旧成績・コードを移植していない。
- 0C今回分: Python標準ライブラリの独立合成参照例。時刻/未来情報、現物会計、曖昧性/失敗拒否、独立oracle。**新規24テスト成功**、既存Go **40トップレベル/105サブテスト込み成功**。DD率履歴と売却fee不足の欠陥を独立テストで発見・修正。[実測と限界](STAGE0C_SYNTHETIC_VALIDATION_2026-10-21.md)、[実行手順](../../reference/README.md)。
- PR2本文とユーザー指示を反映した[Stage 1A/1Bスコープ案](MVP_SCOPE_REVISION_2026-10-21.md)。1Aは単一Manager＋機械ゲート、1Bで既存有限討論を追加し品質/費用/時間比較。全42製品AT・費用/科学/安全ゲートを保持する。
- [Market Knowledge最小仕様](../MARKET_KNOWLEDGE.md)。MD/JSON例は未実施研究の記入例であり、今回の合成会計テストや市場優位性の証拠ではない。

## 未完了と固定する境界

初回市場種別はユーザー選択の**暗号資産現物（BTC等）**。venue/pair/feed/timeframe、利用/保管/外部送信権、注文/費用/tick/lot/丸めprofileは未決。合成参照値を市場仕様へ流用しない。0C市場部分、engine同条件実行比較/配布、0D Holdout registry/Windows実効境界、Provider/研究loop/UI統合は未完了。

時計/会計は開発専用プリミティブで、将来値を物理的に隠すデータAPIやOS隔離は未実装。Pythonを製品Runnerとして採用した判断でもない。Go CP＋独立Python Runner、旧資産の権利確認後の部分再利用は比較候補として維持する。旧M6等の科学バグと消費済みHoldout修正を独立確認と呼べない点は0B記録を参照する。

Managerは強制科学/安全/予算ゲートを解除できない。Stage 1Aは`review_status=not_enabled_stage1a`を明記し、割当済みReviewerの失敗を1A切替で回避しない。Stage 1BはReviewer発言最大2回、採否理由/最終判断を残す。全候補/選抜系譜/benchmark/Holdout露出を保全し、個人金融情報・secret・private raw dataは公開Git/外部AIへ送らない。

## 再開順序と開始条件

1. 今回の差分と[検証記録](STAGE0C_SYNTHETIC_VALIDATION_2026-10-21.md)、[実装計画](../IMPLEMENTATION_PLAN.md)、[0C市場判断メモ](STAGE0C_DECISIONS.md)をレビューする。今回の許可範囲を超えて自動継続しない。
2. 次の限定作業はvenue等の資料確認とprofileの独立golden計画。実市場データの取得/費用発生は別の許可を要する。
3. ユーザー手元のWindows 11で必要な境界・Holdout・復旧否定試験を行う。クロスビルドや既存基盤検証スクリプト成功だけでSandboxを合格にしない。
4. Stage 0全体の必要証拠・市場仕様・Provider利用条件/料金・明示的な開始許可が揃うまで1Aへ進まない。

**以下は前回作業時の保存記録（PR #3は後から作成済み、上の最新確認を参照）：** コード/設計コミット `8e55eed` を専用ブランチへPushし、remote head一致を確認済み。GitHub APIは環境ポリシーのCONNECT 403で拒否され、PR2追加コメント/レビュー状態は未取得。新PR作成コマンドもGraphQL接続のForbiddenで失敗し、PRは未作成。必要ホスト`api.github.com`の環境設定下書きを保存済みだが、保存は実行環境への反映ではない。[準備済みPR本文](STAGE0C_PR_DESCRIPTION.md)からbase/headを指定してレビュー用PRを作る。PushとPR作成の実結果を混同しない。

`source scripts/env.sh`で固定Go、Python testは追加依存不要。古い配布ZIPはv1.1基盤検証版で投資研究機能を含まない。期限付きリンクだけを再現成果物と見なさない。
