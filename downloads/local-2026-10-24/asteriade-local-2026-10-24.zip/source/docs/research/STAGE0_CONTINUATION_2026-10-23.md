# Stage 0 継続作業と引継ぎ

2026-10-23（Asia/Tokyo）。ユーザーの「このチャットでやれるところまで実施」「続きを実施」に基づく。開始HEAD `6d01d08897b4ed53de01138ee737cc6ef9deb119`、ローカルbranch `codex/model-task-plan`。既存変更を保持し、commit/push/PR変更は行っていない。

**SAFE-01、DOC-01と、依存から切り離せるPRE-01〜04を完了した。** [tasks.md](../../tasks.md)は全41タスクの担当・依存・完了条件と全42ATの対応を保持する。市場profileの採用、実データ取込、Windows実効境界、製品kernel/Runner、Stage 0全体の合格は未完了。

## 成果と検証範囲

| Task | 成果 | 判明したこと・限界 |
|---|---|---|
| DOC-01 | ARCHITECTURE / IMPLEMENTATION_PLAN / RESEARCH_PROTOCOL / SECURITY_VALIDATIONの市場前提11箇所を整合 | BTC現物・1市場1ペア・1hは調査前提。venue/quote/期間/権利等は未確定。要件原本と歴史記録を維持 |
| DOC-02 / MKT-01部分 | [公式出典・アクセス記録](SOURCE_ACCESS_REVIEW_2026-10-23.md) | Public表示、PR #2/#3/#4のDraft/base/head、固定bitbank文書を確認。API/取引所本文はCONNECT 403。PRコメントの引用値を公式料率や時計に採用しない |
| SAFE-01 | [Windows境界ADR](WINDOWS_BOUNDARY_ADR_2026-10-23.md) | 宣言型Spec/固定Evaluatorを優先。5役割identity、AppContainer/Job/ACL/handle/IPC候補、12実機ケースと失効条件を定義。Microsoft公式の固定版資料を参照 |
| PRE-01 / PRE-02 | [合成goldenとengine比較](SYNTHETIC_ENGINE_COMPARISON_2026-10-23.md)、`reference/comparison/`と試験 | 固定Backtrader sourceを開発比較にだけ使用。3例の残高・数量・資産・費用は正解と一致、最大数値差1.14e-13以下。部分決済のraw損益は定義が異なる。既定の次足openは遅延受領の時計契約に早すぎる |
| PRE-03 | [証跡preflight](WINDOWS_EVIDENCE_PREFLIGHT_2026-10-23.md)、`scripts/safety_evidence.py`と試験 | profile/UBR/SID/policy/fixture/hash/時刻、陽性/否定対照・欠落等を検査。最良でもreview_required。実機の収集器とsandboxは未実装 |
| PRE-04 | [合成入力品質](SYNTHETIC_INPUT_QUALITY_2026-10-23.md)、`reference/asteriade_synthetic/quality.py`と試験 | bytesのみ、固定TOY-CASH。429/通信失敗、empty/gap、重複/順序、OHLC/時計、改訂/同revision conflictを区別。rawと内容hashを分け、旧snapshotを上書きしない |

親は境界と合成契約・oracleの固定、証跡preflight実装、子の成果の読取確認、再実行、台帳/引継ぎ統合を担当。`gpt-6.1-sol`指定の子はDOC-01、出典調査、親契約に沿う比較器/品質検査と境界ADR/preflightのレビューを担当した。レビューで指摘されたOS patch revisionと観測identity/policy/fixtureの不足を親が修正し、回帰試験へ追加した。GPT-6.1-Lunaは選択不可なので未使用。旧GPT-6-Lunaや外部の従量APIへの置換はしていない。

## 最終検証

Linux x86_64 / Python 3.12.14。リポジトリルートで実行した。

```bash
env -u ASTERIADE_BACKTRADER_SOURCE \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -v

ASTERIADE_BACKTRADER_SOURCE=.local/engine-comparison/backtrader-b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -v

ASTERIADE_BACKTRADER_SOURCE=.local/engine-comparison/backtrader-b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m comparison.engine_comparison
```

| 検査 | 結果 |
|---|---|
| 標準ライブラリ構成 | 77件中73成功・外部engineの4件skip、失敗0 |
| 固定engineあり | **77件成功、skip/失敗0**。既存24、比較7、品質31、証跡15 |
| 親による比較の再実行 | 3会計例、raw損益定義の差、早すぎるfillの拒否を確認 |
| Goの状態 | この増分でGo/依存/Runnerは変更なし。前回のrace付き164件成功・helper 1件skip、vet/build/Linux smoke/Windows cross-buildの記録を保持。今回の再実行とは呼ばない |

Backtraderの固定版に由来するPython 3.12のinvalid escape SyntaxWarning 2件がある。上流sourceの変更・警告抑制はしていない。標準構成は追加パッケージ不要、任意比較のsource取得/checksum/ライセンス範囲は比較記録を参照。PythonもBacktraderも製品の実行依存には追加していない。

実行ログはignoredな`.local/validation/python-stdlib-2026-10-23.log`、`python-with-engine-2026-10-23.log`、`engine-comparison-parent-2026-10-23.json`。以前のGo記録は[Registry実装記録](STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)。最終確認でPython構文/TOML、ローカル文書リンク140件、41タスクの一意性・依存先・循環なし、全42ATの対応、`git diff --check`が成功。タスク状態はDONE 15、BLOCKED 5、TODO 5、GATED 16。

## クラウド環境の保存状態

既存のGo 1.27.2用install_script/start_skillを保持し、環境設定下書きのnetworkに`api.github.com`、`api.coin.z.com`、`coin.z.com`、`bitbank.cc`、`www.bitbank.cc`、`support.bitbank.cc`、`blog.bitbank.cc`を保存した。下書き再読取で7 hostを確認。目的はGitHub現況・取引所の公開文書確認。秘密・資格情報・OS policyは変更していない。

下書きは保存済みで**Publish/実環境への反映は未確認**。設定画面で内容を確認・保存してPublishする操作が残る。アクセス拒否後の迂回やTLS/proxy無効化、実市場データAPI呼出しは行っていない。反映後に初めて、通常経路で公式本文へのアクセスを再確認する。

設定のrepository refは依頼時のmasterのままで、masterは旧文書だけの系統。今回の実装は最新開発系統上の未commit作業であり、今後の新環境でこの変更が自動復元される証明はない。新規checkoutでGo setupを再現するには、実装を含む対象refと保存済み成果の所在を確認する必要がある。install/start手順は既存作業checkoutで検証済み。

## 次に必要な条件

1. DOC-02/MKT-01: 適用済みの許可経路でGitHub設定・取引所の一次資料を確認する。保存、AI送信、公開の各権利、現行fee/適用日、足境界・確定/訂正・availabilityの根拠を揃える。
2. 親MKT-02/03: venue/quote・期間・取得上限/保存先の選択と公式根拠に沿って、市場profile、時計/会計golden、coverageを固定する。今回のTOY値を実市場へ転用しない。
3. Sol ENG-01→親ENG-02: 採用profileで比較し、科学精度・依存・ライセンス・Windows配布方式を判断する。比較できたことだけでBacktraderを製品採用しない。
4. Windows 11でSol SAFE-02→親SAFE-03: 採用実行物、identity、policyでprobe収集器を実装・実行し、全ケース/variantと陽性対照を確認する。preflight成功やクロスビルドを代用しない。
5. 市場/安全条件が整ってからMKT-04の限定取込、GATE-00の統合判定へ進む。Stage 1A以降の依存と開始許可は別途保持する。

残りはLunaの文書タスクだけではない。市場採否・安全性レビューを担う親、比較/実機harness/取込を担うSol、出典整理を担うLunaの仕事が残っている。現環境で独立して進められる準備は完了し、実測できない条件を推測でDONEにしていない。
