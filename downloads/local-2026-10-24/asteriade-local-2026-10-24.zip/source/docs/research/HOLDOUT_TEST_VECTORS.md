# 合成Holdoutの独立試験ベクトル

2026-10-22。HLD-01。作成: このチャットの親。入力と期待結果を実装前に固定する。
基準は[上流契約](UPSTREAM_EXECUTION_CONTRACT_2026-10-22.md)。この試験は市場成績・Windows隔離の証明ではない。

共通fixtureは架空の`synthetic/spot/TOY/CASH`。UTCの元データ範囲A=`[2026-01-01T00:00:00Z,02:00:00Z)`、B=`[01:00:00Z,03:00:00Z)`、C=`[02:00:00Z,03:00:00Z)`。異なるProject、hash、足種でもA/Bは重複する。Cの隣接可否には元データ・label horizonを含めた範囲対応が既知であることが必要。未知mappingは独立評価不可。

| ID | 固定操作／故障点 | 独立した期待値 |
|---|---|---|
| HC-01 | unseen→preflight→検査失敗。grantを発行しない | unseen維持、read可能=false、release=false。失敗履歴は残す |
| HC-02 | access intentのcommit直後に再open | grantは1件、可能露出=true、claim/runはoutcome_unknown。未使用へ戻らない |
| HC-03 | 値アクセスを記録後に再open | inspected/露出を維持。古いfenceは拒否。再openを繰返しても新grantなし |
| HC-04 | 公開後に科学的欠陥→元claimを参照し、新kernel・親付きmanifestで訂正を記録 | consumed→defect_review→corrected_analysis。可能露出とreleaseはtrueのまま。元manifestのままの訂正は拒否 |
| HC-05 | Aを使用後、異Project・hash・足種でBを要求 | conflict、2件目grantなし。Cはknown mappingなら重複なし |
| HC-06 | A/Bを同時claim | 成功1、競合1。イベント/outbox/receiptとclaimが同じcommitに属する |
| HC-07 | 古いgeneration、actor、policy、manifestのいずれかでアクセス | すべて拒否。lease経過だけで露出をリセットしない |
| HC-08 | 同key・同payload再送、続けて異payload | 同payloadは同claim、イベント追加0。異payloadはconflict。復旧後も再送でclaimは再活性化しない |
| HC-09 | backupを別場所へ復元／台帳だけ古い版へ戻す | continuity unknown、独立claim不可。全ディスクとwitnessの同時rollback検知は範囲外 |
| HC-10 | release intent commit後、ackなしで再open | release可能=true、未露出に戻らない。Run outcome_unknown |
| HC-11 | candidateを登録→failed、子candidate→rejected | 両候補・親・family・理由が残る。状態/親を上書きしない |
| HC-12 | mapping不明、未登録partition、continuity不明 | unknown/not foundで拒否。空の履歴を未使用の証拠にしない |

追加の破壊的故障は使い捨てSQLiteだけへ注入する。claim、ExposureEvent、outbox、receipt各INSERTをトリガーで失敗させ、partition/claim/event/outbox/receiptがすべて元の件数・状態のままであることを確認する。将来schema版・改竄migration ledgerを開いても元DBを勝手に書き換えない。

時刻の比較は時刻値で行う。`00:00:00Z`と`00:00:00.5Z`を文字列順で比較しない。逆転・ゼロ長・非UTC・範囲外時刻、未知商品aliasは拒否する。純粋ロジックの試験、SQLiteの故障／同一Store並行試験、実機Broker/Windowsの隔離試験は別々に記録する。

実装後の[検証記録](STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)には、合成経路で実測した範囲と製品で残る実証を分けて記載した。HC-04の新kernel/manifest条件は上流契約から明示し、期待状態を実装に合わせて緩めていない。
