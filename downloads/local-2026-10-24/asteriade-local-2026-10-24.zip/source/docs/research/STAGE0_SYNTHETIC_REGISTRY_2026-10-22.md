# 合成Registry・凍結manifest・復旧の実装と検証

2026-10-22（Asia/Tokyo）。開始元 `6d01d08897b4ed53de01138ee737cc6ef9deb119`、作業ブランチ `codex/model-task-plan`。ユーザーの「Solに任せようとしていたタスクをこのチャットで実行」に基づく。実装と統合は親、GPT-6.1-Sol指定の子は独立した読み取りレビューを担当。GPT-6.1-Lunaは未実行。commit/pushは行っていない。

`DEV-01`、`HLD-02`、`HLD-03`、`HLD-04`、`INT-01`と前提の`HLD-01`を、合成データに限って完了した。市場データ・製品Kernel・Broker・Windows実効境界・Stage 0全体の合格ではない。Runnerは全能力falseのまま。

## 実装範囲

| 対象 | 実装と境界 |
|---|---|
| 独立fixture | [HOLDOUT_TEST_VECTORS.md](HOLDOUT_TEST_VECTORS.md)。HC-01〜12の入力と期待状態を定義 |
| 純粋Registry | `internal/research/registry.go`。UTC半開区間、露出の単調性、row version/fence、unknown拒否。商品は架空の`synthetic/spot/TOY/CASH`だけ。別hash/lineage/足種でも同じ元期間を重複扱い |
| identity v2 | `internal/research/evaluation.go`。`asteriade/synthetic-evaluation-v2` / `asteriade/evaluation-json-v2`。型付きSpec、partition、kernel/code/environment/benchmark/protocol/cost/metrics/gates/policy、seed、親・変更理由を凍結 |
| 実内容照合 | callerが所有する信頼された合成CASの各ファイルを実際にSHA-256照合。manifest保存と新Run作成、訂正記録時に再検査。1参照16MiB以内。CAS名だけで内容を信用しない |
| 保存 | `internal/store/research_schema.go`、`research_store.go`。追加schema v2、manifestの不変保存、同manifestに別Run、候補・親family・失敗/棄却理由の追記保存 |
| claim | 単一Storeのmutex＋SQLite write予約後に全Projectの期間重複を照会。状態・claim・event・outbox・receiptを同一transactionで保存。同key同内容の再送は再grantしない |
| 公開・訂正 | release intentは出力hash/宛先に束縛し、ackと分離。訂正は公開済みclaim、直接の親manifest、新kernel、同partition/project/familyへ束縛。消費を維持し、再アクセス権や科学的validを付与しない |
| 履歴と投影 | `research_ledger.go`、`research_projection.go`。追記履歴をhash chain化。transaction末尾の`state_checkpoint`で全研究投影と研究receiptを固定列/主キー順のhashへ束縛。Open・研究書込・claim照合時にchainと投影を検査 |
| 復旧 | access/release intent以降の中断は露出を維持、fence増加、claim/Runは`outcome_unknown`。復旧後の同key再送でも再活性化しない |
| DB連続性 | 同じprivate directoryの`<DB path>.research-witness`にepoch/sequence/head/continuityを保存。DBだけの古い復元、別場所への復元、witness欠落・先行/遅延でunknown化 |

既存`identity.go`/freeze v1と、Storeのv1 DDL配列は開始元から変更していない。v1はsynthetic development専用という制限を維持する。研究schema v2の移行は既存Projectを保持し、全migration checksumを確認する。新版・checksum不一致・移行台帳欠落は拒否する。v2からv1へのdowngradeは提供しない。

研究APIはGo内部の合成検証用であり、HTTP/UIへの接続や実行プロセスはない。proofのactor/policy/manifest/fenceは台帳の照合項目で、認証tokenやOS capabilityではない。`succeeded`になったRunも`validation_status=unvalidated`を維持する。

## 今回実行した検証

Linux x86_64 / Go 1.27.2 / Python 3.12.14。`scripts/setup.sh`を実行・再実行し、固定アーカイブSHA-256、TLS、Go module checksumを維持して成功。依存宣言・lockfileの変更なし。

```bash
cd /workspace/Asteriade
bash scripts/setup.sh
source scripts/env.sh
export GOMAXPROCS=4
go test -race -p 4 -json ./... > .local/validation/final-race-tests.json
go vet -p 4 ./...
CGO_ENABLED=0 go build -p 4 -trimpath -o bin/asteriade ./cmd/asteriade
python3 scripts/smoke.py
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -p 4 -trimpath -o bin/asteriade.exe ./cmd/asteriade
PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s reference/tests -v
```

| 検査 | 実測結果 |
|---|---|
| 変更前のGo回帰 | 40トップレベル、サブテスト込み105 passed、failed 0 |
| 最終Go全体・race検査 | **58トップレベル、サブテスト込み164 passed、failed 0**。通常起動ではsubprocess専用helper 1件skip。親の試験から3回別プロセスで起動し、intent/read/release後にCloseせず終了する経路を検証。main/webuiのテスト未定義packageは合格数に含めない |
| 静的検査・ビルド | `go vet`、Linux CGO不要ビルド、Windows amd64 CGO不要クロスビルド成功 |
| Linux live smoke | session、目標保存、idempotency、実行拒否、Origin拒否、再起動、backup/restore成功 |
| Python合成参照 | 既存24件成功。市場成績・実データ検証ではない |

ログはignored領域`.local/validation/`。生成した未署名Windows EXEのSHA-256は`79b3ca719369b068fa5a40722b119c43bed5a22c05a9218ba498039ea404ca04`。Windows実行は未確認で、配布・リリースはしていない。

## HC対応と故障注入

| HC | 確認した合成経路 | 製品で残る実証 |
|---|---|---|
| 01 | preflight失敗でgrantなし、unseen維持、失敗履歴 | Brokerによる実ファイルread 0の強制 |
| 02/03/10 | 子プロセスがintent/read/release後に終了。露出・公開可能性維持、旧fence拒否、Run unknown | 実Workerの停止・IPC・送信境界 |
| 04 | 公開→defect→新kernelのpersist済みrevision参照→corrected_analysis。無revision/旧kernelは拒否 | 科学的欠陥の影響分析、修正kernelによる再計算 |
| 05 | 別Project/異hashの部分重複を拒否。別足種・小数秒境界は純粋判定で確認、隣接を許可 | 実source、派生特徴量・label horizonのmapping証明 |
| 06 | 同一Storeへ同時に重複claimを要求し、成功1・競合1 | 複数hostの分散Registryは未対応。現行の別Store/プロセスは既存排他DB方針 |
| 07/08 | actor/policy/manifest/partition/fence差替え拒否、同keyの同内容/異内容、復旧後再送 | actor認証、lease/OS grantの実Worker束縛 |
| 09 | 別場所backup復元、DBだけの巻戻し、witness欠落、DB commitがwitnessに先行する状態 | 全ディスク/管理者rollbackの耐性、外部trusted anchor |
| 11 | failed親・rejected子とfamily/理由を保持、採否の上書き拒否 | 全探索空間・seed・選抜母集団のGovernor記録 |
| 12 | unknown mapping、未登録partition、未知continuity、商品alias拒否 | 実市場の商品正規化・権利・来歴 |

claim/ledger/outbox/receiptのINSERTを使い捨てDBのTEMP triggerで失敗させ、状態・件数・checkpointが全て元に戻ることを確認した。v2移行途中のDDL失敗もv1へ原子的にrollbackする。追加の回帰試験は、**完了済みclaimの露出投影だけを有効なNewExposureへ戻す**、claim/run/receiptの改変、途中ledgerの欠落、空ledgerに既存投影を挿入するケースを拒否する。投影だけを信用して再grantしない。

レビューで発見した「投影巻戻し」「大文字の商品alias」「修正manifest不要の訂正」を親が修正。GPT-6.1-Sol指定の読み取り最終レビューでは新たな重大不整合なし。テストは親が実行した。

## 復元・運用上の限界と次工程

- witnessはローカルの補助記録であり秘密鍵・外部証明ではない。DBとwitnessを一緒に古くする全ディスクrollback、管理者による一貫した改竄、新規DBへの同一情報再登録をグローバルには検出できない。DB名の変更やwitnessのコピーで独立性を証明しない。
- DB commitとwitness更新は別操作。間で停止した場合はunknownとなる保守的な設計。unknownの自動解除・自動的なunseen復活は実装していない。投影/chain破損時は起動を拒否し、原本を保全する。
- 各研究書込の前に全履歴/全投影を検査するため、小規模合成fixture向け。大規模履歴の性能や多host排他を検証したとは扱わない。
- typed Go APIのみ。汎用JSON ingress、実市場権利/approval失効、kernel許可リスト、artifact export、研究Governorは未接続。内容hash一致だけでは承認・科学的妥当性は成立しない。
- 次の上流作業は`SAFE-01`と市場根拠の確認。Solの`ENG-01`は`MKT-03`、`MKT-04`は市場選定/権利/安全ゲート、`SAFE-02`はWindowsと採用engine待ち。Stage 1以降はGATEDのまま。

クラウド環境には再実行済みの`install_script`と現在のGo開始・試験・起動手順の`start_skill`を下書き保存した。ネットワーク・秘密・repository設定は変更していない。保存は公開・新しいタスクでの復元実証ではなく、環境設定での確認・保存とPublishが別途必要。

2026-10-23再開時に、保存済み結果・文書リンク・TOML・v1 DDL/freeze不変を再確認した。最終コード試験後は文書更新のみ。
