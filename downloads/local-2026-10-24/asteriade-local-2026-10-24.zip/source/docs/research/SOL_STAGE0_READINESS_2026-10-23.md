# Sol引継ぎ: Stage 0の前提確認と証跡検査の修正

2026-10-23（Asia/Tokyo）。ユーザーのSol引継ぎ指示に従い、同じcheckoutの`codex/model-task-plan` / `6d01d08897b4ed53de01138ee737cc6ef9deb119`から継続した。チャット本体が実装・検証・記録を担当し、`gpt-6.1-sol`指定の子がSID入力契約と修正のread-onlyレビューを担当。既存未commit作業を保全し、branch切替・commit/push・外部送信は行っていない。

**SAFE-02の準備に使う既存preflightのSID入力検査を修正した。ENG-01 / SAFE-02 / MKT-04本体は前提待ちのまま。** PRE-01〜04の機能を再実装したものでも、Windows安全性やStageの合格でもない。

## 引継ぎと環境の確認

AGENTS.md、tasks.md、REQUIREMENTS.md、HANDOFF.md、直前の継続作業記録、Windows境界ADR/preflightを確認した。保存済みvalidation manifestと比較し、今回触るファイル以外の既存作業のhashが一致することを確認した。Goアプリ・依存・Store/freeze/schema・Runnerは今回変更していない。

cloud-environment-runtime skillに従い`environment_status`と`/etc/codex/network-policy.json`を読んだ。観測はcurrent、spec/observed revisionは2、追加allowed_hostsは空、network policy stateは`unknown`。下書き7 hostの適用・enforcedは確認できない。今回は拒否先への再接続、proxy/TLSの変更、設定変更、実市場データAPI呼出しを行っていない。既報のCONNECT 403が解消した証拠はない。

実行環境はLinux x86_64 / Python 3.12.14。Windows 11の採用構成・実機観測は未受領。保存済み合成JSON・クロスビルドをWindowsの証拠へ読み替えない。

## 修正した不具合

旧`profile_fingerprint`はSIDの要素を桁数無制限の数字として受理していた。例:

- `S-1-5-21-1-2-3-4294967296`: subauthorityがDWORD上限を超える。
- `S-1-15-2-1-2-3-4-5-6-4294967296`: AppContainer SIDの同じ範囲違反。
- controllerが`S-1-5-21-1-2-3-1000`、workerが`S-1-5-21-01-2-3-1000`: 数値列が同じ別表記でも、文字列のdistinct判定を通っていた。

不正SIDでも報告が実行能力を開く経路はないが、profile完全性の検査として不十分だった。

`scripts/safety_evidence.py`の`valid_sid`で、accountの固定prefix＋4要素、AppContainerの固定prefix＋7要素を検査する。全要素をASCII通常10進表記の0〜4294967295に限定し、単独`0`以外の先頭ゼロ、符号、空白、Unicode数字、要素数違い等を拒否する。入力を暗黙に正規化しない。正常なprofileのcanonical JSONとSHA-256方式は変更せず、修正前の合成profile hash `288bda61d74d6345dd2b5910ae4513facc67b098f22da54d69388f566be9ebd1`が維持されることを回帰で確認した。

これはSIDの文字列表現の検査。account/token/AppContainerの実在、Windowsでの変換挙動、実際の権限分離を確認したものではない。製品Runnerとの接続はなく、最良の結果も`review_required`、`execution_enabled=false`のまま。

## 今回実行した検証

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s reference/tests -p test_safety_evidence.py -v

env -u ASTERIADE_BACKTRADER_SOURCE \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -v

ASTERIADE_BACKTRADER_SOURCE=.local/engine-comparison/backtrader-b853d7c90b6721476eb5a5ea3135224e33db1f14 \
  PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 \
  python3 -m unittest discover -s reference/tests -v
```

| 検査 | 今回の結果 |
|---|---|
| SID修正と証跡preflight | 20件成功。既存15＋新規5。全11位置の範囲/表記違反、別表記のidentity、0/MAX、prefix/要素数、profile非変更、正常hash維持 |
| 全Python・標準構成 | 82件中78成功、外部engineの4件skip、失敗0 |
| 全Python・固定engineあり | **82件成功、skip/失敗0** |
| Sol指定の独立レビュー | 追加指摘なし。子はメモリ内の別入力でもSID形式/境界/正常hashを確認。ファイル編集・外部通信なし |
| 互換性・記録整合 | 対象コードをimportせず組み立てたcanonical profileを`sha256sum`で照合し、固定hashと一致。`git diff --check`、Python構文/TOML、ローカル文書リンク144件、41タスクの依存先・循環なしと全42AT対応を確認 |

ログはignoredな`.local/validation/sol-stdlib-2026-10-23.log`、`sol-with-engine-2026-10-23.log`。Go/永続化/並行処理の変更はないため、Go race/vet/buildの再実行はしていない。前回のGo164成功・helper 1skipは過去実績として保持する。

## 残タスクの解除条件と次の担当

| Task / 状態 | 具体的に不足している入力・証拠 | 次の担当 |
|---|---|---|
| ENG-01 / TODO | 親のMKT-02/03: venue/quote/feed/期間、時計・availability/eligibility/fill、費用・丸め・coverage・独立goldenの確定。toy比較は完了済みで、これを市場profileの比較に代用しない | 一次資料はLuna/Sol、採否・契約は上位モデル。その後Solが比較 |
| SAFE-02 / BLOCKED | 親のENG-02: 採用engine・配布方式・実行物。加えてWindows 11のedition/build/UBR、identity/SID、policy/fixture/hashと管理された試験環境 | ENG-02は上位モデル。条件確定後、Solが実機harness/collectorを実装・実行し、上位モデルがSAFE-03 |
| MKT-04 / BLOCKED | MKT-02/03/SAFE-03に加え、取得対象・期間・量・保存先、保存/AI送信/公開それぞれの権利と必要な許可 | 市場・安全の判断は上位モデル。条件確定後Solが限定取込 |

直近に解消すべき点は、設定下書きの確認・Publish/実適用、公式資料の確認、venue/quote等の選択である。ネットワーク許可は第三者データの使用権や取得許可を代替しない。元タスクの完了・製品AT合格・Stage 0 exitは宣言しない。
