# SAFE-01: Windows実行境界と証跡契約

2026-10-23。親が設計。状態は**設計採用・実装候補、Windowsで未実証**。SAFE-01の完了はSAFE-02/03やRunner開放を意味しない。現行`runner.CheckReady`と全能力falseを維持する。

## 1. 採用する設計と分離

初期の評価経路は、許可された宣言型StrategySpecを固定Evaluatorが解釈する形を優先する。任意Python/GoコードをFinal Holdoutと同一プロセスへ読み込まない。外部engineはまず開発専用比較器とし、製品採否はENG-02で判断する。

| 役割 | 実行identity・資源 | 渡せるもの／禁止するもの |
|---|---|---|
| Control Plane | ユーザーのローカル管理側、SQLite・承認・Registry所有 | 凍結ID、状態、検証済み公開結果。WorkerへDB、session、Provider秘密を渡さない |
| Data Broker | 制限した専用標準ユーザーを候補。読み取り専用dataset、限定された管理IPC | claim/fence照合後に許可partitionだけをEvaluatorへ渡す。AIや任意WorkerにFinal Holdoutの値を渡さない。全期間パスを渡さない |
| Fixed Evaluator | Broker/Hostと異なる専用identity＋AppContainer/Jobを候補。固定hashのkernel、読み取り入力、限定staging | 宣言型Specだけを解釈。runtime plugin/import/任意コード/evalなし。出力は型・サイズ・公開方針検査後に管理側へ |
| Research Worker | 実行ごとAppContainer SID＋Job、専用workspace、開発partitionだけ | 最小入力と有限資源。DB/秘密/他task/他partition/管理API、ネットワーク、注文、外部送信は禁止 |
| Provider Host | Worker/Evaluator/Brokerと異なる専用標準ユーザーを候補。公式Provider認証だけ | 許可済み要約のみ。Hostの子孫に広い資格情報・通信を継承させない。公式CLIがこの分離を満たせなければHost経路をblocked |

専用ユーザー作成・ACL・Firewall/WFP変更は将来の使い捨てWindows試験環境で具体的な変更範囲をレビューして実施する。現Linux環境でアカウントやOS policyは変更しない。単一EXEは配布物の目標であり、同じ高権限identityで全役割を実行する要件ではない。

## 2. backend候補と停止条件

第一候補は**AppContainer（network capabilityなし）＋起動時Job所属＋明示handle許可リスト＋private ACL**。LPACの追加は互換性を含め別profileとして実証する。Jobだけ、Restricted Tokenだけをsandboxと呼ばない。成立しない場合はWindows Sandbox/VM等の別profileを検討し、Dockerや外部runtimeを製品必須へ自動追加しない。

起動順は、private実行ディレクトリ準備→token/AppContainer/Job/資源上限/ACL/IPC作成→固定実行物hash照合→`STARTUPINFOEX`にsecurity capabilities・handle list・Job listを設定→必要に応じてsuspendedで作成→実token/Job/handleを照合→開始。いずれか失敗すればresumeせず終了・回収を確認する。起動してから権限を狭める方式を合格にしない。

- Jobはbreakaway/silent-breakawayを許可せず、kill-on-close・active process・CPU/memory/time制限を固定。終了API成功だけで子孫終了とせず、PIDの再利用を考慮した作成時刻/handleとJob通知を照合する。
- 任意子プロセスが不要なEvaluatorではchild process policyも拒否。shell/PowerShell/COM/RPC/WMI/service等の媒介経路は個別に否定試験する。Jobに通常の子が入ることだけでは媒介起動を拒否した証拠にならない。
- ファイルはcanonical path文字列だけで許可せず、開いたhandleの実体・volume/file IDとACLを検査。junction/symlink/reparse/ADS/UNC/rename競合、read/write/deleteを試す。データhash照合後のすり替えを防ぐimmutable handle/保管方式も試験対象。
- 環境変数はallowlistで構築し、Host認証・proxy・クラウド資格情報をWorkerへ継承しない。標準入出力/pipeのhandleだけを許可し、親DBや秘密ファイルのhandleを継承しない。
- ネットワークはno capabilityを出発点とするが、それだけで合格としない。IPv4/IPv6、DNS/UDP、proxy、loopback/LAN、子孫経路を管理下sinkで確認する。Provider Hostへの限定通信がWorker経由の代理送信にならないことを確認する。

## 3. IPCと露出の手順

Named pipe候補は実行ごとの推測困難な名前、明示DACL、remote拒否、先行作成の検出を用いる。既定のpipe security descriptorは使わない。`FILE_GENERIC_WRITE`がpipe instance作成権を含む点に注意し、必要権限を個別に指定する。logon SID/実client process token/sessionを確認し、payload内のactor名を認証に使わない。

フレームは長さ上限、版、Run/manifest/claim/fence、使い捨てchallenge、単調sequenceに束縛する。認証前にファイルを開かず、長大/重複/未知フィールド・旧challenge・旧fence・別Runを拒否する。親の全権管理APIをpipe経由で公開しない。認証秘密はpipeや環境から別taskへ漏らさない。

露出順は既存Registry契約を使う。管理側でaccess intentをcommit→Brokerが最新claim/fenceと内容hashを照合→限定入力→非公開出力→結果検査→宛先/出力hash付きrelease intentをcommit→許可された表示→ack。中断時は露出維持・outcome_unknown。再起動やlease期限だけで再grantしない。DB/witnessの欠落、backup/import履歴不足、全端末rollbackの検出不能は独立性を回復する根拠にしない。

## 4. 固定profileと失効

`profile`にはschema、Windows edition/build/UBR（patch revision）/arch、backend版、Control/Broker/Evaluator/Worker/Host/kernel実行物hash、policy hash、fixture hash、各SID/AppContainer SIDを記録する。型付き/固定キーのcanonical JSONのSHA-256をprofile fingerprintとする。policy文書には上限・許可資源・IPC/ネットワーク/出力条件を含める。

OS/build/UBR、実行物、identity、policy、fixture、backendのいずれかが変われば別fingerprint。旧報告を流用しない。判定には別途レビューで固定したexpected fingerprintを渡し、報告自身のfingerprintを承認値として自動採択しない。

証跡validatorは**完全性・hash・対応関係の事前検査**だけを行う。JSONに`passed`を書いたこと、hashが一致したことは、実機試験の実施・OS拒否の真正性を証明しない。最良の結果も`review_required`であり、製品の能力flagへ接続しない。最終SAFE-03ではtrusted収集過程・陽性対照・OS error・sink/子孫の観測と実fingerprintを親が照合する。

## 5. 最小の実機試験matrix

各IDは同じprofile/runで`positive`（対照が動作する）と`negative`（禁止操作が拒否される）の両方を必須にする。artifactには手順、時刻、identity、OS error/exit、期待・観測、fixture hash前後、必要なsink受信件数を含める。秘密値は使用せず使い捨てmarkerで置き換える。

| ID | 陽性対照と否定操作 | 合格条件 |
|---|---|---|
| SV-16-files | 許可workspace read/writeと、DB/secret/他task/partition read/write/delete | 許可操作成功、保護対象拒否・不変 |
| SV-16-paths | 通常handleと、junction/symlink/reparse/ADS/UNC/rename競合 | 実体確認、域外操作0 |
| SV-17-tree | 管理対象probe起動/終了と、child/grandchild/breakaway | 全子孫管理、終了後残存0 |
| SV-17-startup | 起動前制限を確認し、初期命令からcanaryを開く | 割当raceによる禁止アクセス0 |
| SV-17-handles | 許可pipeと、親DB/secret handleの継承・再利用 | 許可handle以外を利用不可 |
| SV-17-mediated | 許可された管理probeと、COM/RPC/WMI/serviceの代理操作 | 未管理process/代理アクセス0 |
| SV-18-network | 管理sinkへの対照到達と、WorkerのIPv4/6/DNS/UDP/proxy/loopback/LAN/子孫送信 | 対照を観測、禁止経路の受信0 |
| SV-19-host | 合成Provider Hostと、Worker/子孫からdummy資格情報要求 | 正規Host経路のみ、秘密marker漏出0 |
| SV-20-ipc | 正規clientと、別SID/session/remote/squatting/replay/長大frame | 正規だけ処理、認証前副作用0 |
| SV-21-recovery | 正常再起動と、claim/release中断、旧DB/witness/import | 露出維持、旧grant拒否、unknown停止 |
| SV-03-orders | 合成の許可読取要求と、注文/取消/送金/口座要求 | 注文能力・credentialなし、sink受信0 |
| SV-04-privacy | 公開可fixtureと、private/secret markerを含むPrompt/Artifact/log/export | 公開可だけ通り、秘密漏出0 |

`failed / blocked / skipped / unrun`をpassへ読み替えない。試験種別やvariantを省いたartifactはSAFE-03レビューで差し戻す。backend-specific variantを増やすときはmatrix/policy版も更新する。現Linuxで作るのはvalidatorとunrunテンプレートで、これらのWindows試験を実施したとは扱わない。

## 6. 公式根拠と取得証跡

2026-10-23、通常HTTPS proxy/TLSでMicrosoft公式GitHub文書を固定commitから取得。win32 HEAD=`ca8274decead49403d70ceeed4af8d4ca74eaf11`、sdk-api HEAD=`656e9656bfaef34dd29cd7ee9e1146aec17e924c`。ローカル本文/hashはignored `.local/sources/windows/manifest.json`。

- [AppContainer isolation](https://github.com/MicrosoftDocs/win32/blob/ca8274decead49403d70ceeed4af8d4ca74eaf11/desktop-src/SecAuthZ/appcontainer-isolation.md): 資格情報・ファイル・network・process等の境界。個別構成の実効性は別に試験する。
- [Job objects](https://github.com/MicrosoftDocs/win32/blob/ca8274decead49403d70ceeed4af8d4ca74eaf11/desktop-src/ProcThread/job-objects.md): 通常の子の継承、breakaway、Win32_Process.Create経由の例外。
- [Restricted tokens](https://github.com/MicrosoftDocs/win32/blob/ca8274decead49403d70ceeed4af8d4ca74eaf11/desktop-src/SecAuthZ/restricted-tokens.md): SID・特権等の制限。ファイル/通信全体の証明ではない。
- [Named pipe access](https://github.com/MicrosoftDocs/win32/blob/ca8274decead49403d70ceeed4af8d4ca74eaf11/desktop-src/ipc/named-pipe-security-and-access-rights.md): 既定DACL、logon SID、GENERIC_WRITE/instance作成権。
- [UpdateProcThreadAttribute](https://github.com/MicrosoftDocs/sdk-api/blob/656e9656bfaef34dd29cd7ee9e1146aec17e924c/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute.md): security capabilities、handle list、Job list、child policyの構成要素。
- [AssignProcessToJobObject](https://github.com/MicrosoftDocs/sdk-api/blob/656e9656bfaef34dd29cd7ee9e1146aec17e924c/sdk-api-src/content/jobapi2/nf-jobapi2-assignprocesstojobobject.md): 割当・nested job・失敗条件。割当前メモリ操作の記述を一般的な全副作用の説明へ拡張しない。

OS/kernel/管理者による完全な侵害への防御は保証しない。Windows機材、採用engineと実行物、identityの実設定が揃ってからSAFE-02を実行し、SAFE-03でprofile単位に判定する。
