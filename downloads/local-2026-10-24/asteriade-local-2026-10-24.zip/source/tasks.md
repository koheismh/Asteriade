# Asteriade — モデル別タスク台帳

更新: 2026-10-24（Asia/Tokyo）。作業ブランチ: `codex/model-task-plan`。計画基準: `codex/btc-spot-profile-research` / `6d01d08897b4ed53de01138ee737cc6ef9deb119`。

**次のAIはこのファイルから担当を選ぶ。** 要件は [docs/REQUIREMENTS.md](docs/REQUIREMENTS.md)。既定ブランチmasterの旧v1.1と、現在の投資研究v2のタスクを混ぜない。既存[実装計画](docs/IMPLEMENTATION_PLAN.md)の段階と全42ATを引き継ぐ。

## 1. プロジェクト概要とGitHub確認結果

AsteriadeはWindows 11向けの自律AI投資研究システム。仮説、計画凍結、バックテスト、機械検証、考察、Markdown/JSON・Market Knowledge保存をつなぐ。初期はBTC現物・1市場1ペア・1時間足。Stage 1Aは単一Manager、Stage 1Bで独立Reviewerを追加する。実注文・口座操作は対象外。研究の正常完了と、収益性のある優位性の発見は別の判定である。

2026-10-22にHTTPS Git proxyでremoteを読取・fetchし、次を確認した。ブランチ名から進捗を推測せず、固定commitの文書と実装を参照した。

| remote branch | commit | masterとの差／内容 |
|---|---|---|
| `master` | `8b55314` | 既定HEAD。旧要件・指示等の4ファイルのみ |
| `docs/investment-research-design-20261021` | `9f5f254` | 5 commits ahead。投資研究v2設計 |
| `codex/investment-research-stage0` | `f721104` | 9 ahead。Go基盤、identity、再利用評価 |
| `codex/lean-mvp-synthetic-stage0c` | `e77638e` | 11 ahead。1A/1B段階化、合成参照検証 |
| `codex/btc-spot-profile-research` | `6d01d08` | 12 ahead。上記の直系後続、BTC現物profile暫定比較 |
| `docs/scope-reduction-review-20261021` | `58ba796` | 8 ahead。`98f3693`から分岐したスコープ案。自動統合しない |
| `codex/windows-stage0-download` | `3c30d55` | 1 ahead。旧基盤のWindows ZIP。投資研究完成版ではない |

- `git ls-remote --symref origin HEAD refs/heads/master`、全heads/tags、fetch後のtree・logを確認。検査時にtagは返らず、最新系統のtreeに`.github/workflows`はなかった。
- GitHub APIのrepo metadata / open PR / Actions照会は`Forbidden`。2026-10-23に公開HTMLでPublic表示とPR #2/#3/#4のDraft/base/headを確認した。レビュー全件・branch protection・CIの現況は未確認。[再確認記録](docs/research/SOURCE_ACCESS_REVIEW_2026-10-23.md)参照。
- 既存チェックアウトを使ってローカル作業ブランチを作成。masterやremoteの変更、push、merge、releaseは今回行っていない。
- 旧Go/SQLite/loopback UI、freeze v1、Python合成参照に加え、このチャットで合成Registry・追加schema v2・次版manifest/Run保存を実装した。研究Runner・研究loop・製品kernel・実市場Registryは未完成。
- **今回実測:** 固定Go 1.27.2を準備し、変更前105件、変更後race付き164件（58トップレベル）成功、helper 1件skip、失敗0。Python既存24件、Linux live smoke、Windowsクロスビルド成功。Windows実機・外部Providerは未検証。[実装・検証記録](docs/research/STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)を参照。
- **2026-10-23追加実測:** 合成golden/任意engine比較、合成入力品質、Windows証跡preflightを追加し、Python77件成功。外部engineなしでは73件成功・4件skip。Goアプリは前回検証後から変更なし。[継続作業記録](docs/research/STAGE0_CONTINUATION_2026-10-23.md)参照。

## 2. 担当モデルと作業規則

| 担当表記 | 適した仕事 | レビュー責任 |
|---|---|---|
| **上位モデル（親）** | 要件・市場/科学契約、アーキテクチャ、同時実行/復旧、Windows安全境界、採否・Stage出口 | 最終統合、安全性、科学的妥当性、リリース判断を保持 |
| **GPT-6.1-Sol** | 確定した契約に沿う複数ファイル実装、永続化、API、障害注入、統合試験 | 自分の試験結果を提出。安全/科学ゲートの最終判定は親 |
| **GPT-6.1-Luna** | 出典整理、AT台帳、独立した小fixture、既存仕様に沿う表示・用語・リンク整備 | Solまたは親がレビュー。未知仕様・費用・科学判断を確定しない |

これらは**Asteriadeを開発する際の分担**であり、製品内Manager/Reviewerの固定モデル指定ではない。選定理由は仕事の曖昧さ・影響・検証可能性に基づく推奨で、性能比較の実測ではない。

今回のサブタスク実行は`gpt-6.1-sol`指定で要件・段階・残ゲートと合成Registryコードの読み取りレビューを行った。Sol割当のRegistry/Store実装はこのチャットの親が担当した。2026-10-23の継続では、Sol指定の子がDOC-01、公式出典調査、親の契約に沿うengine比較/入力品質と境界設計のレビューを担当し、親が設計・証跡preflight・最終統合/検証を担当した。GPT-6.1-Lunaはこのセッションの選択肢にないため未実行。`gpt-6-luna`を同じモデルと読み替えない。利用可能なモデルIDを確認して起動し、指定モデルがなければ親または利用可能なSolへ委ね、実際の指定と結果を記録する。別の従量課金APIを勝手に使わない。

### 状態

- `DONE`: この行の成果物と完了条件だけを確認済み。製品AT合格とは別。
- `READY`: 依存が揃い、記載範囲の作業を開始できる。外部操作や課金まで許可する意味ではない。
- `TODO`: 依存タスクの完了待ち。
- `BLOCKED`: 必要な環境・公式根拠・ユーザー選択が不足。
- `GATED`: 後段。必要なStage出口と当該段階の開始許可待ち。
- 実行時は`IN_PROGRESS`、成果提出時は`REVIEW`を使う。各担当は実行モデル、開始時HEAD、変更ファイル、検証、残制約を末尾の記録に追記する。

### 自分の担当の選び方

1. AGENTS.md、本台帳、担当行の入力文書を読む。`git status`とHEADを確認し、既存変更を保全する。既存チェックアウトを使い、依頼がない限りworktreeを作らない。
2. 指定Task IDがあればその行を使う。なければ自分のモデルに一致する`READY`を上から1件選ぶ。READYがなければTODOの依存を解消できるか親へ報告し、GATEDを自動解除しない。
3. `IN_PROGRESS`と実担当を記録し、変更領域を宣言する。同時担当は最大3、同じファイルは一人が所有する。台帳／HANDOFFの統合は親が行い、子は返答で更新案を渡して競合を避ける。
4. 完了条件の実測と成果物を提出する。未実施・失敗・部分根拠を分け、`REVIEW`へ。依存をDONEにする最終確認は親。
5. 未知の科学仕様、権限拡張、public/private区分、費用、設計変更が出たら、その判断だけ親へ返す。独立した作業は続ける。

後続モデルへ渡す依頼例:

> `tasks.md`の`HLD-02`をGPT-6.1-Solとして担当してください。依存と現在の許可範囲を確認し、指定された変更領域で完了条件を満たしてください。変更、実行コマンド、結果、未実施事項を報告し、親レビューへ渡してください。

`DONE`やブランチ上の過去の「Push許可」は、新しい外部送信の包括承認ではない。2026-10-22の追加依頼により、Sol担当の実装をこのチャットで依存順に進める。親がDEV-01と合成Registry/永続化/復旧/identity接続を担当し、必要なHLD-01も先に整える。Stage 1の稼働、実データ取得、有料サービス、GitHubへの公開はそれぞれ前提を確認する。

## 3. 今回完了した上流作業と、すぐに渡せる作業

| ID | 作業 | 最適モデル | 状態 | 依存 | 成果物／変更領域 | 完了条件・根拠 |
|---|---|---|---|---|---|---|
| UP-01 | GitHub系統・現行要件・実装差分の把握 | 上位モデル（親） | DONE | なし | 本書§1、既存HANDOFF参照 | 7ブランチの関係、v1/v2差、未確認API項目を区別 |
| UP-02 | Holdout・freeze・アクセス/復旧契約の具体化 | 上位モデル（親） | DONE | UP-01 | [上流契約](docs/research/UPSTREAM_EXECUTION_CONTRACT_2026-10-22.md) | 状態表、claim/fence、commit順、復元限界、HC-01〜12を定義。実装合格は未宣言 |
| UP-03 | 担当・依存・全42ATの分割 | 上位モデル（親） | DONE | UP-01, UP-02 | 本書、AGENTS.md、Codex設定、HANDOFF | 全ATに担当タスクがあり、利用可能性と実行モデルを区別 |
| DOC-01 | 最新前提と古い文言の整合確認 | GPT-6.1-Luna | DONE | UP-01 | `docs/ARCHITECTURE.md`, `docs/IMPLEMENTATION_PLAN.md`, `docs/RESEARCH_PROTOCOL.md`, `docs/SECURITY_VALIDATION.md`の該当箇所のみ | Solが代行、親が11箇所を確認。BTC/1市場1ペア/1hを調査前提とし、venue/quote/期間/権利等の未確定と歴史的記録を保持 |
| DOC-02 | PR・GitHub設定の現況照会 | GPT-6.1-Luna | BLOCKED | UP-01 | 参照のみ。結果を`docs/research/`の新規記録へ | 現行許可経路でbase/head/review/CI/branch保護/公開範囲を読取。`api.github.com`接続拒否中。トークン値を要求・表示せず、過去記録と区別 |
| DEV-01 | 最新系統の固定Go環境と基盤回帰を確認 | GPT-6.1-Sol | DONE | UP-01 | 既存`scripts/setup.sh`, `scripts/env.sh`を利用。ログはignored領域 | 1.27.2をchecksum/TLS検証付きで準備、`go mod verify`、`go test ./...`、build、既存smokeを実測。lockfileは維持。Windows実行は別 |
| HLD-01 | 独立したHoldout試験ベクトルを固定 | GPT-6.1-Luna | DONE | UP-02 | 新規`docs/research/HOLDOUT_TEST_VECTORS.md`、必要なら合成JSON例 | HC-01〜12の入力・期待イベント・露出状態・拒否理由を手で追える値で定義。実装出力を正解へコピーしない |
| SAFE-01 | Windows境界と実証profileの設計 | 上位モデル（親） | DONE | UP-02 | [Windows境界ADR](docs/research/WINDOWS_BOUNDARY_ADR_2026-10-23.md) | 5役割のidentity、AppContainer/Job/handle/ACL、network、IPC、復旧と12ケースを具体化。OS build/UBR等に束縛。設計の完了であり実機合格ではない |

## 4. Stage 0 — 市場・Holdout・安全性の残り

| ID | 作業 | 最適モデル | 状態 | 依存 | 成果物／変更領域 | 完了条件・停止条件 |
|---|---|---|---|---|---|---|
| MKT-01 | bitbank/GMO公式資料と権利の根拠収集 | GPT-6.1-Luna | BLOCKED | UP-01 | [市場調査](docs/research/BTC_SPOT_PROFILE_SELECTION_2026-10-22.md)、[最新の通信・根拠確認](docs/research/MKT01_NETWORK_AND_EVIDENCE_2026-10-23.md) | 10/24 03:16 JSTもruntime追加許可空/state unknown。画面からの設定保存がruntime更新を要求でき、Publishは別処理と確認。agentに適用ツールなし。3権利・現行fee/時計等は未確認 |
| MKT-02 | 初期profileと研究範囲の採否判断 | 上位モデル（親） | BLOCKED | MKT-01 | profile判断ADR | venue/quoteのユーザー選択と公式根拠が必要。bitbank案は条件付き。未知の期間/feeを推測で凍結しない |
| MKT-03 | 市場時計・会計goldenとcoverage契約 | 上位モデル（親） | TODO | MKT-02 | profile別golden仕様、benchmark/cost/unsupported表 | availability→signal→fill、base/quote fee、丸め、部分売却、gap、MTM/DDの独立正解。既存toyの対応範囲を誇張しない |
| MKT-04 | 限定データ取込とmanifest/品質検証 | GPT-6.1-Sol | BLOCKED | MKT-02, MKT-03, SAFE-03 | 採用後のdata adapter、合成fixture、非公開manifest | 対象/期間/量/保存先/権利の許可後だけ実データ。429・通信失敗・重複・改訂・欠損を区別。Raw保管と再現性を確認 |
| HLD-02 | Registryの純粋な状態・重複判定 | GPT-6.1-Sol | DONE | HLD-01, DEV-01 | 新規`internal/research/registry*`と単体試験 | HCの純粋ロジック、別Project/別revision/別足種の重複、unknown拒否。既存freeze v1制限を緩めない |
| HLD-03 | 追加migrationと原子的claim/receipt/outbox | GPT-6.1-Sol | DONE | HLD-02 | `internal/store`の追加研究schemaとstore試験 | 旧v1 checksum不変、新版migrationと拒否互換、並行claimでgrant 1件、idempotency競合、追記履歴保持 |
| HLD-04 | 故障注入・復元・公開中断の検証 | GPT-6.1-Sol | DONE | HLD-03 | Store/Registry統合試験、検証記録 | HC-02/03/06〜10を再現。復元でunseenを復活させない。純粋試験とOS隔離を区別 |
| INT-01 | freeze次版・Run/manifest保存の接続 | GPT-6.1-Sol | DONE | HLD-03, DEV-01 | `internal/research`次版、`internal/store`追加機能 | v1 golden維持、未知版拒否、実ファイル/定義hash照合、同manifest新Run、新条件新manifest。Runner startは開けない |
| ENG-01 | 候補engineの同条件・独立oracle比較 | GPT-6.1-Sol | TODO | MKT-03, DEV-01 | 0B比較への実測追記、隔離した合成比較fixture | 旧資産/候補OSSの使用権・依存確認後、同入力・費用・時計で約定/PnL差を説明。既存成績や実データを移植しない |
| ENG-02 | engine採否とWindows配布方式の決定 | 上位モデル（親） | TODO | ENG-01, SAFE-01 | 採否ADR、依存・配布・保守境界 | Go/別Runner/同梱候補の科学精度・ライセンス・配布・安全性を比較。追加ランタイムを無断で必須化しない |
| SAFE-02 | Windows canary/子孫/IPC/通信の実証 | GPT-6.1-Sol | BLOCKED | SAFE-01, DEV-01, ENG-02 | 管理された試験harness・証跡。既存`scripts/verify-windows.ps1`は基盤用と区別 | Windows 11で採用実行物/identity/policyのfingerprintを固定し、SV-16〜21、注文能力なし/合成Provider・exportの秘密marker拒否を陽性対照付きで実測。harness準備は先行可 |
| SAFE-03 | Windows能力profileの合否レビュー | 上位モデル（親） | TODO | SAFE-02 | profile別判定記録 | OS/build/identity/tool hash/policyと実経路の証拠を確認。実行物・identity・policy変更で判定失効。未達能力を閉鎖。Linux/cross-buildで代替しない |
| GATE-00 | Stage 0統合exit | 上位モデル（親） | TODO | DEV-01, MKT-04, HLD-04, INT-01, ENG-02, SAFE-03 | Stage 0判定表と残制約 | [上流契約§10](docs/research/UPSTREAM_EXECUTION_CONTRACT_2026-10-22.md#10-stage-0出口の証拠)の全証拠を照合。合格とStage 1開始許可は別 |

`MKT-04`は限定Data Adapterによる取込であり、未検証の研究Runnerを開放する依存ではない。合成Registry開発は市場profileの未決と独立して進められる。`HLD-03`と`INT-01`はStoreを共有するため直列。SAFE系はWindows実証までREADYとはしない。

### 独立して先行できる準備作業（2026-10-23追加）

以下は親タスクの市場・配布・実機条件を緩めずに切り出したもの。PREのDONEをMKT-03/04、ENG-01/02、SAFE-02/03のDONEへ読み替えない。

| ID | 作業 | 最適モデル | 状態 | 依存 | 成果物／変更領域 | 完了条件・根拠 |
|---|---|---|---|---|---|---|
| PRE-01 | 市場に依存しない合成golden契約 | 上位モデル（親） | DONE | UP-02 | `reference/comparison/vectors.py`、[比較記録](docs/research/SYNTHETIC_ENGINE_COMPARISON_2026-10-23.md) | 固定3例の残高・数量・平均原価・部分/全売却・費用・資産、時計否定例を独立literalで指定 |
| PRE-02 | 任意engineとの合成比較器 | GPT-6.1-Sol | DONE | PRE-01, DEV-01 | `reference/comparison/engine_comparison.py`と試験 | 固定Backtrader source hash、3例一致とraw損益意味の差、早すぎる既定fillを実測。製品採用・市場適合の判定はしない |
| PRE-03 | Windows証跡の事前検査 | GPT-6.1-Sol | DONE | SAFE-01, DEV-01 | `scripts/safety_evidence.py`、[使用手順](docs/research/WINDOWS_EVIDENCE_PREFLIGHT_2026-10-23.md) | 親が実装。12ケース/positive-negative/profile/hash/freshness等の15試験。最良でもreview_required・能力false。実機collectorは未実装 |
| PRE-04 | 合成入力品質・改訂の純粋検査 | GPT-6.1-Sol | DONE | PRE-01, DEV-01 | `reference/asteriade_synthetic/quality.py`、[品質契約](docs/research/SYNTHETIC_INPUT_QUALITY_2026-10-23.md) | 31試験。429/通信・empty/gap・重複/順序・改訂・同revision競合を区別。raw/内容hashと旧snapshotを保持。実市場取得なし |

DOC-02/MKT-01は[公開HTML・固定公式文書の再確認](docs/research/SOURCE_ACCESS_REVIEW_2026-10-23.md)まで進行。GitHub APIと取引所本文の実アクセスはCONNECT 403。必要7 hostを環境設定下書きへ保存したが、Publish/実環境への適用は未確認。MKT-02以降の市場profile・権利と、SAFE-02のWindows実証は引き続き不足している。

## 5. Stage 1A以降 — 条件を満たしてから着手

以下は将来の実装担当を固定するバックログ。`GATED`は依存に加え、当該Stageの開始許可を要する。各行は対象をさらに小さなPRへ分割可能だが、受け入れ条件を削らない。

| ID | 作業 | 最適モデル | 状態 | 依存 | 成果物／変更領域 | 完了条件 |
|---|---|---|---|---|---|---|
| A1-00 | Governor・Provider・予算の実行契約 | 上位モデル（親） | GATED | GATE-00 | 状態遷移/有限上限/予約・精算/機械ゲート契約 | 料金・認証・能力不明で停止、月額/Run上限、outcome_unknown、1A review非実施を定義 |
| A1-01 | 公式Provider adapterと費用・秘匿境界 | GPT-6.1-Sol | GATED | A1-00 | adapter/usage/許可済み入力組立、fake provider試験 | 公式契約と対象モデル利用条件を確認。予約・未知usage・無断fallback禁止。実接続/費用試験は別の許可内 |
| A1-02 | 研究ドメイン・有限loop・候補系譜 | GPT-6.1-Sol | GATED | A1-01, INT-01 | Governor、研究Store、runner接続の限定範囲 | 1Project/1市場/1仮説で計画凍結→実験→評価。全候補/棄却・上限・中断・再起動・独立境界を保持 |
| A1-03 | MD/JSON・Market Knowledge・benchmark出力 | GPT-6.1-Sol | GATED | A1-02 | exporter、成果物validation、fixture | 否定結果/unsupported/全試行/コスト・リスク/再現性/Prospective pendingを保存。1A reviewer配列は空＋理由 |
| A1-04 | 最小Cockpitの状態・理由・結果表示 | GPT-6.1-Luna | GATED | A1-03 | `internal/webui`の限定変更、既存API契約に従う | 仮説/工程/次工程/要対応、実行終了と分析中を区別。値不明を0や成功にしない。API/安全判定は変更しない |
| A1-05 | 単一Manager縦断・障害・秘匿回帰 | GPT-6.1-Sol | GATED | A1-04, HLD-04, SAFE-03 | 既存代表12ケース＋全該当ATのE2E | 人の逐次指示なしで有限完走、否定結果も正常完了。権限/料金/境界不明では停止し、受入証拠を残す |
| A1-06 | MVP受入と費用対効果判断 | 上位モデル（親） | GATED | A1-05 | 1A判定と1Bへの判断 | 研究自動化の価値と市場優位性を区別。利益未発見だけでMVP不合格にしない |
| B1-01 | 有限討論・B/C比較の事前登録 | 上位モデル（親） | GATED | A1-06 | 課題/評価基準/費用・時間/脱落/比較限界の契約 | 共通の強制ゲート、Reviewer最大2発言、独立初回入力。小標本で優劣を断定しない |
| B1-02 | Reviewer adapter・討論状態・比較計測 | GPT-6.1-Sol | GATED | B1-01 | Provider/Governor/比較記録 | 5-step、採否理由、期限、代替許可。Reviewer障害を1A切替で回避せずblocked_review |
| B1-03 | 討論表示・結果台帳と比較レビュー | 上位モデル（親） | GATED | B1-02 | AT-03/04/05/35の証拠と採否報告 | 実施数・条件差・費用・欠陥検出を照合し、追加価値不明も明記。UI小変更はLunaへ再委任可 |
| S2-01 | 選抜・統計診断・Prospective昇格設計 | 上位モデル（親） | GATED | B1-03 | 前提/標本/候補依存/追跡条件の契約 | 統計手法を万能扱いしない。全探索系譜・未使用性・未来観測の閾値を事前固定 |
| S2-02 | 研究記憶・有限Grid/Random/GA | GPT-6.1-Sol | GATED | S2-01 | 構造化重複照会、探索runner、全候補記録 | 未探索entry/exit/sizingを残す。無効Run/選抜familyを保持し、Holdoutを最適化feedbackに使わない |
| S2-03 | Prospective自動記録・復旧 | GPT-6.1-Sol | GATED | S2-01 | 限定feed/時刻/欠損/無取引/再接続記録 | 過去埋戻しを未来証拠にしない。新しいidentityと昇格条件、停止・断絶を記録 |
| S3-01 | 市場拡張・長期運用の設計とgate | 上位モデル（親） | GATED | S2-02, S2-03 | FX/日経225mini別契約・採否 | 個別の権利、tick/倍率/session/roll等と独立参照を定義。BTCの規則を流用しない |
| S3-02 | 承認された市場adapter・長期保全 | GPT-6.1-Sol | GATED | S3-01 | adapter、保存/restore、再現性試験 | 市場間会計とHoldoutの分離、欠落artifactの表示、AT-27/39を実証 |
| S3-03 | 検索・引継ぎ・表示の局所改善 | GPT-6.1-Luna | GATED | S3-02 | 既存schema/APIに沿うUI/文書/合成例 | 別AIが現在地・根拠・次工程を特定。公開Gitへの自動送信を追加しない |

## 6. 全42受け入れ要件と担当の対応

現在、**製品AT全面合格は主張しない**。下表は既存の合成参照と今回の合成Registry/Store試験による部分根拠。作業変更は未commitであり、開始HEAD・環境・実行結果は[検証記録](docs/research/STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)に固定した。

| AT | 主担当タスク | 導入／強化段階 | 現在の根拠・未実施 |
|---|---|---|---|
| AT-01 | HLD-03, A1-02 | 0→1A | 旧基盤と合成manifest/Run保存を確認。研究設定の製品縦断未実施 |
| AT-02 | A1-02 | 1A | 仮説・計画の実運用未実施 |
| AT-03 | B1-02 | 1B | 独立初回Reviewer未実施 |
| AT-04 | B1-02 | 1B | 採否/再反論上限未実施 |
| AT-05 | B1-02 | 1B | 対立時の有限終了未実施 |
| AT-06 | A1-01, A1-02 | 1A | 期限/不正出力/有限retry未実施 |
| AT-07 | HLD-02, A1-05 | 0→1A | 合成時計の部分根拠。製品の強制拒否未実施 |
| AT-08 | S2-02 | 2 | GA未実施。1Aからcoverage表現はA1-03で保持 |
| AT-09 | A1-02, S2-02 | 1A→2 | 重複候補追跡未実施 |
| AT-10 | MKT-03, ENG-01 | 0→1A | 部分売却/両barrier拒否の合成根拠。trailing/製品fill未実施 |
| AT-11 | MKT-03, A1-03 | 0→1A | 市場費用未確定、基準/好条件/ストレス未実施 |
| AT-12 | A1-03, A1-05 | 1A | 尾部損失/推定誤差の表示未実施 |
| AT-13 | HLD-01, HLD-04 | 0→1A | preflight失敗・intent後終了を合成Storeで確認。Brokerのread 0実証は未実施 |
| AT-14 | HLD-04 | 0→1A | 露出維持、公開中断、復元unknown、新kernel/manifestの訂正記録を確認。科学的再計算は未実施 |
| AT-15 | INT-01, HLD-04 | 0→1A | v1を維持しv2の実内容hash・親revision・Run保存を接続。実行側の強制は未実施 |
| AT-16 | A1-02, A1-04 | 0→1A | 研究Run eventと表示の縦断未実施 |
| AT-17 | A1-04, B1-03 | 1A→1B | 最小Cockpit/討論表示未実施 |
| AT-18 | A1-04 | 1A | 実行終了・分析中の区別未実施 |
| AT-19 | HLD-02, A1-03, S2-02 | 0→1A→2 | 合成candidateの親/family・failed/rejected履歴を保存。全探索母集団は未実装 |
| AT-20 | A1-03, S3-03 | 1A→3 | 文書設計あり。製品exportからの引継ぎ未実施 |
| AT-21 | A1-03, S3-02 | 1A→3 | 保持切れ・再現性欠落の表示未実施 |
| AT-22 | A1-03, A1-05 | 1A | 公開範囲/許可検査未実施。今回pushなし |
| AT-23 | A1-00, A1-01 | 0→1A | Provider未接続。未知料金/能力拒否の製品試験未実施 |
| AT-24 | A1-00, A1-01 | 1A | 費用予約・上限・未知usage未実施 |
| AT-25 | HLD-04, A1-05 | 0→1A | 合成claim/Runの中断・復元・再送・並行競合を確認。実Worker/外部結果は未実施 |
| AT-26 | SAFE-02, SAFE-03, PRE-03 | 0→1A | 境界ADRと証跡preflightの合成試験。Runner全能力false、Windows実効境界未実施 |
| AT-27 | S3-01, S3-02 | 3 | 追加市場会計未実施。現物toyで代替しない |
| AT-28 | A1-03, A1-05 | 1A | 否定結果の縦断保存未実施 |
| AT-29 | MKT-03, ENG-01, PRE-01, PRE-02 | 0→1A | 3つの独立会計goldenと固定Backtraderの合成比較。製品kernel/実市場比較未実施 |
| AT-30 | HLD-04, ENG-01, A1-05, PRE-02, PRE-04 | 0→1A | 早すぎるfill、欠損/改訂/同revision conflictの合成根拠。製品欠陥注入未実施 |
| AT-31 | A1-05, S2-02 | 1A→2 | 優位性ゼロでの選抜記録・昇格拒否未実施 |
| AT-32 | HLD-02, A1-02, S2-01 | 0→1A→2 | 合成候補系譜の永続履歴を確認。多重選抜診断・全探索追跡は未実施 |
| AT-33 | A1-02, A1-03 | 1A | 優先/見送り根拠、AI点数と成功確率の区別未実施 |
| AT-34 | MKT-03, A1-03 | 1A | benchmark事前凍結・同条件比較未実施 |
| AT-35 | B1-01, B1-03, S2-01 | 1B→2 | 比較計画のみ。追加価値未証明 |
| AT-36 | A1-03, S2-03 | 1A手動→2自動 | 実観測なし、pending。過去dataで代替しない |
| AT-37 | HLD-02, HLD-04 | 0→1A→2 | 単一DB内の全Project合成Registryを実装・試験。実source mapping/物理的アクセス境界は未実証 |
| AT-38 | INT-01, ENG-02, SAFE-02 | 0→1A | 保存/Run作成/訂正時に実ファイルhashを照合。承認kernelへの物理境界未実施 |
| AT-39 | ENG-01, ENG-02, S3-02, PRE-02 | 0→3 | 0B机上比較と固定Backtraderの合成実測。市場同条件/Windows配布適合未実施 |
| AT-40 | A1-05, A1-06 | 1A | 利益ゼロでも正常完了となる縦断未実施 |
| AT-41 | SAFE-02, A1-05 | 0→1A | 現行Runner拒否。製品経路で注文能力なしの否定試験未実施 |
| AT-42 | SAFE-02, A1-01, A1-05 | 0→1A | synthetic markerによるProvider/export境界試験未実施 |

## 7. 引継ぎ・今回の作業記録

| 日付 | Task | 実担当 | 結果と証拠 |
|---|---|---|---|
| 2026-10-22 | UP-01 | 上位モデル（親） | remote/fetch/tree/log確認。masterから最新系統を発見。GitHub APIはForbidden |
| 2026-10-22 | UP-01 / UP-03補助 | GPT-6.1-Sol（`gpt-6.1-sol`指定） | 最新v2・42AT・残ゲートをread-onlyレビュー。1h前提の文書差を指摘。親が内容を照合 |
| 2026-10-22 | UP-02 | 上位モデル（親） | 追加設計、HC-01〜12、state/commit/rollback境界を記述。アプリ実装やWindows実証は未実施 |
| 2026-10-22 | UP-03 | 上位モデル（親） | モデル別台帳、42AT対応、開始手順を作成。文書リンク・ID・依存整合を検証 |
| 2026-10-22 | UP-02 / UP-03レビュー | GPT-6.1-Sol指定 → 親が修正 | Stage 0出口から後段adapter依存を除去。Windows実証を採用engine/配布物へ束縛し、変更時の旧判定失効を明記 |
| 2026-10-22 | 基準確認 | 上位モデル（親） | `PYTHONPATH=reference PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s reference/tests -v` → 24件成功 |
| 2026-10-22 | DEV-01 | このチャットの親（Sol割当を実行） | 固定Go準備・再実行、変更前105件、最終race付き164件成功、vet/build/smoke/Windows cross-build。詳細は[検証記録](docs/research/STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md) |
| 2026-10-22 | HLD-01 | 親（Luna未提供、先行依存を代行） | HC-01〜12の独立ベクトルを固定。実測範囲と製品未実証を別記 |
| 2026-10-22 | HLD-02 / HLD-03 | 親（Sol割当を実行） | TOY/CASH限定状態・重複判定、v1保持のschema v2、原子的claim/receipt/outbox、候補履歴 |
| 2026-10-22 | HLD-04 | 親（Sol割当を実行） | subprocess中断、投影/receipt改変、故障注入、backup/witness復元、再送・fenceの回帰を確認 |
| 2026-10-22 | INT-01 | 親（Sol割当を実行） | synthetic-evaluation-v2、実内容hash、保存manifestと新Run、公開済みclaimに束縛した新kernel revision |
| 2026-10-22 | 実装レビュー | GPT-6.1-Sol指定 → 親が修正・統合 | 投影巻戻し・商品alias・訂正条件の3指摘を修正し回帰追加。再レビューで新たな重大不整合なし。子はread-only |

2026-10-23再開確認: 保存済みテスト結果、文書リンク、TOML、v1 DDL/freeze維持、作業差分を再確認。アプリコードは最終試験後から変更していない。

今回のDONEは合成Store/libraryの範囲。全HCの製品実経路、科学的valid、Stage 0全体の合格を意味しない。各行の詳細証拠・ファイル・限界は[今回の実測](docs/research/STAGE0_SYNTHETIC_REGISTRY_2026-10-22.md)を参照する。

直前までの次候補だった`SAFE-01`と`DOC-01`は、下記の継続で完了した。`ENG-01`は`MKT-03`、`MKT-04`は市場/安全ゲート、`SAFE-02`はWindowsと採用engineを待つ。後段はGATEDのまま。公開/PR作成は未実施。製品AT全面合格やStage 0 exitを宣言していない。

2026-10-23追加指示: 残タスクをこのチャットで可能な範囲まで継続する。SAFE-01/DOC-01、公式資料到達確認、SAFE-02の証跡harness準備、市場未選定でも分離可能な合成golden/比較器を進める。市場仕様・実機・権利の証拠がない項目は完了にしない。

| 日付 | Task | 実担当 | 結果と証拠 |
|---|---|---|---|
| 2026-10-23 | DOC-01 | GPT-6.1-Sol（Luna未提供の代行）→親レビュー | 4文書の市場前提11箇所を整合、要件原本・過去記録を維持 |
| 2026-10-23 | DOC-02 / MKT-01部分 | GPT-6.1-Sol（Luna未提供の代行）→親確認 | 公開表示・PR3件・固定bitbank文書。API/取引所本文403、コメントの報告値は公式値に採用せず |
| 2026-10-23 | SAFE-01 / PRE-03 | 親、Sol読取レビュー | 公式Microsoft固定文書、境界設計、preflightと15試験。UBRと観測SID/policy/fixture等の束縛をレビュー後に強化 |
| 2026-10-23 | PRE-01 / PRE-02 | 親が契約、GPT-6.1-Solが実装、親が再実行 | 3会計例の最大差1.14e-13以下、部分決済の損益定義差と既定次足openの時計差を記録 |
| 2026-10-23 | PRE-04 | 親が契約、GPT-6.1-Solが実装、親レビュー/試験 | 31試験、純粋JSON bytes検査と不変report。実データの取込/保存/公開許可なし |
| 2026-10-23 | 統合検証・環境下書き | 親 | Python77件成功、標準構成73成功/4skip。7hostの下書き保存、実適用未確認。詳細は[継続作業記録](docs/research/STAGE0_CONTINUATION_2026-10-23.md) |

次の作業はDOC-02/MKT-01の不足する一次資料・設定の確認→親MKT-02/03→Sol ENG-01、親ENG-02→WindowsでSol SAFE-02→親SAFE-03の順。現環境だけで新たに完了できるREADYはない。Lunaだけが残っている状態ではない。

### Sol引継ぎ後の確認・補助修正

2026-10-23: ユーザーのSol引継ぎ指示に基づき同じbranch/HEADと未commit作業の保全を確認。ENG-01はMKT-03、SAFE-02はENG-02/Windows実機、MKT-04はMKT-02/03/SAFE-03が未充足で、元タスクの状態を維持する。runtimeの追加allowed_hostsは空、policy stateはunknownのため、下書き7 hostの適用を確認できず、拒否先へ再試行していない。

| Task | 範囲 | 担当 | 状態 | 証拠・残条件 |
|---|---|---|---|---|
| SAFE-02準備 / PRE-03修正 | SID subauthorityの範囲・表記とidentity分離の入力検査 | このチャット（GPT-6.1-Sol担当、ユーザー指定）、Sol指定の子がread-onlyレビュー | DONE（補助修正のみ） | DWORD超過・先頭ゼロaliasを拒否、正常hash維持。専用20件/全Python82件成功、標準構成78成功/4skip。SAFE-02本体はBLOCKED。[修正・解除条件](docs/research/SOL_STAGE0_READINESS_2026-10-23.md) |

### MKT-01の個別引継ぎ（2026-10-23 07:37 JST）

担当はこのチャット（Sol担当としてLuna割当を代行、子の委任なし）。現branch/HEADと既存未commit作業を保全。runtimeと下書きを別に読み、必要hostの適用を確認できないためユーザー指定どおり接続を行わなかった。保存済みbitbank固定版の3原本を前回hash・cloneと照合し、仕様の既知部分と権利/料金/時計等の不足を整理した。MKT-01はBLOCKED維持、MKT-02/03の判断は上位モデル待ち。[今回の調査記録](docs/research/MKT01_NETWORK_AND_EVIDENCE_2026-10-23.md)を参照。今回変更は文書3件のみ、アプリ/数値試験は未実施。

2026-10-24継続: Sol担当としてruntime/下書きと適用機能の有無を診断。追加許可は依然未確認。下書き保存とユーザー画面からの設定保存を区別し、後者がruntime更新を要求できることを公式skillで確認。Publishは別処理。必要な画面操作と再開条件を上記記録§5/HANDOFFへ反映した。ツールで適用やPublishは実行できず、同じ保存/接続を反復していない。MKT-01はBLOCKED維持。

### ローカルPCへの移行準備（2026-10-24）

ユーザーのローカル移行依頼に基づき、Sol担当としてGit bundle＋未commitを含む115作業ソース＋検証サマリーの配布ZIPと復元器を準備した。[ローカル引継ぎ](docs/research/LOCAL_DEVELOPMENT_HANDOFF_2026-10-24.md)にOS別手順と再開依頼を記録。状態: DONE（移行パッケージの準備・Linux復元検証のみ）。復元先でHEAD/hash/status一致、Go164成功/helper1skip、Python78成功/4skip。改変等7ケースの拒否とGit設定注入を継承しないことを検証。Sol指定の子がread-onlyレビューを担当し、Git設定継承の指摘を修正した。ローカルPCへの直接接続はなく、PC側の導入・認証・実測は未実施。MKT-01とStage/安全ゲートは未完了を維持する。
