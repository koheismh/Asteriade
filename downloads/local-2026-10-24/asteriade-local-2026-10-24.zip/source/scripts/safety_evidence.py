"""Offline evidence preflight. This tool never enables a Runner capability.

Use a private, stable copy of evidence collected by a trusted Windows harness.
Hash/schema agreement is not proof that an OS denial actually occurred.
"""

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import sys


SCHEMA = "asteriade/safety-evidence-v1"
PROFILE_SCHEMA = "asteriade/windows-boundary-v1"
OBSERVATION_SCHEMA = "asteriade/safety-observation-v1"
CASE_IDS = (
    "SV-16-files", "SV-16-paths", "SV-17-tree", "SV-17-startup",
    "SV-17-handles", "SV-17-mediated", "SV-18-network", "SV-19-host",
    "SV-20-ipc", "SV-21-recovery", "SV-03-orders", "SV-04-privacy",
)
TOOLS = ("controller", "broker", "evaluator", "worker", "host", "kernel")
ROLES = ("controller", "broker", "evaluator", "worker", "host")
STATUSES = {"passed", "failed", "blocked", "skipped", "unrun"}
MAX_BYTES = 4 * 1024 * 1024
MAX_AGE = timedelta(hours=72)


def require(condition, code):
    if not condition:
        raise ValueError(code)


def keys(value, expected, code):
    require(type(value) is dict and set(value) == set(expected), code)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def is_hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None and value != "0" * 64


def label(value):
    return isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", value) is not None


def valid_sid(value, prefix, subauthorities):
    # Windows subauthorities are DWORDs. Reject alternate representations;
    # normalizing them here would change the reviewed profile's identity/hash.
    if not isinstance(value, str) or len(value) > 184 or not value.startswith(prefix):
        return False
    parts = value[len(prefix):].split("-")
    return len(parts) == subauthorities and all(
        re.fullmatch(r"0|[1-9][0-9]{0,9}", part) is not None and int(part) <= 4294967295
        for part in parts)


def timestamp(value):
    require(isinstance(value, str) and len(value) <= 40 and value.endswith("Z"), "invalid_timestamp")
    result = datetime.fromisoformat(value[:-1] + "+00:00")
    require(result.tzinfo is not None and 2020 <= result.year < 2100, "invalid_timestamp")
    return result


def strict_json(raw):
    require(len(raw) <= MAX_BYTES, "document_too_large")

    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "duplicate_json_key")
            result[key] = value
        return result

    def constant(_):
        raise ValueError("non_finite_json")

    return json.loads(raw, object_pairs_hook=unique, parse_constant=constant)


def profile_fingerprint(profile):
    keys(profile, ("schema", "os", "edition", "build", "ubr", "arch", "backend",
                   "tools", "identities", "appcontainer_sid", "policy_sha256", "fixture_sha256"), "invalid_profile_fields")
    require(profile["schema"] == PROFILE_SCHEMA and profile["os"] == "windows" and
            profile["arch"] == "amd64" and profile["edition"] in
            {"Windows 11 Home", "Windows 11 Pro", "Windows 11 Enterprise", "Windows 11 Education"}, "unsupported_platform")
    require(type(profile["build"]) is int and 22000 <= profile["build"] < 100000, "invalid_windows_build")
    require(type(profile["ubr"]) is int and 0 <= profile["ubr"] <= 4294967295, "invalid_windows_revision")
    require(profile["backend"] == "appcontainer-job-v1", "unsupported_backend")
    keys(profile["tools"], TOOLS, "invalid_tools")
    require(all(is_hash(v) for v in profile["tools"].values()), "invalid_tool_hash")
    require(is_hash(profile["policy_sha256"]) and is_hash(profile["fixture_sha256"]), "invalid_policy_or_fixture_hash")
    keys(profile["identities"], ROLES, "invalid_identities")
    sids = list(profile["identities"].values())
    require(all(valid_sid(s, "S-1-5-21-", 4) for s in sids), "invalid_account_sid")
    require(len(set(sids)) == len(ROLES), "identities_not_separated")
    sid = profile["appcontainer_sid"]
    require(valid_sid(sid, "S-1-15-2-", 7), "invalid_appcontainer_sid")
    canonical = json.dumps(profile, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return digest(canonical)


def read_artifact(root, ref):
    keys(ref, ("file", "sha256"), "invalid_artifact_reference")
    name = ref["file"]
    # Flat portable filenames: no traversal, ADS, drive, UNC or subdirectory.
    require(isinstance(name, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\.json", name), "invalid_artifact_path")
    require(is_hash(ref["sha256"]), "invalid_artifact_hash")
    path = root / name
    require(not path.is_symlink() and path.is_file() and path.resolve().parent == root, "unsafe_or_missing_artifact")
    with path.open("rb") as stream:
        raw = stream.read(MAX_BYTES + 1)
    require(len(raw) <= MAX_BYTES and digest(raw) == ref["sha256"], "artifact_hash_mismatch")
    return strict_json(raw)


def verify(bundle, artifacts, expected_profile, *, now=None):
    keys(bundle, ("schema", "run_id", "started_at", "finished_at", "profile", "profile_sha256", "cases"), "invalid_bundle_fields")
    require(bundle["schema"] == SCHEMA and label(bundle["run_id"]), "invalid_bundle_identity")
    measured = profile_fingerprint(bundle["profile"])
    require(is_hash(expected_profile) and measured == expected_profile == bundle["profile_sha256"], "profile_mismatch")
    started, finished = timestamp(bundle["started_at"]), timestamp(bundle["finished_at"])
    now = now or datetime.now(timezone.utc)
    require(started <= finished <= now and now - started <= MAX_AGE, "stale_or_future_evidence")
    require(type(bundle["cases"]) is list and len(bundle["cases"]) <= len(CASE_IDS), "invalid_case_count")
    root = Path(artifacts).resolve(strict=True)
    require(root.is_dir(), "invalid_artifact_directory")
    seen, files, issues = set(), set(), []
    for case in bundle["cases"]:
        keys(case, ("id", "status", "positive", "negative", "reason"), "invalid_case_fields")
        case_id = case["id"]
        require(isinstance(case_id, str) and case_id in CASE_IDS and case_id not in seen, "unknown_or_duplicate_case")
        seen.add(case_id)
        require(isinstance(case["status"], str) and case["status"] in STATUSES, "invalid_case_status")
        require(isinstance(case["reason"], str) and len(case["reason"]) <= 2048, "invalid_case_reason")
        if case["status"] != "passed":
            require(bool(case["reason"].strip()), "missing_nonpass_reason")
            issues.append(case_id + ":" + case["status"])
            continue
        for phase in ("positive", "negative"):
            ref = case[phase]
            observation = read_artifact(root, ref)
            require(ref["file"] not in files, "reused_artifact")
            files.add(ref["file"])
            keys(observation, ("schema", "run_id", "profile_sha256", "test_id", "phase", "recorded_at",
                               "execution_id", "subject_role", "subject_sid", "policy_sha256", "procedure",
                               "fixture_before_sha256", "fixture_after_sha256", "sink_received", "remaining_processes",
                               "result", "expected", "observed", "exit_code", "os_error"), "invalid_observation_fields")
            require(observation["schema"] == OBSERVATION_SCHEMA and observation["run_id"] == bundle["run_id"] and
                    observation["profile_sha256"] == measured and observation["test_id"] == case_id and
                    observation["phase"] == phase, "observation_binding_mismatch")
            require(started <= timestamp(observation["recorded_at"]) <= finished, "observation_time_mismatch")
            require(label(observation["execution_id"]) and observation["result"] == "passed", "observation_not_passed")
            role = observation["subject_role"]
            require(isinstance(role, str) and role in ROLES and observation["subject_sid"] == bundle["profile"]["identities"][role], "observation_identity_mismatch")
            require(observation["policy_sha256"] == bundle["profile"]["policy_sha256"], "observation_policy_mismatch")
            require(observation["fixture_before_sha256"] == bundle["profile"]["fixture_sha256"] and
                    is_hash(observation["fixture_after_sha256"]), "observation_fixture_mismatch")
            for field in ("procedure", "expected", "observed"):
                require(isinstance(observation[field], str) and 0 < len(observation[field].strip()) <= 8192, "missing_observation")
            for field in ("sink_received", "remaining_processes"):
                value = observation[field]
                require(value is None or type(value) is int and 0 <= value <= 2147483647, "invalid_observation_count")
            if case_id == "SV-18-network":
                received = observation["sink_received"]
                require(type(received) is int and (received > 0 if phase == "positive" else received == 0), "network_control_or_denial_failed")
            if case_id == "SV-17-tree":
                require(observation["remaining_processes"] == 0, "descendants_not_reaped")
            require(type(observation["exit_code"]) is int and type(observation["os_error"]) is int and
                    -2147483648 <= observation["exit_code"] <= 4294967295 and
                    0 <= observation["os_error"] <= 4294967295, "invalid_os_result")
    issues.extend(case_id + ":missing" for case_id in CASE_IDS if case_id not in seen)
    return {"status": "blocked" if issues else "review_required", "execution_enabled": False,
            "profile_sha256": measured, "issues": issues,
            "note": "Completeness/hash preflight only; trusted Windows observations and human review still required."}


def template():
    return {"schema": SCHEMA, "run_id": None, "started_at": None, "finished_at": None,
            "profile": {"schema": PROFILE_SCHEMA, "os": None, "edition": None, "build": None, "ubr": None,
                        "arch": None, "backend": "appcontainer-job-v1", "tools": dict.fromkeys(TOOLS),
                        "identities": dict.fromkeys(ROLES), "appcontainer_sid": None,
                        "policy_sha256": None, "fixture_sha256": None}, "profile_sha256": None,
            "cases": [{"id": case_id, "status": "unrun", "positive": None, "negative": None,
                       "reason": "Windows observations have not been collected."} for case_id in CASE_IDS]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--template", action="store_true", help="emit an unrun template; does not inspect this OS")
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--artifacts", type=Path)
    parser.add_argument("--expected-profile", help="fingerprint fixed separately during profile review")
    args = parser.parse_args()
    if args.template:
        require(not (args.bundle or args.artifacts or args.expected_profile), "template_arguments_conflict")
        print(json.dumps(template(), indent=2))
        return 0
    if not (args.bundle and args.artifacts and args.expected_profile):
        parser.error("--bundle, --artifacts and --expected-profile are required")
    try:
        with args.bundle.open("rb") as stream:
            bundle = strict_json(stream.read(MAX_BYTES + 1))
        report = verify(bundle, args.artifacts, args.expected_profile)
    except (ValueError, OSError, TypeError, RecursionError):
        # Do not echo paths, raw observations or private data from an invalid bundle.
        report = {"status": "blocked", "execution_enabled": False, "issues": ["invalid_evidence_bundle"]}
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "review_required" else 1


if __name__ == "__main__":
    sys.exit(main())
