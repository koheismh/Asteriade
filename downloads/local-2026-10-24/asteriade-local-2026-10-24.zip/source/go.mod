module github.com/koheismh/Asteriade

go 1.27.2

require (
	github.com/ncruces/go-sqlite3 v0.35.6
	golang.org/x/sys v0.48.0
)

require (
	github.com/ncruces/go-sqlite3-wasm/v6 v6.3.35304 // indirect
	github.com/ncruces/julianday v1.0.0 // indirect
)
