"""Restore this handoff into a new directory using only Python and Git.

Offline operation. No commit, push, dependency install or application execution.
Verify the outer ZIP's published SHA-256 before extracting and running this file.
Use an unchanged private copy of the extracted package during restoration.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile


MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
RESERVED = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$"} | {
    prefix + str(n) for prefix in ("COM", "LPT") for n in range(1, 10)}
REPO_OVERRIDES = ("GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR", "GIT_INDEX_FILE", "GIT_CONFIG",
                  "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, "Duplicate manifest key")
        obj[key] = value
    return obj


def relative(name):
    require(isinstance(name, str) and 0 < len(name) <= 180 and
            re.fullmatch(r"[A-Za-z0-9_./-]+", name), "Invalid portable file path")
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name, "Noncanonical file path")
    for part in name.split("/"):
        require(part not in ("", ".", "..") and part.lower() != ".git" and
                not part.endswith((".", " ")) and part.split(".")[0].upper() not in RESERVED,
                "Unsafe portable file path")
    return Path(*path.parts)


def regular(root, name):
    path = root / relative(name)
    for part in (path, *path.parents):
        if part == root:
            break
        require(not part.is_symlink() and not getattr(part, "is_junction", lambda: False)(),
                "Links are not accepted in package files")
    require(path.is_file() and root in path.resolve().parents, "Missing or unsafe package file")
    return path


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_package(root):
    raw = regular(root, "manifest.json").read_bytes()
    require(len(raw) <= 1024 * 1024, "Manifest is too large")
    manifest = json.loads(raw, object_pairs_hook=unique)
    require(type(manifest) is dict and set(manifest) == {
        "schema", "repository", "origin", "branch", "head", "files", "source_paths",
        "deleted_tracked_paths", "git_status_porcelain", "cloud_validation"}, "Invalid manifest fields")
    require(manifest["schema"] == "asteriade/local-handoff-v1" and
            manifest["repository"] == "koheismh/Asteriade" and
            manifest["origin"] == "https://github.com/koheismh/Asteriade.git" and
            manifest["branch"] == "codex/model-task-plan" and
            manifest["head"] == "6d01d08897b4ed53de01138ee737cc6ef9deb119", "Unexpected handoff identity")
    files = manifest["files"]
    require(type(files) is dict and 1 <= len(files) <= 4096, "Invalid file list")
    folded, total = {"manifest.json"}, 0
    for name, meta in files.items():
        relative(name)
        require(name.casefold() not in folded, "Case-insensitive path collision")
        folded.add(name.casefold())
        require(type(meta) is dict and set(meta) == {"size", "sha256", "mode"}, "Invalid file metadata")
        require(type(meta["size"]) is int and 0 <= meta["size"] <= MAX_FILE and
                type(meta["mode"]) is int and meta["mode"] in (0o644, 0o755) and
                isinstance(meta["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", meta["sha256"]),
                "Invalid size, hash or file mode")
        total += meta["size"]
        require(total <= MAX_TOTAL, "Package is too large")
        path = regular(root, name)
        require(path.stat().st_size == meta["size"] and sha(path) == meta["sha256"],
                "Package content/hash mismatch: " + name)
    require({"base.bundle", "tracked-changes.patch", "index.patch", "restore.py", "README_LOCAL.md"} <= files.keys(),
            "Required package file is missing")
    actual = set()
    for path in root.rglob("*"):
        require(not path.is_symlink() and not getattr(path, "is_junction", lambda: False)(),
                "Package contains a link")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
        else:
            require(path.is_dir(), "Package contains a special file")
    require(actual == set(files) | {"manifest.json"}, "Unexpected or missing package files")
    sources, deleted = manifest["source_paths"], manifest["deleted_tracked_paths"]
    for names in (sources, deleted):
        require(type(names) is list and len(names) <= 4096, "Invalid source paths")
        for name in names:
            relative(name)
        require(len({p.casefold() for p in names}) == len(names), "Duplicate source paths")
    require(not ({p.casefold() for p in sources} & {p.casefold() for p in deleted}), "Conflicting source paths")
    require({"source/" + p for p in sources} == {p for p in files if p.startswith("source/")},
            "Source manifest mismatch")
    require(isinstance(manifest["git_status_porcelain"], str), "Invalid Git state record")
    return manifest


def git(*args, cwd=None):
    # Scope isolation to this offline helper. Do not change the user's global
    # config or copy authentication/proxy configuration into the restored repo.
    env = os.environ.copy()
    env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
               GIT_CONFIG_COUNT="0", GIT_ALLOW_PROTOCOL="file", GIT_TERMINAL_PROMPT="0")
    env.pop("GIT_CONFIG_PARAMETERS", None)
    for name in list(env):
        if re.fullmatch(r"GIT_CONFIG_(?:KEY|VALUE)_[0-9]+", name):
            env.pop(name)
    result = subprocess.run(["git", "-c", "core.fsmonitor=false", *map(str, args)],
                            cwd=cwd, env=env, check=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout


def restore(root, destination):
    require(shutil.which("git") is not None, "Install Git first")
    require(not any(os.environ.get(k) for k in REPO_OVERRIDES),
            "Run from a normal terminal without Git repository override variables")
    root = root.resolve(strict=True)
    manifest = check_package(root)
    destination = destination.absolute()
    require(not destination.exists() and not destination.is_symlink(), "Destination already exists; choose a new path")
    require(destination.parent.is_dir(), "Create the destination's parent directory first")
    destination = destination.resolve()
    require(root not in destination.parents, "Choose a destination outside the extracted package")
    heads = git("bundle", "list-heads", root / "base.bundle").decode("ascii").splitlines()
    require(manifest["head"] + " refs/heads/" + manifest["branch"] in heads, "Bundle HEAD does not match")
    # Atomic mkdir prevents overwriting a path created after the preflight.
    destination.mkdir()
    with tempfile.TemporaryDirectory(prefix="asteriade-empty-template-") as empty:
        git("-c", "core.hooksPath=" + empty, "-c", "core.autocrlf=false", "clone",
            "--no-checkout", "--no-recurse-submodules", "--template=" + empty,
            "--branch", manifest["branch"], root / "base.bundle", destination)
    require(git("rev-parse", "HEAD", cwd=destination).decode().strip() == manifest["head"], "Restored HEAD differs")
    git("config", "core.autocrlf", "false", cwd=destination)
    git("remote", "set-url", "origin", manifest["origin"], cwd=destination)
    git("read-tree", "HEAD", cwd=destination)
    if (root / "index.patch").stat().st_size:
        git("apply", "--cached", "--binary", "--whitespace=nowarn", root / "index.patch", cwd=destination)
    for name in manifest["source_paths"]:
        source = regular(root, "source/" + name)
        target = destination / relative(name)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(source.read_bytes())
        if os.name != "nt":
            target.chmod(manifest["files"]["source/" + name]["mode"])
        require(sha(target) == manifest["files"]["source/" + name]["sha256"], "Restored source hash mismatch")
    status = git("status", "--porcelain=v1", "--untracked-files=all", "-z", cwd=destination).decode("utf-8")
    require(status == manifest["git_status_porcelain"], "Restored Git status differs; keep files for inspection")
    completion = {"schema": manifest["schema"], "head": manifest["head"], "source_files_verified": len(manifest["source_paths"]),
                  "git_status_matches": True, "runner_enabled": False, "local_tests": "not_run"}
    (destination / ".git" / "asteriade-handoff.json").write_text(json.dumps(completion, indent=2) + "\n", encoding="utf-8")
    print("Restored:", destination)
    print("Verified source files:", len(manifest["source_paths"]))
    print("HEAD, file hashes and uncommitted Git status match the cloud handoff.")
    print("No commit/push, dependency installation or application execution was performed.")
    print("Read docs/research/LOCAL_DEVELOPMENT_HANDOFF_2026-10-24.md next.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", required=True, type=Path)
    args = parser.parse_args()
    try:
        restore(Path(__file__).resolve().parent, args.destination)
    except (ValueError, OSError, subprocess.CalledProcessError, RecursionError) as error:
        if isinstance(error, subprocess.CalledProcessError):
            print("Git failed. Check Git installation and the new destination; keep partial output for inspection.", file=sys.stderr)
        else:
            print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
