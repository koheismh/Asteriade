# Windows 動作確認用 ZIP

このZIPのEXEは、同じStage 0ソースからデバッグ用シンボルを除いてビルドした軽量版です。アプリケーションコードは変更していません。

ビルド: `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o bin/portable/asteriade.exe ./cmd/asteriade`

実行ファイルのSHA-256は同梱の `SHA256SUMS.txt` を参照してください。`docs/STAGE0_STATUS.md` に記録した従来ビルドのhashとは異なります。Windows実行はまだ未確認です。

最初は `START_HERE.md` に従ってEXEだけの動作確認をしてください。ソース検証にはGo 1.27.2が必要です。
